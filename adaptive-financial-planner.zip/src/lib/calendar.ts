export async function addEventToCalendar(
  token: string, 
  title: string, 
  description: string, 
  dateStr: string // Format: YYYY-MM-DD
) {
  try {
    const event = {
      summary: title,
      description: description,
      start: {
        date: dateStr,
        timeZone: 'Asia/Jakarta'
      },
      end: {
        date: dateStr,
        timeZone: 'Asia/Jakarta'
      }
    };

    const response = await fetch('https://www.googleapis.com/calendar/v3/calendars/primary/events', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(event)
    });
    
    if (!response.ok) {
      throw new Error(`Calendar API Error: ${response.status} ${response.statusText}`);
    }
    
    return await response.json();
  } catch (error) {
    console.error('Failed to add event to Google Calendar:', error);
    throw error;
  }
}
