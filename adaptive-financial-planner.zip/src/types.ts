export interface Income {
  id: string;
  source: string;
  amount: number;
  period: 'monthly' | 'one-time';
  category: 'primary' | 'side-hustle' | 'investment' | 'other' | 'universitas' | 'iuran_kas' | 'dana_usaha' | 'sponsor' | 'organisasi_lain';
  date: string;
  isRecurring?: boolean;
  createdBy?: string;
}

export interface Expense {
  id: string;
  title: string;
  amount: number;
  category: 'kebutuhan' | 'keinginan' | 'tabungan' | 'program_kerja' | 'modal_usaha' | 'operasional_org' | 'lain_lain';
  subcategory: string; // e.g., Sewa, Makanan, Transport, Belanja, Langganan, dll
  date: string;
  isRecurring?: boolean;
  createdBy?: string;
}

export interface Goal {
  id: string;
  name: string;
  targetAmount: number;
  currentAmount: number;
  targetDate: string; // YYYY-MM-DD
  priority: 'high' | 'medium' | 'low';
  category?: 'general' | 'emergency_fund';
  createdBy?: string;
}

export interface AIAdvice {
  recommendedRatio: {
    kebutuhan: number; // percentage (e.g., 50)
    keinginan: number;  // percentage (e.g., 30)
    tabungan: number;   // percentage (e.g., 20)
  };
  summary: string;
  suggestions: string[];
  goalsAnalysis: {
    goalId: string;
    feasibility: 'Mudah Tercapai' | 'Sangat Menantang' | 'Butuh Penyesuaian';
    advice: string;
  }[];
  urgencyLevel: 'Aman' | 'Waspada' | 'Kritis';
}

export interface SimulatorState {
  incomeMultiplier: number; // default 1 (100%)
  needsReduction: number; // default 0 (0% reduction)
  wantsReduction: number; // default 0 (0% reduction)
}
