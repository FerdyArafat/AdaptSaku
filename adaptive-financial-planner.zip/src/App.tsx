import React, { useState, useEffect, useMemo, useRef, FormEvent, ChangeEvent } from 'react';
import { 
  Plus, 
  Sparkles, 
  Wallet, 
  Coins, 
  PiggyBank, 
  Activity, 
  Trash2, 
  RefreshCw,
  Info,
  ChevronDown,
  ChevronUp,
  ChevronLeft,
  ChevronRight,
  Sun,
  Moon,
  Calendar,
  AlertCircle,
  Search,
  Download,
  Upload,
  Database,
  X,
  LogOut,
  Users,
  Copy,
  Settings
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Income, Expense, Goal, AIAdvice } from './types';
import { Dashboard } from './components/Dashboard';
import { FinancialForms } from './components/FinancialForms';
import { AISimulator } from './components/AISimulator';
import { initAuth, googleSignIn, logout, db } from './lib/firebase';
import { addEventToCalendar } from './lib/calendar';
import { User } from 'firebase/auth';
import { collection, doc, query, where, getDocs, setDoc, onSnapshot, deleteDoc, arrayUnion } from 'firebase/firestore';

// ... (Rest of the file has INITIAL_INCOMES, etc., we can still use them if we want to bootstrap)
// with monthly income in the 3-5jt range, filling all available periods (past, current, future, and older)
// with daily/scattered meal expenses.
const generateSampleData = () => {
  const incomesList: Income[] = [];
  const expensesList: Expense[] = [];
  
  const now = new Date();
  const currentYear = now.getFullYear();
  const currentMonth = now.getMonth(); // 0-indexed
  
  // We want to generate data for:
  // - Future month: offset = 1 (Rencana)
  // - Current and past months: offset = -12 to 0
  // - Older than 1 year (older_than_year): offset = -14, -16, -18, -20
  const targetOffsets = [
    -20, -18, -16, -14, // Older than 1 year
    -12, -11, -10, -9, -8, -7, -6, -5, -4, -3, -2, -1, 0, // 12 months back + current
    1 // 1 month ahead
  ];
  
  targetOffsets.forEach((offset) => {
    const targetDate = new Date(currentYear, currentMonth + offset, 1);
    const yr = targetDate.getFullYear();
    const mo = String(targetDate.getMonth() + 1).padStart(2, '0');
    const periodStr = `${yr}-${mo}`;
    
    // 1. INCOMES for this period (Monthly total: 3.2M - 4.2M IDR, which is strictly 3-5jt)
    const isFuture = offset > 0;
    
    // Primary income (Salary): 3,200,000 to 3,700,000 depending on period offset
    const primaryGaji = 3300000 + (Math.abs(offset * 40000) % 400000); 
    incomesList.push({
      id: `inc_gaji_${periodStr}`,
      source: isFuture ? 'Estimasi Gaji Bulanan' : 'Gaji Bulanan (Staf Admin)',
      amount: primaryGaji,
      period: 'monthly',
      category: 'primary',
      date: `${periodStr}-25`
    });
    
    // Side hustle (Optional, present in alternating months to show organic variation): 300,000 to 600,000 IDR
    if (Math.abs(offset) % 2 === 0) {
      const sideIncome = 350000 + (Math.abs(offset * 25000) % 250000);
      incomesList.push({
        id: `inc_side_${periodStr}`,
        source: isFuture ? 'Estimasi Freelance Logo' : 'Freelance Desain Brosur',
        amount: sideIncome,
        period: 'monthly',
        category: 'side-hustle',
        date: `${periodStr}-15`
      });
    }
    
    // 2. EXPENSES for this period
    // Fixed Need: Rent / Kos Bulanan (e.g. 800k - 1M IDR, appropriate for 3-5M income)
    const kosAmount = 850000 + (Math.abs(offset * 15000) % 150000);
    expensesList.push({
      id: `exp_kos_${periodStr}`,
      title: isFuture ? 'Sewa Kos (Rencana)' : 'Sewa Kamar Kos',
      amount: kosAmount,
      category: 'kebutuhan',
      subcategory: 'Sewa Tempat Tinggal',
      date: `${periodStr}-05`
    });
    
    // Fixed Need: Room Electricity / Listrik Kos
    expensesList.push({
      id: `exp_electricity_${periodStr}`,
      title: 'Iuran Listrik Bulanan',
      amount: 110000 + (Math.abs(offset * 4000) % 30000),
      category: 'kebutuhan',
      subcategory: 'Tagihan & Utilitas',
      date: `${periodStr}-07`
    });
    
    // Fixed Need: Mobile Internet / Kuota
    expensesList.push({
      id: `exp_internet_${periodStr}`,
      title: 'Paket Data & Pulsa Seluler',
      amount: 75000 + (Math.abs(offset * 5000) % 20000),
      category: 'kebutuhan',
      subcategory: 'Tagihan & Utilitas',
      date: `${periodStr}-03`
    });

    // Daily meal items, highly scattered & diverse to show concrete, non-lump-sum daily expenses
    // Day of execution list for frequent meals:
    const mealDays = [1, 3, 5, 7, 9, 11, 13, 15, 17, 19, 21, 23, 25, 27, 29, 30];
    const mealTemplates = [
      { t: 'Sarapan Bubur Ayam Pasar', amt: 12000, cat: 'kebutuhan', sub: 'Makanan & Minuman' },
      { t: 'Makan Siang Nasi Padang Sederhana', amt: 21000, cat: 'kebutuhan', sub: 'Makanan & Minuman' },
      { t: 'Makan Malam Nasi Goreng Gila', amt: 17000, cat: 'kebutuhan', sub: 'Makanan & Minuman' },
      { t: 'Belanja Sayur Cook-at-Home', amt: 65000, cat: 'kebutuhan', sub: 'Makanan & Minuman' },
      { t: 'Makan Siang Warteg Dua Ribu', amt: 18000, cat: 'kebutuhan', sub: 'Makanan & Minuman' },
      { t: 'Sarapan Soto Ayam Lamongan', amt: 15000, cat: 'kebutuhan', sub: 'Makanan & Minuman' },
      { t: 'Es Kopi Susu Aren & Donat', amt: 16000, cat: 'keinginan', sub: 'Makan Mewah/Kafe' },
      { t: 'Makan Malam Bebek Goreng Tenda', amt: 24000, cat: 'kebutuhan', sub: 'Makanan & Minuman' },
      { t: 'Mie Ayam Pangsit & Bakso Saku', amt: 19000, cat: 'kebutuhan', sub: 'Makanan & Minuman' },
      { t: 'Belanja Snack Kuartalan', amt: 50000, cat: 'kebutuhan', sub: 'Makanan & Minuman' },
      { t: 'Nongkrong Ngopi Tipis di Kafe', amt: 28000, cat: 'keinginan', sub: 'Makan Mewah/Kafe' },
      { t: 'Makan Siang Soto Betawi', amt: 23000, cat: 'kebutuhan', sub: 'Makanan & Minuman' },
      { t: 'Sarapan Pecel Madiun Lengkap', amt: 14000, cat: 'kebutuhan', sub: 'Makanan & Minuman' },
      { t: 'Makan Malam Kupat Tahu', amt: 15000, cat: 'kebutuhan', sub: 'Makanan & Minuman' },
      { t: 'Es Coklat & Roti Panggang', amt: 20000, cat: 'keinginan', sub: 'Makan Mewah/Kafe' },
      // Saving/Tabungan direct expense to match the structure
      { t: 'Tabungan Reksa Dana Mingguan', amt: 100000, cat: 'tabungan', sub: 'Investasi' }
    ];
    
    mealDays.forEach((day, mIdx) => {
      const templateIdx = (mIdx + Math.abs(offset)) % mealTemplates.length;
      const t = mealTemplates[templateIdx];
      expensesList.push({
        id: `exp_meal_${periodStr}_${day}`,
        title: isFuture ? `Estimasi: ${t.t}` : t.t,
        amount: t.amt + (Math.abs(offset + day) % 7) * 1000, // randomized variation
        category: t.cat as any,
        subcategory: t.sub,
        date: `${periodStr}-${String(day).padStart(2, '0')}`
      });
    });

    // Weekly transport (e.g. gasoline / bensin)
    const fuelDays = [2, 9, 16, 23, 30];
    fuelDays.forEach((fDay, fIdx) => {
      expensesList.push({
        id: `exp_fuel_${periodStr}_${fDay}`,
        title: 'Bensin Motor (Pertalite)',
        amount: 25000 + (fIdx % 2 === 0 ? 5000 : 0),
        category: 'kebutuhan',
        subcategory: 'Transportasi',
        date: `${periodStr}-${String(fDay).padStart(2, '0')}`
      });
    });

    // Moderate subscriptions or lifestyle elements to keep budgeting dynamic and colorful
    if (Math.abs(offset) % 3 === 0) {
      expensesList.push({
        id: `exp_sub_${periodStr}`,
        title: 'Langganan Spotify Family (Patungan)',
        amount: 32000,
        category: 'keinginan',
        subcategory: 'Streaming & Hiburan',
        date: `${periodStr}-10`
      });
    }
    
    if (Math.abs(offset) % 4 === 1) {
      expensesList.push({
        id: `exp_cinema_${periodStr}`,
        title: 'Nonton Bioskop Weekend (Tiket & Minum)',
        amount: 45000,
        category: 'keinginan',
        subcategory: 'Streaming & Hiburan',
        date: `${periodStr}-18`
      });
    }

    if (Math.abs(offset) % 2 === 1) {
      expensesList.push({
        id: `exp_laundry_${periodStr}`,
        title: 'Jasa Laundry Kiloan Mingguan',
        amount: 35000,
        category: 'kebutuhan',
        subcategory: 'Lainnya',
        date: `${periodStr}-20`
      });
    }

    expensesList.push({
      id: `exp_haircut_${periodStr}`,
      title: 'Pangkas Rambut Rapih',
      amount: 25000,
      category: 'kebutuhan',
      subcategory: 'Lainnya',
      date: `${periodStr}-28`
    });
  });

  return { incomesList, expensesList };
};

const { incomesList: INITIAL_INCOMES, expensesList: INITIAL_EXPENSES } = generateSampleData();

const INITIAL_GOALS: Goal[] = [
  { id: 'g1', name: 'Dana Darurat 3 Bulan', targetAmount: 8000000, currentAmount: 3500000, targetDate: '2026-12-31', priority: 'high' },
  { id: 'g2', name: 'Beli Sepeda Lipat Baru', targetAmount: 2200000, currentAmount: 800000, targetDate: '2026-11-20', priority: 'medium' }
];

export default function App() {
  const [needsAuth, setNeedsAuth] = useState(true);
  const [token, setToken] = useState<string | null>(null);
  const [user, setUser] = useState<User | null>(null);
  const [isLoggingIn, setIsLoggingIn] = useState(false);
  const [organizations, setOrganizations] = useState<any[]>([]);
  const [activeOrgId, setActiveOrgId] = useState<string | null>(null);
  const [orgMembers, setOrgMembers] = useState<any[]>([]);
  const [memberFilter, setMemberFilter] = useState<string>('ALL');
  const [isOrgModalOpen, setIsOrgModalOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [newOrgName, setNewOrgName] = useState('');
  const [newMemberUid, setNewMemberUid] = useState('');

  useEffect(() => {
    const unsubscribe = initAuth(
      (u, tk) => { 
        setUser(u);
        setToken(tk);
        setNeedsAuth(false); 
      },
      () => {
        setUser(null);
        setToken(null);
        setNeedsAuth(true); 
      }
    );
    return () => unsubscribe();
  }, []);

  const handleLogin = async () => {
    setIsLoggingIn(true);
    try {
      const result = await googleSignIn();
      if (result) {
        setToken(result.accessToken);
        setUser(result.user);
        setNeedsAuth(false);
      }
    } catch (err) {
      console.error('Login failed:', err);
    } finally {
      setIsLoggingIn(false);
    }
  };

  const handleSignOut = async () => {
    await logout();
  };

  const handleCreateOrg = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newOrgName.trim() || !user) return;
    const newOrgId = 'org_' + Math.random().toString(36).substr(2, 9);
    try {
      await setDoc(doc(db, 'organizations', newOrgId), {
        name: newOrgName,
        ownerId: user.uid,
        memberIds: [user.uid],
        createdAt: new Date().toISOString()
      });
      await setDoc(doc(db, `organizations/${newOrgId}/members/${user.uid}`), {
        userId: user.uid,
        role: 'owner'
      });
      triggerToast('Organisasi berhasil dibuat', 'success');
      setNewOrgName('');
      setActiveOrgId(newOrgId);
      setIsOrgModalOpen(false);
    } catch (err) {
      console.error(err);
      triggerToast('Gagal membuat organisasi', 'error');
    }
  };

  const [customId, setCustomId] = useState('');
  const [editingOrgName, setEditingOrgName] = useState('');

  useEffect(() => {
    if (user) {
      getDocs(query(collection(db, 'users'), where('__name__', '==', user.uid))).then(snap => {
        if (!snap.empty && snap.docs[0].data().customId) {
          setCustomId(snap.docs[0].data().customId);
        }
      });
    }
  }, [user]);

  useEffect(() => {
    const org = organizations.find(o => o.id === activeOrgId);
    if (org) setEditingOrgName(org.name);
  }, [activeOrgId, organizations]);

  const handleUpdateCustomId = async () => {
    if (!customId.trim() || customId.length < 3) {
      triggerToast('Custom ID minimal 3 karakter', 'warning');
      return;
    }
    try {
      const q = query(collection(db, 'users'), where('customId', '==', customId.trim()));
      const snap = await getDocs(q);
      const existing = snap.docs.filter(d => d.id !== user?.uid);
      if (existing.length > 0) {
        triggerToast('Custom ID sudah digunakan orang lain', 'warning');
        return;
      }
      await setDoc(doc(db, 'users', user!.uid), { customId: customId.trim() }, { merge: true });
      triggerToast('Custom ID berhasil disimpan', 'success');
    } catch (e) {
      triggerToast('Gagal menyimpan Custom ID', 'error');
    }
  };

  const handleUpdateOrgName = async () => {
    if (!editingOrgName.trim() || !activeOrgId) return;
    try {
       await setDoc(doc(db, 'organizations', activeOrgId), { name: editingOrgName }, { merge: true });
       triggerToast('Nama organisasi diperbarui', 'success');
    } catch(err) {
       triggerToast('Gagal update nama', 'error');
    }
  };

  const handleRemoveMember = async (memberId: string) => {
    if (!activeOrgId || memberId === user?.uid) return;
    try {
      const orgRef = doc(db, 'organizations', activeOrgId);
      const orgDoc = organizations.find(o => o.id === activeOrgId);
      if (orgDoc) {
        const newMemberIds = orgDoc.memberIds.filter((id: string) => id !== memberId);
        await setDoc(orgRef, { memberIds: newMemberIds }, { merge: true });
      }
      await deleteDoc(doc(db, `organizations/${activeOrgId}/members/${memberId}`));
      triggerToast('Anggota dihapus', 'success');
    } catch(err) {
      triggerToast('Gagal menghapus anggota', 'error');
    }
  };

  const handleAddMember = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMemberUid.trim() || !activeOrgId) return;
    try {
      let uidToAdd = newMemberUid.trim();
      const userQ = query(collection(db, 'users'), where('customId', '==', uidToAdd));
      const userSnap = await getDocs(userQ);
      if (!userSnap.empty) {
        uidToAdd = userSnap.docs[0].id;
      }

      const orgRef = doc(db, 'organizations', activeOrgId);
      await setDoc(orgRef, { memberIds: arrayUnion(uidToAdd) }, { merge: true });
      const memberRef = doc(db, `organizations/${activeOrgId}/members/${uidToAdd}`);
      await setDoc(memberRef, { userId: uidToAdd, role: 'member' });
      triggerToast('Anggota berhasil ditambahkan', 'success');
      setNewMemberUid('');
    } catch (err) {
      console.error(err);
      triggerToast('Gagal menambah anggota', 'error');
    }
  };

  useEffect(() => {
    if (!user) {
      setOrganizations([]);
      setActiveOrgId(null);
      return;
    }
    const orgsRef = collection(db, 'organizations');
    const q = query(orgsRef, where('memberIds', 'array-contains', user.uid));
    const unsub = onSnapshot(q, { includeMetadataChanges: true }, (snapshot) => {
      const orgs = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setOrganizations(orgs);
      
      // Prevent optimistic local updates from triggering listeners to subcollections before server ACK
      // which causes 'Missing or insufficient permissions' errors.
      if (snapshot.metadata.hasPendingWrites && snapshot.docChanges().some(change => change.type === "added")) {
        return;
      }

      if (orgs.length > 0 && !activeOrgId) {
        setActiveOrgId(orgs[0].id);
      } else if (orgs.length === 0 && !snapshot.metadata.fromCache) {
        // Create default organization only if from server
        const newOrgId = 'org_' + Math.random().toString(36).substr(2, 9);
        const orgData = {
          name: 'Personal Workspace',
          ownerId: user.uid,
          memberIds: [user.uid],
          createdAt: new Date().toISOString()
        };
        setDoc(doc(db, 'organizations', newOrgId), orgData)
          .then(() => {
            return setDoc(doc(db, `organizations/${newOrgId}/members/${user.uid}`), {
              userId: user.uid,
              role: 'owner'
            });
          })
          .then(() => setActiveOrgId(newOrgId))
          .catch(err => console.error("Error creating default org", err));
      }
    }, (error) => {
      console.error("Firestore Error fetching organizations:", error);
    });
    return () => unsub();
  }, [user]);

  const timelineRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [isSearchVisible, setIsSearchVisible] = useState<boolean>(false);

  const scrollTimeline = (direction: 'left' | 'right') => {
    if (timelineRef.current) {
      const scrollAmount = 350; // Scroll by a few items
      timelineRef.current.scrollBy({
        left: direction === 'left' ? -scrollAmount : scrollAmount,
        behavior: 'smooth'
      });
    }
  };

  const [isDark, setIsDark] = useState<boolean>(() => {
    try {
      const stored = localStorage.getItem('saku_theme');
      return stored === null ? true : stored === 'dark';
    } catch {
      return true;
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem('saku_theme', isDark ? 'dark' : 'light');
    } catch (e) {
      console.warn(e);
    }
  }, [isDark]);

  const [incomes, setIncomes] = useState<Income[]>([]);
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [goals, setGoals] = useState<Goal[]>([]);

  useEffect(() => {
    if (!activeOrgId) {
      setIncomes([]);
      setExpenses([]);
      setGoals([]);
      return;
    }

    const unsubIncomes = onSnapshot(collection(db, `organizations/${activeOrgId}/incomes`), (snapshot) => {
      setIncomes(snapshot.docs.map(d => ({ id: d.id, ...d.data() } as Income)));
    }, (error) => console.error(error));

    const unsubExpenses = onSnapshot(collection(db, `organizations/${activeOrgId}/expenses`), (snapshot) => {
      setExpenses(snapshot.docs.map(d => ({ id: d.id, ...d.data() } as Expense)));
    }, (error) => console.error(error));

    const unsubGoals = onSnapshot(collection(db, `organizations/${activeOrgId}/goals`), (snapshot) => {
      setGoals(snapshot.docs.map(d => ({ id: d.id, ...d.data() } as Goal)));
    }, (error) => console.error(error));

    const unsubMembers = onSnapshot(collection(db, `organizations/${activeOrgId}/members`), (snapshot) => {
      setOrgMembers(snapshot.docs.map(d => d.data()));
    }, (error) => console.error(error));

    return () => {
      unsubIncomes();
      unsubExpenses();
      unsubGoals();
      unsubMembers();
    };
  }, [activeOrgId]);

  const [aiAdvice, setAiAdvice] = useState<AIAdvice | null>(() => {
    try {
      const stored = localStorage.getItem('saku_ai_advice');
      return stored ? JSON.parse(stored) : null;
    } catch {
      return null;
    }
  });

  const [activePeriod, setActivePeriod] = useState<string>(() => {
    try {
      const stored = localStorage.getItem('saku_active_period');
      return stored || '2026-05';
    } catch {
      return '2026-05';
    }
  });

  useEffect(() => {
    localStorage.setItem('saku_active_period', activePeriod);
  }, [activePeriod]);

  // Customizable period list from user
  const [customPeriods, setCustomPeriods] = useState<string[]>(() => {
    try {
      const stored = localStorage.getItem('saku_custom_periods');
      return stored ? JSON.parse(stored) : [];
    } catch {
      return [];
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem('saku_custom_periods', JSON.stringify(customPeriods));
    } catch (e) {
      console.warn(e);
    }
  }, [customPeriods]);

  const [showAddPeriod, setShowAddPeriod] = useState<boolean>(false);
  const [newPeriodYear, setNewPeriodYear] = useState<string>('2026');
  const [newPeriodMonth, setNewPeriodMonth] = useState<string>('05');

  const MONTH_NAMES: { [key: string]: string } = {
    '01': 'Januari',
    '02': 'Februari',
    '03': 'Maret',
    '04': 'April',
    '05': 'Mei',
    '06': 'Juni',
    '07': 'Juli',
    '08': 'Agustus',
    '09': 'September',
    '10': 'Oktober',
    '11': 'November',
    '12': 'Desember'
  };

  const isOlderThanYear = (ym: string) => {
    if (ym === 'older_than_year') return true;
    const parts = ym.split('-');
    if (parts.length < 2) return false;
    const [y, m] = parts.map(Number);
    const now = new Date();
    const currentYear = now.getFullYear();
    const currentMonth = now.getMonth(); // 0-indexed (e.g. 4 for May)
    const monthDiff = (currentYear - y) * 12 + (currentMonth - (m - 1));
    return monthDiff >= 13;
  };

  const formatYearMonthLabel = (ym: string) => {
    if (ym === 'older_than_year') return 'Di Atas 1 Tahun Lalu';
    const parts = ym.split('-');
    if (parts.length < 2) return ym;
    const [year, month] = parts;
    const monthName = MONTH_NAMES[month] || month;
    return `${monthName} ${year}`;
  };

  const handleAddCustomPeriod = (e: FormEvent) => {
    e.preventDefault();
    const periodStr = `${newPeriodYear}-${newPeriodMonth}`;
    
    // Check if the custom period is older than 1 year ago
    if (isOlderThanYear(periodStr)) {
      setActivePeriod('older_than_year');
      triggerToast('Mohon masukkan transaksi yang sudah berusia di atas 1 tahun lalu langsung ke periode "Di Atas 1 Tahun Lalu".', 'info');
      setShowAddPeriod(false);
      return;
    }

    if (!customPeriods.includes(periodStr)) {
      const updated = [...customPeriods, periodStr].sort();
      setCustomPeriods(updated);
      setActivePeriod(periodStr);
      triggerToast(`Periode kustom ${formatYearMonthLabel(periodStr).toUpperCase()} berhasil ditambahkan!`, 'success');
      setShowAddPeriod(false);
    } else {
      setActivePeriod(periodStr);
      triggerToast(`Periode ${formatYearMonthLabel(periodStr).toUpperCase()} sudah ada dalam daftar.`, 'info');
      setShowAddPeriod(false);
    }
  };

  const uniquePeriods = useMemo(() => {
    const periods = new Set<string>();

    const now = new Date();
    const currentYear = now.getFullYear();
    const currentMonth = now.getMonth(); // 0-indexed

    // 1. Generate strictly 1 month ahead (i = 1) and up to 12 months back (i = -12 to 0)
    for (let i = -12; i <= 1; i++) {
      const d = new Date(currentYear, currentMonth + i, 1);
      const yearStr = d.getFullYear();
      const monthStr = String(d.getMonth() + 1).padStart(2, '0');
      periods.add(`${yearStr}-${monthStr}`);
    }

    // 2. Add custom or transactional periods if they are NOT older than 12 months (since those older ones map to 'older_than_year')
    const addPeriodIfRecent = (ym: string) => {
      if (/^\d{4}-\d{2}$/.test(ym)) {
        if (!isOlderThanYear(ym)) {
          periods.add(ym);
        }
      }
    };

    customPeriods.forEach(addPeriodIfRecent);

    incomes.forEach(i => {
      if (i.date && i.date.length >= 7) {
        addPeriodIfRecent(i.date.substring(0, 7));
      }
    });

    expenses.forEach(e => {
      if (e.date && e.date.length >= 7) {
        addPeriodIfRecent(e.date.substring(0, 7));
      }
    });

    const sortedTimeline = Array.from(periods).sort();
    return ['older_than_year', ...sortedTimeline];
  }, [incomes, expenses, customPeriods]);

  const filteredIncomes = useMemo(() => {
    return incomes.filter(i => {
      if (memberFilter !== 'ALL' && i.createdBy !== memberFilter) return false;
      if (!i.date) return false;
      const ym = i.date.substring(0, 7);
      if (activePeriod === 'older_than_year') {
        return isOlderThanYear(ym);
      }
      return ym === activePeriod;
    });
  }, [incomes, activePeriod, memberFilter]);

  const filteredExpenses = useMemo(() => {
    return expenses.filter(e => {
      if (memberFilter !== 'ALL' && e.createdBy !== memberFilter) return false;
      if (!e.date) return false;
      const ym = e.date.substring(0, 7);
      if (activePeriod === 'older_than_year') {
        return isOlderThanYear(ym);
      }
      return ym === activePeriod;
    });
  }, [expenses, activePeriod, memberFilter]);

  const filteredGoals = useMemo(() => {
    return goals.filter(g => {
      if (memberFilter !== 'ALL' && g.createdBy !== memberFilter) return false;
      return true;
    });
  }, [goals, memberFilter]);

  const searchResults = useMemo(() => {
    if (!searchQuery || searchQuery.trim().length < 2) return null;
    const q = searchQuery.toLowerCase().trim();
    
    const matchedIncomes = incomes.filter(i => 
      i.source.toLowerCase().includes(q) ||
      i.category.toLowerCase().includes(q) ||
      (i.date && i.date.includes(q))
    );
    
    const matchedExpenses = expenses.filter(e => 
      e.title.toLowerCase().includes(q) ||
      e.category.toLowerCase().includes(q) ||
      e.subcategory.toLowerCase().includes(q) ||
      (e.date && e.date.includes(q))
    );

    const matchedGoals = goals.filter(g =>
      g.name.toLowerCase().includes(q) ||
      g.priority.toLowerCase().includes(q) ||
      (g.targetDate && g.targetDate.includes(q))
    );
    
    return { incomes: matchedIncomes, expenses: matchedExpenses, goals: matchedGoals };
  }, [incomes, expenses, goals, searchQuery]);

  const handleCopyPreviousPeriod = () => {
    if (activePeriod === 'older_than_year') return;
    const idx = uniquePeriods.indexOf(activePeriod);
    let prevPeriod = '';
    if (idx > 0) {
      prevPeriod = uniquePeriods[idx - 1];
    } else {
      const [y, m] = activePeriod.split('-').map(Number);
      let prevM = m - 1;
      let prevY = y;
      if (prevM === 0) {
        prevM = 12;
        prevY = y - 1;
      }
      prevPeriod = `${prevY}-${String(prevM).padStart(2, '0')}`;
    }

    const prevIncomes = incomes.filter(i => i.date && i.date.startsWith(prevPeriod));
    const prevExpenses = expenses.filter(e => e.date && e.date.startsWith(prevPeriod));

    if (prevIncomes.length === 0 && prevExpenses.length === 0) {
      triggerToast(`Tidak ada data di periode sebelumnya (${formatYearMonthLabel(prevPeriod)}) untuk disalin.`, 'error');
      return;
    }

    setConfirmModal({
      isOpen: true,
      title: 'Salin Anggaran Bulan Lalu?',
      message: `Salin ${prevIncomes.length} pemasukan dan ${prevExpenses.length} pengeluaran dari ${formatYearMonthLabel(prevPeriod)} ke ${formatYearMonthLabel(activePeriod)} sebagai draf rencana/aktivitas?`,
      actionText: 'Salin Data Rencana',
      type: 'indigo',
      onConfirm: () => {
        const clonedIncomes = prevIncomes.map(i => ({
          ...i,
          id: 'inc_' + Math.random().toString(36).substring(2, 9),
          date: i.date.replace(prevPeriod, activePeriod)
        }));

        const clonedExpenses = prevExpenses.map(e => ({
          ...e,
          id: 'exp_' + Math.random().toString(36).substring(2, 9),
          date: e.date.replace(prevPeriod, activePeriod)
        }));

        setIncomes(prev => [...prev, ...clonedIncomes]);
        setExpenses(prev => [...prev, ...clonedExpenses]);
        setConfirmModal(null);
        triggerToast(`Berhasil menyalin ${clonedIncomes.length} pemasukan dan ${clonedExpenses.length} pengeluaran dari ${formatYearMonthLabel(prevPeriod)} ke ${formatYearMonthLabel(activePeriod)}!`, 'success');
      }
    });
  };

  const [activeTab, setActiveTab] = useState<'ringkasan' | 'simulasi'>('ringkasan');
  const [showGuide, setShowGuide] = useState(() => {
    try {
      const stored = localStorage.getItem('saku_show_guide');
      return stored !== 'false';
    } catch {
      return true;
    }
  });

  // State-based Confirm Modal and Toast systems to bypass iframe alert/confirm sandbox blocks
  const [confirmModal, setConfirmModal] = useState<{
    isOpen: boolean;
    title: string;
    message: string;
    actionText: string;
    type?: 'indigo' | 'danger' | 'warning';
    onConfirm: () => void;
  } | null>(null);

  const [toast, setToast] = useState<{
    show: boolean;
    message: string;
    type: 'success' | 'info' | 'error';
  }>({ show: false, message: '', type: 'success' });

  const triggerToast = (message: string, type: 'success' | 'info' | 'error' = 'success') => {
    setToast({ show: true, message, type });
  };

  useEffect(() => {
    if (toast.show) {
      const timer = setTimeout(() => {
        setToast((prev) => ({ ...prev, show: false }));
      }, 4500);
      return () => clearTimeout(timer);
    }
  }, [toast.show]);

  // Active Organization sync is handled by onSnapshot in useEffect

  const handleAddIncome = async (income: Omit<Income, 'id'>) => {
    if (!activeOrgId || !user) return;
    const newId = 'inc_' + Math.random().toString(36).substring(2, 9);
    try {
      await setDoc(doc(db, `organizations/${activeOrgId}/incomes/${newId}`), {
        ...income,
        createdBy: user.uid
      });
    } catch (e) {
      console.error(e);
      triggerToast('Gagal menambah pendapatan', 'error');
    }
  };

  const handleDeleteIncome = async (id: string) => {
    if (!activeOrgId) return;
    try {
      await deleteDoc(doc(db, `organizations/${activeOrgId}/incomes/${id}`));
    } catch (e) {
      console.error(e);
    }
  };

  const handleUpdateIncome = async (updatedIncome: Income) => {
    if (!activeOrgId) return;
    try {
      await setDoc(doc(db, `organizations/${activeOrgId}/incomes/${updatedIncome.id}`), updatedIncome, { merge: true });
      triggerToast('Pendapatan berhasil diperbarui.', 'success');
    } catch (e) {
      console.error(e);
    }
  };

  const handleAddExpense = async (expense: Omit<Expense, 'id'>) => {
    if (!activeOrgId || !user) return;
    const newId = 'exp_' + Math.random().toString(36).substring(2, 9);
    try {
      await setDoc(doc(db, `organizations/${activeOrgId}/expenses/${newId}`), {
        ...expense,
        createdBy: user.uid
      });
      if (token && expense.date) {
        addEventToCalendar(
          token,
          `Pengeluaran: ${expense.title}`,
          `Sebesar Rp ${expense.amount.toLocaleString('id-ID')} (${expense.category} - ${expense.subcategory})`,
          expense.date
        ).catch(e => console.warn('Failed to sync to calendar:', e));
      }
    } catch (e) {
      console.error(e);
      triggerToast('Gagal menambah pengeluaran', 'error');
    }
  };

  const handleDeleteExpense = async (id: string) => {
    if (!activeOrgId) return;
    try {
      await deleteDoc(doc(db, `organizations/${activeOrgId}/expenses/${id}`));
    } catch (e) {
      console.error(e);
    }
  };

  const handleUpdateExpense = async (updatedExpense: Expense) => {
    if (!activeOrgId) return;
    try {
      await setDoc(doc(db, `organizations/${activeOrgId}/expenses/${updatedExpense.id}`), updatedExpense, { merge: true });
      triggerToast('Pengeluaran berhasil diperbarui.', 'success');
    } catch (e) {
      console.error(e);
    }
  };

  const handleAddGoal = async (goal: Omit<Goal, 'id'>) => {
    if (!activeOrgId || !user) return;
    const newId = 'goal_' + Math.random().toString(36).substring(2, 9);
    try {
      await setDoc(doc(db, `organizations/${activeOrgId}/goals/${newId}`), {
        ...goal,
        createdBy: user.uid
      });
      if (token && goal.targetDate) {
        addEventToCalendar(
          token,
          `Batas Waktu Target: ${goal.name}`,
          `Target: Rp ${goal.targetAmount.toLocaleString('id-ID')} dengan prioritas ${goal.priority}`,
          goal.targetDate
        ).catch(e => console.warn('Failed to sync to calendar:', e));
      }
    } catch (e) {
      console.error(e);
      triggerToast('Gagal menambah target keuangan', 'error');
    }
  };

  const handleDeleteGoal = async (id: string) => {
    if (!activeOrgId) return;
    try {
      await deleteDoc(doc(db, `organizations/${activeOrgId}/goals/${id}`));
    } catch (e) {
      console.error(e);
    }
  };

  const handleUpdateGoal = async (updatedGoal: Goal) => {
    if (!activeOrgId) return;
    try {
      await setDoc(doc(db, `organizations/${activeOrgId}/goals/${updatedGoal.id}`), updatedGoal, { merge: true });
      triggerToast('Target Keuangan berhasil diperbarui.', 'success');
    } catch (e) {
      console.error(e);
    }
  };

  const handleResetToSeed = () => {
    setConfirmModal({
      isOpen: true,
      title: 'Reset ke Data Contoh?',
      message: 'Apakah Anda ingin memulihkan data AdaptSaku kembali ke data contoh? Seluruh data yang sudah Anda buat akan ditimpa secara permanen.',
      actionText: 'Ya, Reset Data',
      type: 'warning',
      onConfirm: () => {
        setIncomes(INITIAL_INCOMES.map(x => ({ ...x })));
        setExpenses(INITIAL_EXPENSES.map(x => ({ ...x })));
        setGoals(INITIAL_GOALS.map(x => ({ ...x })));
        setActivePeriod('2026-05');
        setAiAdvice(null);
        setConfirmModal(null);
        triggerToast('AdaptSaku berhasil dipulihkan ke data contoh.', 'info');
      }
    });
  };

  const handleClearAll = () => {
    setConfirmModal({
      isOpen: true,
      title: 'Hapus Seluruh Data?',
      message: 'Apakah Anda yakin ingin mengosongkan data AdaptSaku? Seluruh transaksi pendapatan, pengeluaran, dan tujuan keuangan akan dihapus permanen.',
      actionText: 'Hapus Semua',
      type: 'danger',
      onConfirm: () => {
        setIncomes([]);
        setExpenses([]);
        setGoals([]);
        setAiAdvice(null);
        setConfirmModal(null);
        triggerToast('Seluruh data keuangan berhasil dihapus.', 'info');
      }
    });
  };

  const handleExportBackup = () => {
    try {
      const backupData = {
        version: 'adaptsaku_v3',
        timestamp: new Date().toISOString(),
        incomes,
        expenses,
        goals,
        customPeriods
      };
      const jsonString = `data:text/json;charset=utf-8,${encodeURIComponent(JSON.stringify(backupData, null, 2))}`;
      const downloadAnchor = document.createElement('a');
      downloadAnchor.setAttribute('href', jsonString);
      downloadAnchor.setAttribute('download', `adaptsaku_backup_${new Date().toISOString().split('T')[0]}.json`);
      document.body.appendChild(downloadAnchor);
      downloadAnchor.click();
      downloadAnchor.remove();
      triggerToast('Ekspor cadangan data berhasil diunduh!', 'success');
    } catch (err) {
      triggerToast('Gagal mengekspor cadangan data.', 'error');
    }
  };

  const handleImportFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const parsed = JSON.parse(event.target?.result as string);
        
        if (!parsed || (typeof parsed !== 'object')) {
          throw new Error('Format data tidak valid');
        }

        const validIncomes = Array.isArray(parsed.incomes) ? parsed.incomes : [];
        const validExpenses = Array.isArray(parsed.expenses) ? parsed.expenses : [];
        const validGoals = Array.isArray(parsed.goals) ? parsed.goals : [];
        const validCustomPeriods = Array.isArray(parsed.customPeriods) ? parsed.customPeriods : [];

        setConfirmModal({
          isOpen: true,
          title: 'Impor Cadangan Data?',
          message: `Apakah Anda yakin ingin mengimpor dari file cadangan ini? Aksi ini akan mengganti seluruh data yang ada saat ini secara permanen dengan ${validIncomes.length} pemasukan, ${validExpenses.length} pengeluaran, dan ${validGoals.length} tujuan keuangan.`,
          actionText: 'Ya, Impor & Timpa',
          type: 'warning',
          onConfirm: () => {
            setIncomes(validIncomes);
            setExpenses(validExpenses);
            setGoals(validGoals);
            if (validCustomPeriods.length) {
              setCustomPeriods(validCustomPeriods);
            }
            setConfirmModal(null);
            triggerToast('Impor data cadangan berhasil diaplikasikan!', 'success');
            if (fileInputRef.current) {
              fileInputRef.current.value = '';
            }
          }
        });

      } catch (err) {
        triggerToast('Gagal membaca file backup. Pastikan file berformat JSON AdaptSaku yang valid.', 'error');
        if (fileInputRef.current) {
          fileInputRef.current.value = '';
        }
      }
    };
    reader.readAsText(file);
  };

  const triggerSearchEdit = (period: string) => {
    setActivePeriod(period);
    setActiveTab('ringkasan');
    triggerToast(`Mengalihkan ke periode ${formatYearMonthLabel(period)} untuk melihat/mengedit.`, 'info');
  };

  if (needsAuth) {
    return (
      <div className={`min-h-screen flex items-center justify-center font-sans ${isDark ? 'bg-[#0F172A] text-slate-100' : 'bg-[#F8FAFC] text-slate-800'}`}>
        <div className="max-w-sm w-full p-8 text-center space-y-6 rounded-3xl border shadow-xl bg-slate-900/50 border-slate-800/80 backdrop-blur-md">
          <div className="w-16 h-16 bg-indigo-600 rounded-3xl mx-auto flex items-center justify-center text-white shadow-lg shadow-indigo-600/30 border border-indigo-500/30">
            <Wallet className="w-8 h-8" />
          </div>
          <div>
            <h1 className="text-2xl font-black mb-2 flex items-center justify-center gap-2">
              ADAPT<span className="text-indigo-500">SAKU</span>
            </h1>
            <p className="text-sm font-medium text-slate-400">Silakan masuk untuk mengelola rencana keuangan bersamamu serta sinkronisasi ke Google Calendar.</p>
          </div>
          <button 
            onClick={handleLogin}
            disabled={isLoggingIn}
            className="w-full py-4 bg-indigo-600 text-white rounded-2xl font-bold hover:bg-indigo-700 transition disabled:opacity-50"
          >
            {isLoggingIn ? 'Memproses...' : 'Masuk dengan Google'}
          </button>
        </div>
      </div>
    );
  }

  return (
    <div id="app_root" className={`min-h-screen flex flex-col font-sans selection:bg-indigo-500/30 selection:text-white transition-colors duration-300 ${isDark ? 'bg-[#0F172A] text-slate-100' : 'theme-light bg-[#F8FAFC] text-slate-800'}`}>
      {/* HEADER SECTION */}
      <header className="bg-slate-900/60 backdrop-blur-md border-b border-slate-800/80 sticky top-0 z-45">
        <div className="max-w-7xl mx-auto px-4 md:px-6 py-4 flex items-center justify-between gap-2">
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-10 h-10 sm:w-12 sm:h-12 bg-indigo-600 rounded-2xl flex items-center justify-center text-white shadow-lg shadow-indigo-600/30 border border-indigo-500/30 shrink-0">
              <Wallet className="w-5 h-5 sm:w-6 sm:h-6" />
            </div>
            <div className="min-w-0">
              <h1 className="text-lg sm:text-xl font-black text-white tracking-tight flex items-center gap-2 leading-none whitespace-nowrap overflow-hidden text-ellipsis">
                ADAPT<span className="text-indigo-500">SAKU</span>
                <span className="hidden sm:inline-block text-[10px] bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 px-2 py-0.5 rounded-full font-bold font-mono">
                  CALIBRATED
                </span>
              </h1>
              <p className="text-[9px] sm:text-[11px] text-slate-400 font-medium font-sans mt-1 whitespace-nowrap overflow-hidden text-ellipsis">
                Smart adaptive budgeting
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 sm:gap-3 shrink-0">
            <button
              id="btn_search_toggle"
              onClick={() => setIsSearchVisible(!isSearchVisible)}
              className={`p-2 sm:p-2.5 rounded-xl border transition-all cursor-pointer flex items-center justify-center shrink-0 ${
                isSearchVisible 
                  ? 'bg-indigo-600 border-indigo-500 text-white' 
                  : (isDark ? 'bg-slate-800 hover:bg-slate-700 border-slate-705 text-indigo-400 hover:text-indigo-300' : 'bg-white hover:bg-slate-100 border-slate-200 text-indigo-600 hover:text-indigo-700')
              }`}
              aria-label="Toggle Pencarian Global"
              title="Cari Catatan Keuangan"
            >
              <Search className="w-4 h-4 sm:w-5 sm:h-5" />
            </button>
            <button
              id="btn_settings_toggle"
              onClick={() => setIsSettingsOpen(true)}
              className={`p-2 sm:p-2.5 rounded-xl border transition-all cursor-pointer flex items-center justify-center shrink-0 ${
                isDark ? 'bg-slate-800 hover:bg-slate-700 border-slate-705 text-slate-300' : 'bg-white hover:bg-slate-100 border-slate-200 text-slate-700'
              }`}
              title="Pengaturan & Akun"
            >
              <Settings className="w-4 h-4 sm:w-5 sm:h-5" />
            </button>
          </div>
        </div>
      </header>

      {/* CORE WRAPPER SECTION */}
      <main className="flex-1 max-w-7xl mx-auto px-4 md:px-6 py-8 w-full space-y-8">
        {/* Info Notification / Help Banner / Collapsible Guide */}
        <div id="guide_banner_container" className={`rounded-[2rem] border shadow-xl overflow-hidden transition-all duration-300 ${
          isDark 
            ? 'bg-gradient-to-r from-slate-800/80 to-indigo-950/40 border-slate-705' 
            : 'bg-gradient-to-r from-white to-indigo-50/40 border-slate-200'
        }`}>
          <div 
            onClick={() => {
              const nextState = !showGuide;
              setShowGuide(nextState);
              localStorage.setItem('saku_show_guide', String(nextState));
            }}
            className={`p-5 flex items-center justify-between cursor-pointer select-none transition-all ${
              isDark ? 'hover:bg-slate-800/40' : 'hover:bg-slate-100/60'
            }`}
          >
            <div className="flex items-center gap-3">
              <span className={`p-2 rounded-xl border flex items-center justify-center shrink-0 transition-all ${
                isDark 
                  ? 'bg-indigo-500/15 text-indigo-400 border-indigo-500/20' 
                  : 'bg-indigo-50 text-indigo-600 border-indigo-100'
              }`}>
                <Info className="w-5 h-5" />
              </span>
              <div>
                <h3 className={`text-xs font-sans font-black tracking-widest uppercase flex flex-wrap items-center gap-2 transition-colors ${
                  isDark ? 'text-white' : 'text-slate-900'
                }`}>
                  Petunjuk Penggunaan Aplikasi AdaptSaku
                  <span className={`p-0.5 px-2 text-[8px] rounded-full uppercase font-black border transition-colors ${
                    isDark 
                      ? 'bg-indigo-500/10 text-indigo-300 border-indigo-500/20' 
                      : 'bg-indigo-50 text-indigo-700 border-indigo-200/60'
                  }`}>
                    Easy Guide
                  </span>
                </h3>
                <p className={`text-[10px] mt-0.5 font-medium transition-colors ${isDark ? 'text-slate-400' : 'text-slate-600'}`}>
                  {showGuide ? 'Klik untuk menyembunyikan bantuan' : 'Klik untuk melihat 3 langkah mudah mengelola keuangan'}
                </p>
              </div>
            </div>
            <button
              className={`p-1.5 rounded-lg transition-colors ${
                isDark ? 'hover:bg-slate-700/80 text-slate-400 hover:text-white' : 'hover:bg-slate-200 text-slate-600 hover:text-slate-900'
              }`}
              aria-label={showGuide ? 'Tutup Panduan' : 'Buka Panduan'}
            >
              {showGuide ? (
                <ChevronUp className="w-4 h-4" />
              ) : (
                <ChevronDown className="w-4 h-4" />
              )}
            </button>
          </div>

          <AnimatePresence initial={false}>
            {showGuide && (
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: 'auto', opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                transition={{ duration: 0.2, ease: 'easeInOut' }}
                className={`overflow-hidden border-t ${isDark ? 'border-slate-800' : 'border-slate-100'}`}
              >
                <div className={`p-6 pt-5 space-y-5 transition-colors ${isDark ? 'bg-slate-900/40 text-slate-300' : 'bg-slate-50/50 text-slate-800'}`}>
                   <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
                    <div className={`space-y-1.5 p-4.5 rounded-2xl flex flex-col justify-between border transition-all ${
                      isDark 
                        ? 'bg-slate-900/60 border-slate-800/80' 
                        : 'bg-white border-slate-200 shadow-sm'
                    }`}>
                      <div>
                        <div className="flex items-center gap-2 mb-2">
                          <span className={`w-6 h-6 rounded-full font-mono text-xs font-black flex items-center justify-center shrink-0 border transition-colors ${
                            isDark 
                              ? 'bg-pink-500/10 border-pink-500/20 text-pink-400' 
                              : 'bg-pink-50 border-pink-100 text-pink-600'
                          }`}>
                            1
                          </span>
                          <h4 className={`text-[10px] font-black uppercase tracking-widest transition-colors ${
                            isDark ? 'text-slate-200' : 'text-slate-800'
                          }`}>
                            Catat Keuanganmu
                          </h4>
                        </div>
                        <p className={`text-[11px] leading-relaxed font-medium transition-colors ${
                          isDark ? 'text-slate-400' : 'text-slate-600'
                        }`}>
                          Gunakan formulir untuk mendaftarkan <strong className={isDark ? 'text-slate-200 font-bold' : 'text-slate-900 font-black'}>Pendapatan</strong> harian/bulanan, mencatat <strong className={isDark ? 'text-slate-200 font-bold' : 'text-slate-900 font-black'}>Pengeluaran</strong> belanja, serta menyusun <strong className={isDark ? 'text-slate-200 font-bold' : 'text-slate-900 font-black'}>Tujuan Impian</strong> masa depan Anda.
                        </p>
                      </div>
                    </div>

                    <div className={`space-y-1.5 p-4.5 rounded-2xl flex flex-col justify-between border transition-all ${
                      isDark 
                        ? 'bg-slate-900/60 border-slate-800/80' 
                        : 'bg-white border-slate-200/75 shadow-sm'
                    }`}>
                      <div>
                        <div className="flex items-center gap-2 mb-2">
                          <span className={`w-6 h-6 rounded-full font-mono text-xs font-black flex items-center justify-center shrink-0 border transition-colors ${
                            isDark 
                              ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-400' 
                              : 'bg-emerald-50 border-emerald-100 text-emerald-600'
                          }`}>
                            2
                          </span>
                          <h4 className={`text-[10px] font-black uppercase tracking-widest transition-colors ${
                            isDark ? 'text-slate-200' : 'text-slate-800'
                          }`}>
                            Pantau Kesehatan Keuangan
                          </h4>
                        </div>
                        <p className={`text-[11px] leading-relaxed font-medium transition-colors ${
                          isDark ? 'text-slate-400' : 'text-slate-600'
                        }`}>
                          Lihat grafik lingkaran di menu <strong className={isDark ? 'text-slate-200 font-bold' : 'text-slate-900 font-black'}>Dashboard Keuangan</strong>. Sistem akan otomatis menghitung porsi belanja bulanan dan memberitahu jika kantong Anda dalam status aman atau waspada.
                        </p>
                      </div>
                    </div>

                    <div className={`space-y-1.5 p-4.5 rounded-2xl flex flex-col justify-between border transition-all ${
                      isDark 
                        ? 'bg-slate-900/60 border-slate-800/80' 
                        : 'bg-white border-slate-200/75 shadow-sm'
                    }`}>
                      <div>
                        <div className="flex items-center gap-2 mb-2">
                          <span className={`w-6 h-6 rounded-full font-mono text-xs font-black flex items-center justify-center shrink-0 border transition-colors ${
                            isDark 
                              ? 'bg-indigo-500/10 border-indigo-500/20 text-indigo-400' 
                              : 'bg-indigo-50 border-indigo-100 text-indigo-600'
                          }`}>
                            3
                          </span>
                          <h4 className={`text-[10px] font-black uppercase tracking-widest transition-colors ${
                            isDark ? 'text-slate-200' : 'text-slate-800'
                          }`}>
                            Simulasi Dan Tanya AI
                          </h4>
                        </div>
                        <p className={`text-[11px] leading-relaxed font-semibold transition-colors ${
                          isDark ? 'text-slate-400' : 'text-slate-600'
                        }`}>
                          Klik tab <strong className={isDark ? 'text-slate-200 font-bold' : 'text-slate-900 font-black'}>Asisten AI & Simulasi</strong>. Kamu bisa menggeser perkiraan sisa uang atau menekan tombol <strong className={isDark ? 'text-slate-200 font-bold' : 'text-slate-900 font-black'}>Rekomendasi Alokasi AI</strong> untuk meminta hitung otomatis dari asisten Gemini AI pintar.
                        </p>
                      </div>
                    </div>
                  </div>

                  {/* Disclaimer Section */}
                  <div className={`p-5 rounded-2xl border flex items-start gap-3 mt-4 text-xs leading-relaxed transition-all duration-300 ${
                    isDark 
                      ? 'bg-indigo-950/40 border-indigo-500/20 text-slate-300' 
                      : 'bg-indigo-50 border-indigo-200 text-slate-850 shadow-sm'
                  }`}>
                    <AlertCircle className={`w-5 h-5 shrink-0 mt-0.5 ${isDark ? 'text-indigo-400' : 'text-indigo-600'}`} />
                    <div>
                      <span className={`font-sans font-black text-[9.5px] uppercase tracking-widest block mb-1.5 ${
                        isDark ? 'text-indigo-300' : 'text-indigo-900'
                      }`}>
                        ⚠️ Pendukung Pembelajaran & Data Contoh
                      </span>
                      Data-data yang tertampil adalah contoh penggunaan aplikasi yang bisa Anda tiru untuk menginput <em className={isDark ? 'text-indigo-200 font-medium' : 'text-indigo-950 font-bold bg-indigo-100/30 px-1 py-0.5 rounded'}>cashflow</em> secara lebih baik dan aman. Jika ingin mulai melakukan pencatatan finansial murni milik Anda sendiri, seluruh data simulasi ini bisa dihapus tuntas kapan saja dengan menekan tombol <strong className={isDark ? 'text-rose-400 font-extrabold' : 'text-[#ff0000] font-extrabold tracking-wide hover:underline hover:text-red-700'}>Kosongkan Semua Data</strong> yang berada di bagian paling bawah halaman ini. Sebaliknya, apabila suatu saat Anda ingin menampilkan kembali data simulasi pembelajaran ini, Anda cukup menekan tombol <strong className={isDark ? 'text-indigo-400 font-extrabold' : 'text-indigo-600 font-extrabold tracking-wide hover:underline'}>Reset Data Contoh</strong>.
                    </div>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* MONTH SELECTOR TIMELINE CARD */}
        <div id="month_selector_card" className="w-full bg-slate-800/40 backdrop-blur-md rounded-[2rem] border border-slate-700/60 p-6 space-y-5">
          {/* Top Row: Period Title and Compact 1-line Custom Period Inline Form */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-slate-700/20">
            <div>
              <p className="text-[10px] font-sans font-black text-indigo-400 uppercase tracking-widest">
                Pilih Periode
              </p>
              <h2 className="text-xl font-sans font-black text-white leading-tight uppercase mt-0.5 flex items-center gap-2">
                <Calendar className="w-5 h-5 text-indigo-400" />
                Periode: {formatYearMonthLabel(activePeriod)}
              </h2>
            </div>

            {/* Compact Custom Period Inline Form */}
            <div className="flex items-center">
              {showAddPeriod ? (
                <form onSubmit={handleAddCustomPeriod} className="flex flex-row items-center gap-2 bg-slate-900/90 border border-indigo-500/30 rounded-xl p-1.5 px-3 shadow-xl relative z-25">
                  <span className="text-[10px] font-black text-indigo-400 uppercase tracking-widest select-none whitespace-nowrap hidden lg:inline">Target:</span>
                  <div className="flex items-center gap-1.5">
                    <select 
                      value={newPeriodYear} 
                      onChange={(e) => setNewPeriodYear(e.target.value)} 
                      className="bg-slate-950 border border-slate-700 text-indigo-300 font-mono text-xs font-black rounded-lg px-2 py-1 focus:outline-none cursor-pointer"
                    >
                      {Array.from({ length: 11 }, (_, i) => String(2020 + i)).map(y => (
                        <option key={y} value={y}>{y}</option>
                      ))}
                    </select>
                    <select 
                      value={newPeriodMonth} 
                      onChange={(e) => setNewPeriodMonth(e.target.value)} 
                      className="bg-slate-950 border border-slate-700 text-indigo-300 font-mono text-xs font-black rounded-lg px-2 py-1 focus:outline-none cursor-pointer"
                    >
                      {Object.keys(MONTH_NAMES).sort().map(m => (
                        <option key={m} value={m}>{MONTH_NAMES[m]}</option>
                      ))}
                    </select>
                  </div>
                  <div className="flex gap-1">
                    <button 
                      type="submit" 
                      className="px-3 py-1 bg-indigo-600 hover:bg-indigo-500 text-white font-sans font-black text-[10px] rounded-lg uppercase tracking-wider transition-all cursor-pointer shadow active:scale-95 whitespace-nowrap"
                    >
                      Tambah
                    </button>
                    <button 
                      type="button" 
                      onClick={() => setShowAddPeriod(false)}
                      className="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 font-sans font-black text-[10px] rounded-lg uppercase tracking-wider transition-all cursor-pointer whitespace-nowrap"
                    >
                      Batal
                    </button>
                  </div>
                </form>
              ) : (
                <button 
                  onClick={() => setShowAddPeriod(true)}
                  className="text-[10px] font-sans font-black text-indigo-400 hover:text-white uppercase tracking-widest bg-indigo-500/10 hover:bg-indigo-600/30 px-3 py-1.5 rounded-full border border-indigo-500/20 hover:border-indigo-500/40 flex items-center gap-1 transition-all cursor-pointer shadow active:scale-95 whitespace-nowrap"
                  title="Tambah periode baru di luar jangkauan bawaan"
                >
                  <span>+ Periode Kustom</span>
                </button>
              )}
            </div>
          </div>

          {/* Bottom Row / Full Width Timeline: Split by mobile select vs. desktop timeline */}
          <div className="w-full">
            {/* Mobile View: High Contrast Custom Dropdown + Navigation Steppers for small screens */}
            <div className="flex md:hidden items-center gap-2 w-full mt-1">
              <button
                type="button"
                disabled={uniquePeriods.indexOf(activePeriod) === 0}
                onClick={() => {
                  const idx = uniquePeriods.indexOf(activePeriod);
                  if (idx > 0) setActivePeriod(uniquePeriods[idx - 1]);
                }}
                className="p-3 bg-slate-900/40 border border-slate-800 text-slate-400 hover:text-white disabled:opacity-30 disabled:pointer-events-none rounded-xl transition-all cursor-pointer flex items-center justify-center shrink-0 active:scale-95 shadow-md"
                title="Bulan Sebelumnya"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>

              <div className="relative flex-1">
                <select
                  value={activePeriod}
                  onChange={(e) => setActivePeriod(e.target.value)}
                  className={`w-full font-sans font-black text-xs py-3.5 px-4 pr-10 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 cursor-pointer appearance-none uppercase select-custom shadow-inner border transition-colors ${
                    isDark ? 'bg-indigo-600/20 border-indigo-500/50 text-indigo-300' : 'bg-indigo-600 border-indigo-500 text-white shadow-md'
                  }`}
                >
                  {uniquePeriods.map((p) => {
                    const isFuture = p !== 'older_than_year' && p > '2026-05';
                    const hasData = p === 'older_than_year'
                      ? incomes.some(i => i.date && isOlderThanYear(i.date.substring(0, 7))) || expenses.some(e => e.date && isOlderThanYear(e.date.substring(0, 7)))
                      : incomes.some(i => i.date?.startsWith(p)) || expenses.some(e => e.date?.startsWith(p));
                    let suffix = '';
                    if (isFuture) suffix = ' [RENCANA]';
                    else if (hasData) suffix = ' •';
                    return (
                      <option key={p} value={p} className="bg-slate-950 text-slate-100 font-mono">
                        {formatYearMonthLabel(p).toUpperCase()}{suffix}
                      </option>
                    );
                  })}
                </select>
                <div className={`absolute inset-y-0 right-0 flex items-center pr-3.5 pointer-events-none transition-colors ${
                  isDark ? 'text-indigo-400' : 'text-indigo-200'
                }`}>
                  <ChevronDown className="w-4 h-4" />
                </div>
              </div>

              <button
                type="button"
                disabled={uniquePeriods.indexOf(activePeriod) === uniquePeriods.length - 1}
                onClick={() => {
                  const idx = uniquePeriods.indexOf(activePeriod);
                  if (idx < uniquePeriods.length - 1) setActivePeriod(uniquePeriods[idx + 1]);
                }}
                className="p-3 bg-slate-900/40 border border-slate-800 text-slate-400 hover:text-white disabled:opacity-30 disabled:pointer-events-none rounded-xl transition-all cursor-pointer flex items-center justify-center shrink-0 active:scale-95 shadow-md"
                title="Bulan Berikutnya"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>

            {/* Tablet & Desktop View: Desktop Horizontal Timeline Row (With Compact Left/Right Arrow Controls) */}
            <div className="hidden md:flex items-center gap-2.5 w-full">
              {/* Nav Left Button */}
              <button
                type="button"
                onClick={() => scrollTimeline('left')}
                className="p-2.5 bg-slate-900/70 hover:bg-indigo-600 border border-slate-800 hover:border-indigo-500 text-slate-400 hover:text-white rounded-xl transition-all cursor-pointer flex items-center justify-center shrink-0 active:scale-95 shadow"
                title="Geser Kiri"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>

              {/* Scrollable Container with Ref */}
              <div 
                ref={timelineRef} 
                className="flex-1 flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none scroll-smooth"
              >
                {uniquePeriods.map((p) => {
                  const isActive = p === activePeriod;
                  const isFuture = p !== 'older_than_year' && p > '2026-05';
                  const hasData = p === 'older_than_year'
                    ? incomes.some(i => i.date && isOlderThanYear(i.date.substring(0, 7))) || expenses.some(e => e.date && isOlderThanYear(e.date.substring(0, 7)))
                    : incomes.some(i => i.date?.startsWith(p)) || expenses.some(e => e.date?.startsWith(p));
                  return (
                    <button
                      key={p}
                      onClick={() => setActivePeriod(p)}
                      className={`px-4 py-2.5 rounded-xl text-xs font-black uppercase tracking-wider transition-all duration-300 flex items-center gap-1.5 shrink-0 whitespace-nowrap cursor-pointer border active:scale-95 ${
                        isActive
                          ? 'active-period bg-indigo-600 text-white shadow-lg border-indigo-500/30 ' + (isDark ? 'shadow-indigo-900/30' : 'shadow-indigo-600/30')
                          : isDark ? 'bg-slate-900/40 border-slate-800 text-slate-400 hover:text-white hover:border-slate-700' : 'bg-white border-slate-200 text-slate-500 hover:bg-slate-50 hover:text-slate-900'
                      }`}
                    >
                      <span>{formatYearMonthLabel(p)}</span>
                      {isFuture && (
                        <span className="text-[8px] tracking-normal font-sans font-black bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 px-1 py-0.5 rounded uppercase font-bold">
                          Rencana
                        </span>
                      )}
                      {!hasData && !isFuture && (
                        <span className="w-1.5 h-1.5 bg-slate-600 rounded-full" />
                      )}
                      {hasData && (
                        <span className="w-1.5 h-1.5 bg-emerald-400 text-emerald-400 rounded-full animate-pulse shrink-0" />
                      )}
                    </button>
                  );
                })}
              </div>

              {/* Nav Right Button */}
              <button
                type="button"
                onClick={() => scrollTimeline('right')}
                className="p-2.5 bg-slate-900/70 hover:bg-indigo-600 border border-slate-800 hover:border-indigo-500 text-slate-400 hover:text-white rounded-xl transition-all cursor-pointer flex items-center justify-center shrink-0 active:scale-95 shadow"
                title="Geser Kanan"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Planning helper section if selected month is empty */}
          {activePeriod !== 'older_than_year' && filteredIncomes.length === 0 && filteredExpenses.length === 0 && (
            <div id="planning_helper_banner" className="flex flex-col sm:flex-row sm:items-center justify-between p-4 rounded-2xl bg-indigo-500/10 border border-indigo-500/20 gap-4 mt-2">
              <div className="flex items-start gap-3">
                <AlertCircle className="w-5 h-5 text-indigo-400 shrink-0 mt-0.5 animate-bounce-soft" />
                <div>
                  <h4 className="text-xs font-bold text-slate-200">
                    Belum Ada Data Keuangan di {formatYearMonthLabel(activePeriod)}
                  </h4>
                  <p className="text-[11px] text-slate-400 mt-0.5 leading-relaxed">
                    Mulai rancang dan susun target pengeluaran Anda dengan menduplikasi seluruh anggaran aktif dari periode bulan sebelumnya secara otomatis.
                  </p>
                </div>
              </div>
              <button
                onClick={handleCopyPreviousPeriod}
                className="px-4 py-2 h-9 bg-indigo-600 hover:bg-indigo-700 text-white font-sans text-xs font-black uppercase tracking-wider rounded-lg border border-indigo-500 flex items-center gap-1.5 transition whitespace-nowrap cursor-pointer shadow-md shrink-0"
              >
                <Plus className="w-3.5 h-3.5" />
                Salin Rencana Bulan Lalu
              </button>
            </div>
          )}
        </div>

        {/* GLOBAL SEARCH & RESULTS PANEL */}
        <AnimatePresence>
          {isSearchVisible && (
            <motion.div 
              initial={{ height: 0, opacity: 0, scale: 0.95 }}
              animate={{ height: 'auto', opacity: 1, scale: 1 }}
              exit={{ height: 0, opacity: 0, scale: 0.95 }}
              transition={{ duration: 0.2, ease: 'easeInOut' }}
              className="overflow-hidden"
            >
              <div id="global_search_section" className={`p-4 sm:p-6 mb-4 sm:mb-6 rounded-[1.5rem] sm:rounded-[2rem] border shadow-xl space-y-4 ${
                isDark 
                  ? 'bg-slate-900/40 border-slate-705/80' 
                  : 'bg-white border-slate-200 shadow-sm'
              }`}>
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div className="flex items-center gap-2.5">
                    <span className={`p-2 rounded-xl border flex items-center justify-center shrink-0 ${
                      isDark 
                        ? 'bg-indigo-500/15 text-indigo-400 border-indigo-500/20' 
                        : 'bg-indigo-50 text-indigo-600 border-indigo-100'
                    }`}>
                      <Search className="w-5 h-5" />
                    </span>
                    <div>
                      <h3 className={`text-xs font-sans font-black uppercase tracking-widest ${
                        isDark ? 'text-indigo-400' : 'text-indigo-600'
                      }`}>
                        Cari Catatan Keuangan
                      </h3>
                      <p className={`text-[10px] font-medium ${isDark ? 'text-slate-450' : 'text-slate-600'}`}>
                        Cari nama transaksi, subkategori, atau tanggal di semua periode anggaran
                      </p>
                    </div>
                  </div>

                  <div className="relative flex-1 max-w-md">
                    <Search className={`absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 ${isDark ? 'text-slate-500' : 'text-slate-400'}`} />
                    <input
                      id="global_search_input"
                      type="text"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      placeholder="Ketik kata kunci (cth: Gaji, Kopi, Kos, Beli, Reksadana)..."
                      className={`w-full pl-10 pr-10 py-2.5 rounded-xl text-xs font-bold focus:outline-none transition-all duration-300 border ${
                        isDark
                          ? 'bg-slate-950/60 border-slate-800 text-slate-100 focus:border-indigo-500 placeholder-slate-500'
                          : 'bg-slate-50 border-slate-200 text-slate-800 focus:border-indigo-500 placeholder-slate-400'
                      }`}
                    />
                    {searchQuery && (
                      <button
                        type="button"
                        onClick={() => setSearchQuery('')}
                        className={`absolute right-3.5 top-1/2 -translate-y-1/2 leading-none p-1 rounded hover:bg-slate-800/80 hover:text-white transition-colors text-xs font-bold text-slate-400`}
                      >
                        ✕
                      </button>
                    )}
                  </div>
                </div>

                <AnimatePresence>
                  {searchResults && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      exit={{ opacity: 0, height: 0 }}
                      className="overflow-hidden pt-2"
                    >
                <div className={`p-5 rounded-2xl border space-y-5 max-h-[28rem] overflow-y-auto ${
                  isDark ? 'bg-slate-950/50 border-slate-800/60' : 'bg-slate-50/60 border-slate-200'
                }`}>
                  {searchResults.incomes.length === 0 && searchResults.expenses.length === 0 && searchResults.goals.length === 0 ? (
                    <div className="text-center py-6 text-slate-500 text-xs font-medium">
                      Tidak ditemukan hasil untuk pencarian "{searchQuery}"
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {/* INCOMES MATCH */}
                      {searchResults.incomes.length > 0 && (
                        <div className="space-y-2">
                          <h4 className={`text-[10px] font-sans font-black uppercase tracking-widest flex items-center gap-1.5 ${
                            isDark ? 'text-emerald-400' : 'text-emerald-700 font-extrabold'
                          }`}>
                            Pemasukan Terekam ({searchResults.incomes.length})
                          </h4>
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                            {searchResults.incomes.map(inc => {
                              const ym = inc.date ? inc.date.substring(0, 7) : '';
                              return (
                                <div key={inc.id} className={`p-3 rounded-xl border flex justify-between items-center text-xs transition-all ${
                                  isDark ? 'bg-slate-900/50 border-slate-800/80 hover:border-slate-700' : 'bg-white border-slate-200 hover:border-slate-300 shadow-sm'
                                }`}>
                                  <div>
                                    <p className={`font-bold ${isDark ? 'text-white' : 'text-slate-800'}`}>{inc.source}</p>
                                    <p className="text-[10px] text-slate-400 mt-1 flex items-center gap-1.5">
                                      <span className={`px-1 rounded bg-emerald-555/5 text-emerald-400 text-[9px] font-mono border border-emerald-500/10 uppercase`}>
                                        {formatYearMonthLabel(ym)}
                                      </span>
                                      <span>•</span>
                                      <span>{inc.category === 'primary' ? 'Utama' : 'Sampingan'}</span>
                                    </p>
                                  </div>
                                  <div className="text-right flex items-center gap-3">
                                    <span className="font-mono font-black text-emerald-450 text-emerald-400">
                                      + {new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', minimumFractionDigits: 0 }).format(inc.amount)}
                                    </span>
                                    <button
                                      onClick={() => triggerSearchEdit(ym)}
                                      className={`px-2.5 py-1 text-[10px] font-sans font-black uppercase rounded-lg border transition-all hover:scale-95 cursor-pointer ${
                                        isDark 
                                          ? 'bg-slate-800 hover:bg-slate-700 text-indigo-300 border-slate-755' 
                                          : 'bg-indigo-50 hover:bg-indigo-100 text-indigo-600 border-indigo-100 shadow-sm'
                                      }`}
                                    >
                                      Buka & Edit
                                    </button>
                                  </div>
                                </div>
                              );
                            })}
                          </div>
                        </div>
                      )}

                      {/* EXPENSES MATCH */}
                      {searchResults.expenses.length > 0 && (
                        <div className="space-y-2 pt-2 border-t border-slate-800/20">
                          <h4 className={`text-[10px] font-sans font-black uppercase tracking-widest flex items-center gap-1.5 ${
                            isDark ? 'text-pink-400' : 'text-pink-700 font-extrabold'
                          }`}>
                            Pengeluaran Belanja ({searchResults.expenses.length})
                          </h4>
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                            {searchResults.expenses.map(exp => {
                              const ym = exp.date ? exp.date.substring(0, 7) : '';
                              return (
                                <div key={exp.id} className={`p-3 rounded-xl border flex justify-between items-center text-xs transition-all ${
                                  isDark ? 'bg-slate-900/50 border-slate-800/80 hover:border-slate-700' : 'bg-white border-slate-200 hover:border-slate-300 shadow-sm'
                                }`}>
                                  <div>
                                    <p className={`font-bold ${isDark ? 'text-white' : 'text-slate-800'}`}>{exp.title}</p>
                                    <p className="text-[10px] text-slate-400 mt-1 flex items-center gap-1.5 flex-wrap">
                                      <span className={`px-1 rounded bg-indigo-555/5 text-indigo-400 text-[9px] font-mono border border-indigo-500/10 uppercase`}>
                                        {formatYearMonthLabel(ym)}
                                      </span>
                                      <span>•</span>
                                      <span>{exp.subcategory}</span>
                                      <span>•</span>
                                      <span className="capitalize">{exp.category}</span>
                                    </p>
                                  </div>
                                  <div className="text-right flex items-center gap-3">
                                    <span className="font-mono font-black text-pink-400">
                                      - {new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', minimumFractionDigits: 0 }).format(exp.amount)}
                                    </span>
                                    <button
                                      onClick={() => triggerSearchEdit(ym)}
                                      className={`px-2.5 py-1 text-[10px] font-sans font-black uppercase rounded-lg border transition-all hover:scale-95 cursor-pointer ${
                                        isDark 
                                          ? 'bg-slate-800 hover:bg-slate-700 text-indigo-300 border-slate-755' 
                                          : 'bg-indigo-50 hover:bg-indigo-100 text-indigo-600 border-indigo-100 shadow-sm'
                                      }`}
                                    >
                                      Buka & Edit
                                    </button>
                                  </div>
                                </div>
                              );
                            })}
                          </div>
                        </div>
                      )}

                      {/* GOALS MATCH */}
                      {searchResults.goals.length > 0 && (
                        <div className="space-y-2 pt-2 border-t border-slate-800/20">
                          <h4 className={`text-[10px] font-sans font-black uppercase tracking-widest flex items-center gap-1.5 ${
                            isDark ? 'text-indigo-400' : 'text-indigo-700 font-extrabold'
                          }`}>
                            Tujuan Finansial ({searchResults.goals.length})
                          </h4>
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                            {searchResults.goals.map(gl => {
                              return (
                                <div key={gl.id} className={`p-3 rounded-xl border flex justify-between items-center text-xs transition-all ${
                                  isDark ? 'bg-slate-900/50 border-slate-800/80 hover:border-slate-700' : 'bg-white border-slate-200 hover:border-slate-300 shadow-sm'
                                }`}>
                                  <div>
                                    <p className={`font-bold ${isDark ? 'text-white' : 'text-slate-800'}`}>{gl.name}</p>
                                    <p className="text-[10px] text-slate-400 mt-1 flex items-center gap-1.5 flex-wrap">
                                      <span className={`px-1 py-0.5 rounded text-[9px] font-black uppercase ${
                                        gl.priority === 'high' ? 'bg-rose-500/10 text-rose-450' :
                                        gl.priority === 'medium' ? 'bg-amber-500/10 text-amber-500' : 'bg-slate-500/10 text-slate-400'
                                      }`}>
                                        Prioritas: {gl.priority}
                                      </span>
                                      <span>•</span>
                                      <span>Target: {gl.targetDate}</span>
                                    </p>
                                  </div>
                                  <div className="text-right flex items-center gap-3">
                                    <span className="font-mono font-black text-indigo-400">
                                      {new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', minimumFractionDigits: 0 }).format(gl.targetAmount)}
                                    </span>
                                    <button
                                      onClick={() => {
                                        setActiveTab('ringkasan');
                                        const formElem = document.getElementById('financial_forms_container');
                                        if (formElem) formElem.scrollIntoView({ behavior: 'smooth' });
                                        triggerToast('Membuka tab ringkasan untuk mengelola tujuan keuangan.', 'info');
                                      }}
                                      className={`px-2.5 py-1 text-[10px] font-sans font-black uppercase rounded-lg border transition-all hover:scale-95 cursor-pointer ${
                                        isDark 
                                          ? 'bg-slate-800 hover:bg-slate-700 text-indigo-300 border-slate-755' 
                                          : 'bg-indigo-50 hover:bg-indigo-100 text-indigo-600 border-indigo-100 shadow-sm'
                                      }`}
                                    >
                                      Buka & Edit
                                    </button>
                                  </div>
                                </div>
                              );
                            })}
                          </div>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* TOP VIEW NAV TAB CLUTTER */}
        <div className="flex bg-slate-800/80 border border-slate-700/60 p-1 rounded-2xl max-w-sm">
          <button
            id="tab_view_ringkasan"
            onClick={() => setActiveTab('ringkasan')}
            className={`flex-1 py-3 text-center font-sans text-xs font-black rounded-xl transition-all tracking-wide ${
              activeTab === 'ringkasan'
                ? 'bg-slate-700 text-white shadow-sm border border-slate-600'
                : 'text-slate-400 hover:text-slate-100'
            }`}
          >
            Dashboard Keuangan
          </button>
          <button
            id="tab_view_simulasi"
            onClick={() => setActiveTab('simulasi')}
            className={`flex-1 py-3 text-center font-sans text-xs font-black rounded-xl transition-all tracking-wide flex items-center justify-center gap-1.5 ${
              activeTab === 'simulasi'
                ? 'bg-indigo-600 text-white shadow-sm border border-indigo-500/30'
                : 'text-slate-400 hover:text-slate-105'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5 text-indigo-300" />
            Asisten AI & Simulasi
          </button>
        </div>

        {/* MAIN BODY CONTAINER WITH RENDERING SWITCHES AND ANIMATIONS */}
        <AnimatePresence mode="wait">
          {activeTab === 'ringkasan' ? (
            <motion.div
              key={`ringkasan_${activePeriod}`}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.2 }}
              className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start"
            >
              {/* Left Column: Metrics & Charts */}
              <div className="lg:col-span-12 xl:col-span-7 space-y-8">
                <Dashboard 
                  incomes={filteredIncomes}
                  expenses={filteredExpenses}
                  allIncomes={incomes}
                  allExpenses={expenses}
                  goals={goals}
                  aiAdvice={aiAdvice}
                  uniquePeriods={uniquePeriods}
                  activePeriod={activePeriod}
                  isDark={isDark}
                />
              </div>

              {/* Right Column: Financial Entry Forms */}
              <div className="lg:col-span-12 xl:col-span-5">
                <FinancialForms
                  incomes={filteredIncomes}
                  expenses={filteredExpenses}
                  goals={filteredGoals}
                  onAddIncome={handleAddIncome}
                  onDeleteIncome={handleDeleteIncome}
                  onUpdateIncome={handleUpdateIncome}
                  onAddExpense={handleAddExpense}
                  onDeleteExpense={handleDeleteExpense}
                  onUpdateExpense={handleUpdateExpense}
                  onAddGoal={handleAddGoal}
                  onDeleteGoal={handleDeleteGoal}
                  onUpdateGoal={handleUpdateGoal}
                  activePeriod={activePeriod}
                  isDark={isDark}
                />
              </div>
            </motion.div>
          ) : (
            <motion.div
              key={`simulasi_${activePeriod}`}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.2 }}
            >
              <AISimulator
                incomes={filteredIncomes}
                expenses={filteredExpenses}
                allIncomes={incomes}
                allExpenses={expenses}
                goals={goals}
                aiAdvice={aiAdvice}
                onSetAIAdvice={setAiAdvice}
                activePeriod={activePeriod}
                isDark={isDark}
              />
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* SEED & CLEANUP CONTROL CENTER */}
      <section className="max-w-7xl mx-auto px-4 md:px-6 mt-16 pb-2 w-full flex flex-col items-center justify-center gap-4">
        <div className="p-6 bg-slate-900/40 border border-slate-800/80 rounded-[2rem] w-full max-w-xl text-center shadow-lg">
          <h4 className="text-[11px] font-sans font-black uppercase text-slate-400 tracking-widest mb-3">
            Pusat Kendali Data Transaksi AdaptSaku
          </h4>
          <p className="text-xs text-slate-400 mb-5 leading-relaxed font-sans font-medium">
            Butuh mereset ulang atau ingin memulai dari awal dengan data kosong? Gunakan kendali cepat di bawah ini.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
            <button
              id="btn_reseed"
              onClick={handleResetToSeed}
              className="w-full sm:w-auto text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 px-5 py-3 rounded-2xl text-[11px] font-black uppercase tracking-wider flex items-center justify-center gap-2 transition-all border border-slate-700/80 hover:border-slate-600 cursor-pointer shadow-lg active:scale-95"
              title="Reset ke data contoh"
            >
              <RefreshCw className="w-3.5 h-3.5 text-indigo-400" />
              Reset Data Contoh
            </button>
            <button
               id="btn_clear_all"
               onClick={handleClearAll}
               className="w-full sm:w-auto text-slate-400 hover:text-rose-400 bg-slate-850 hover:bg-slate-800 px-5 py-3 rounded-2xl text-[11px] font-black uppercase tracking-wider flex items-center justify-center gap-2 transition-all border border-slate-800 hover:border-rose-950/30 cursor-pointer shadow-lg active:scale-95"
               title="Hapus semua transaksi dan sisa anggaran"
            >
              <Trash2 className="w-4 h-4 text-rose-500" />
              Kosongkan Semua Data
            </button>
          </div>

          <div className="border-t border-slate-800/60 my-5 pt-5">
            <h5 className="text-[10px] font-sans font-black uppercase text-slate-400 tracking-wider mb-2.5 flex items-center justify-center gap-1.5">
              <Database className="w-3.5 h-3.5 text-indigo-400" />
              Ekspor & Impor Cadangan (Backup & Restore)
            </h5>
            <p className="text-[10px] text-slate-500 mb-4 leading-relaxed font-sans">
              Amankan data Anda secara lokal atau migrasikan ke perangkat lain dengan format file cadangan JSON standar.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
              <button
                onClick={handleExportBackup}
                className="w-full sm:w-auto text-slate-305 hover:text-white bg-indigo-950/40 hover:bg-indigo-900/30 px-5 py-3 rounded-2xl text-[11px] font-black uppercase tracking-wider flex items-center justify-center gap-2 transition-all border border-indigo-500/20 hover:border-indigo-500/60 cursor-pointer shadow-lg active:scale-95"
                title="Unduh seluruh data anggaran dan rencana saat ini ke dalam format file JSON"
              >
                <Download className="w-3.5 h-3.5 text-indigo-400" />
                Ekspor data JSON
              </button>
              <button
                onClick={() => fileInputRef.current?.click()}
                className="w-full sm:w-auto text-slate-305 hover:text-white bg-slate-800 hover:bg-slate-750 px-5 py-3 rounded-2xl text-[11px] font-black uppercase tracking-wider flex items-center justify-center gap-2 transition-all border border-slate-700 hover:border-slate-500 cursor-pointer shadow-lg active:scale-95"
                title="Muat data keuangan dari file cadangan JSON yang valid"
              >
                <Upload className="w-3.5 h-3.5 text-emerald-400" />
                Impor data JSON
              </button>
              <input 
                type="file" 
                ref={fileInputRef} 
                onChange={handleImportFileChange} 
                accept=".json" 
                className="hidden" 
              />
            </div>
          </div>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="bg-slate-950/40 border-t border-slate-800/80 py-8 mt-16 text-center text-xs text-slate-500 font-sans tracking-widest uppercase">
        <div className="max-w-7xl mx-auto px-4">
          <p>© 2026 ADAPTSAKU. Power boosted with Gemini by Google.</p>
        </div>
      </footer>

      {/* GLOBAL TOAST NOTIFICATION */}
      <AnimatePresence>
        {toast.show && (
          <motion.div
            initial={{ opacity: 0, y: 50, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.95 }}
            className="fixed bottom-6 left-1/2 -translate-x-1/2 z-55 w-[90%] max-w-sm pointer-events-auto"
          >
            <div className={`flex items-start gap-3 p-4 rounded-2xl border shadow-xl backdrop-blur-md ${
              toast.type === 'success' 
                ? 'bg-[#064e3b]/95 border-emerald-500/30 text-emerald-200'
                : toast.type === 'error'
                ? 'bg-[#4c0519]/95 border-rose-500/30 text-rose-200'
                : 'bg-indigo-950/95 border-indigo-500/30 text-indigo-300'
            }`}>
              <div className="shrink-0 mt-0.5">
                {toast.type === 'success' && (
                  <div className="w-5 h-5 rounded-full bg-emerald-500/15 flex items-center justify-center border border-emerald-500/20 text-emerald-400 font-mono text-[10px] font-black">
                    ✓
                  </div>
                )}
                {toast.type === 'error' && (
                  <AlertCircle className="w-5 h-5 text-rose-400" />
                )}
                {toast.type === 'info' && (
                  <Info className="w-5 h-5 text-indigo-400" />
                )}
              </div>
              <div className="flex-1">
                <p className="text-sm font-black tracking-tight text-white leading-none">
                  {toast.type === 'success' ? 'Sukses' : toast.type === 'error' ? 'Pemberitahuan' : 'Informasi'}
                </p>
                <p className="text-[11px] text-slate-300 mt-1 leading-relaxed font-sans font-semibold">
                  {toast.message}
                </p>
              </div>
              <button 
                onClick={() => setToast(prev => ({ ...prev, show: false }))}
                className="text-slate-450 hover:text-slate-200 text-[10px] font-black leading-none shrink-0 ml-1 bg-slate-900/40 p-1 rounded hover:bg-slate-900 transition-all cursor-pointer"
              >
                ✕
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* CUSTOM BEAUTIFUL CONFIRMATION MODAL OVERLAY */}
      <AnimatePresence>
        {confirmModal && confirmModal.isOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setConfirmModal(null)}
              className="absolute inset-0 bg-slate-950/80 backdrop-blur-sm"
            />
            {/* Modal Box */}
            <motion.div
              id="confirm_modal_box"
              initial={{ scale: 0.95, opacity: 0, y: 15 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.95, opacity: 0, y: 15 }}
              className="relative w-full max-w-md bg-slate-900/95 border border-slate-800 rounded-[2.25rem] p-6 shadow-2xl z-10 overflow-hidden"
            >
              {/* Accented glow bar depending on modal type */}
              <div className={`absolute top-0 inset-x-0 h-1.5 ${
                confirmModal.type === 'danger' ? 'bg-rose-500' :
                confirmModal.type === 'warning' ? 'bg-amber-500' : 'bg-indigo-600'
              }`} />

              <div className="flex items-start gap-4 mt-2">
                <div className={`w-11 h-11 rounded-2xl flex items-center justify-center shrink-0 border ${
                  confirmModal.type === 'danger' ? 'bg-rose-500/10 border-rose-500/20 text-rose-400 animate-pulse' :
                  confirmModal.type === 'warning' ? 'bg-amber-500/10 border-amber-500/20 text-amber-500' : 'bg-indigo-500/10 border-indigo-500/20 text-indigo-400'
                }`}>
                  {confirmModal.type === 'danger' ? (
                    <Trash2 className="w-5 h-5" />
                  ) : confirmModal.type === 'warning' ? (
                    <AlertCircle className="w-5 h-5" />
                  ) : (
                    <Calendar className="w-5 h-5" />
                  )}
                </div>

                <div className="flex-1">
                  <h3 className="text-lg font-black tracking-tight text-white theme-light:text-slate-900 leading-tight uppercase">
                    {confirmModal.title}
                  </h3>
                  <p className="text-xs text-slate-450 theme-light:text-slate-600 mt-2 leading-relaxed font-sans font-medium">
                    {confirmModal.message}
                  </p>
                </div>
              </div>

              <div className="flex items-center justify-end gap-3 mt-8">
                <button
                  onClick={() => setConfirmModal(null)}
                  className="px-4 py-2.5 rounded-xl text-xs font-black uppercase tracking-wider bg-slate-800 text-slate-300 hover:text-white dark:bg-slate-800 dark:hover:bg-slate-750 border border-slate-700 hover:border-slate-600 transition-all cursor-pointer theme-light:bg-slate-150 theme-light:text-slate-705 theme-light:border-slate-250 theme-light:hover:bg-slate-200"
                >
                  Batal
                </button>
                <button
                  onClick={confirmModal.onConfirm}
                  className={`px-5 py-2.5 rounded-xl text-xs font-black uppercase tracking-wider text-white shadow-lg transition-all cursor-pointer ${
                    confirmModal.type === 'danger' ? 'bg-rose-600 hover:bg-rose-700 shadow-rose-950/20' :
                    confirmModal.type === 'warning' ? 'bg-amber-605 hover:bg-amber-700 shadow-amber-950/20' :
                    'bg-indigo-605 hover:bg-indigo-700 shadow-indigo-950/20'
                  }`}
                >
                  {confirmModal.actionText}
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
      {/* SETTINGS DRAWER */}
      <AnimatePresence>
        {isSettingsOpen && (
          <div className="fixed inset-0 z-50 flex justify-end">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsSettingsOpen(false)}
              className="absolute inset-0 bg-slate-950/50 backdrop-blur-sm"
            />
            <motion.div
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className={`relative w-full max-w-sm h-full flex flex-col shadow-2xl z-10 overflow-auto ${
                isDark ? 'bg-slate-900 border-l border-slate-800' : 'bg-white border-l border-slate-200'
              }`}
            >
              <div className={`p-6 border-b flex items-center justify-between ${isDark ? 'border-slate-800' : 'border-slate-200'}`}>
                <h3 className="text-lg font-black uppercase tracking-wider flex items-center gap-2">
                  <Settings className="w-5 h-5 text-indigo-500" />
                  Pengaturan
                </h3>
                <button 
                  onClick={() => setIsSettingsOpen(false)}
                  className={`p-2 rounded-xl transition-colors cursor-pointer ${isDark ? 'hover:bg-slate-800 text-slate-400' : 'hover:bg-slate-100 text-slate-500'}`}
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="p-6 flex-1 flex flex-col gap-8">
                
                {/* 1. Theme Toggle */}
                <div className="space-y-3">
                  <h4 className="text-xs font-black uppercase tracking-widest text-slate-500">Profil & Tampilan</h4>
                  <div className={`p-4 rounded-2xl border ${isDark ? 'bg-slate-800/50 border-slate-700' : 'bg-slate-50 border-slate-200'}`}>
                    <label className="block text-xs font-semibold mb-2">Custom ID Pengguna Unik</label>
                    <div className="flex gap-2">
                       <input 
                         type="text" 
                         value={customId} 
                         onChange={e => setCustomId(e.target.value)} 
                         placeholder="Buat username unik (harus 3 huruf/angka)..." 
                         className={`flex-1 text-sm h-10 px-3 rounded focus:outline-none focus:border-indigo-500 border ${isDark ? 'bg-slate-900 border-slate-700 text-slate-200' : 'bg-white border-slate-300'}`} 
                       />
                       <button onClick={handleUpdateCustomId} className="h-10 px-4 bg-indigo-600 text-white text-xs font-bold rounded hover:bg-indigo-700 transition cursor-pointer">Simpan</button>
                    </div>
                    <p className={`text-[10px] mt-2 ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>ID ini digunakan saat mengundang Anda ke organisasi.</p>
                  </div>
                  
                  <button
                    onClick={() => setIsDark(!isDark)}
                    className={`w-full flex items-center justify-between p-4 rounded-2xl border transition-all cursor-pointer ${
                      isDark ? 'bg-slate-800/50 border-slate-700 hover:bg-slate-800' : 'bg-slate-50 border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    <span className="font-semibold text-sm">Mode Tampilan</span>
                    {isDark ? (
                      <span className="flex items-center gap-2 text-indigo-300 bg-indigo-500/20 px-3 py-1.5 rounded-lg text-xs font-bold">
                        <Moon className="w-4 h-4" /> Gelap
                      </span>
                    ) : (
                      <span className="flex items-center gap-2 text-amber-600 bg-amber-500/20 px-3 py-1.5 rounded-lg text-xs font-bold">
                        <Sun className="w-4 h-4" /> Terang
                      </span>
                    )}
                  </button>
                </div>

                {/* 2. Organization Selector */}
                {organizations.length > 0 && (
                  <div className="space-y-3">
                    <h4 className="text-xs font-black uppercase tracking-widest text-slate-500">Organisasi Saat Ini</h4>
                    <select
                      value={activeOrgId || ''}
                      onChange={(e) => {
                        setActiveOrgId(e.target.value);
                        setMemberFilter('ALL');
                      }}
                      className={`w-full font-semibold text-sm px-4 py-3.5 rounded-2xl border appearance-none outline-none transition-all cursor-pointer ${
                        isDark ? 'bg-slate-800/50 border-slate-700 text-slate-200 focus:border-indigo-500' : 'bg-slate-50 border-slate-200 text-slate-700 focus:border-indigo-500'
                      }`}
                    >
                      {organizations.map(org => (
                        <option key={org.id} value={org.id}>{org.name}</option>
                      ))}
                    </select>
                    
                    <button
                      onClick={() => { setIsSettingsOpen(false); setIsOrgModalOpen(true); }}
                      className={`w-full flex items-center justify-center gap-2 p-3.5 text-sm font-bold rounded-2xl border transition-all cursor-pointer ${
                        isDark ? 'bg-slate-800 border-slate-705 text-indigo-400 hover:bg-slate-700' : 'bg-white border-slate-300 text-indigo-600 hover:bg-slate-50'
                      }`}
                    >
                      <Users className="w-4 h-4" />
                      Kelola Organisasi
                    </button>
                  </div>
                )}

                {/* 3. Member Filter */}
                {organizations.length > 0 && orgMembers.length > 1 && orgMembers.find(m => m.userId === user?.uid)?.role === 'owner' && (
                  <div className="space-y-3">
                    <h4 className="text-xs font-black uppercase tracking-widest text-slate-500">Filter Laporan Anggota</h4>
                    <select
                      value={memberFilter}
                      onChange={(e) => setMemberFilter(e.target.value)}
                      className={`w-full font-semibold text-sm px-4 py-3.5 rounded-2xl border appearance-none outline-none transition-all cursor-pointer ${
                        isDark ? 'bg-slate-800/50 border-slate-700 text-amber-300 focus:border-amber-500' : 'bg-amber-50 border-amber-200 text-amber-700 focus:border-amber-500'
                      }`}
                    >
                      <option value="ALL">Semua Anggota</option>
                      {orgMembers.map((m: any) => (
                        <option key={m.userId} value={m.userId}>{m.userId === user?.uid ? 'Saya (Anda)' : `UID: ${m.userId.substring(0, 8)}...`}</option>
                      ))}
                    </select>
                  </div>
                )}

              </div>
              
              <div className={`p-6 border-t ${isDark ? 'border-slate-800' : 'border-slate-200'}`}>
                 <button
                  onClick={() => {
                    setIsSettingsOpen(false);
                    handleSignOut();
                  }}
                  className={`w-full flex items-center justify-center gap-2 p-4 rounded-2xl border transition-all cursor-pointer font-bold ${
                    isDark ? 'bg-rose-500/10 hover:bg-rose-500/20 border-rose-500/30 text-rose-400' : 'bg-rose-50 hover:bg-rose-100 border-rose-200 text-rose-600'
                  }`}
                >
                  <LogOut className="w-5 h-5" />
                  Logout Akses Google
                </button>
              </div>

            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* ORGANIZATION MANAGEMENT MODAL */}
      <AnimatePresence>
        {isOrgModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsOrgModalOpen(false)}
              className="absolute inset-0 bg-slate-950/80 backdrop-blur-sm"
            />
            <motion.div
              initial={{ scale: 0.95, opacity: 0, y: 15 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.95, opacity: 0, y: 15 }}
              className={`relative w-full max-w-md border rounded-[2.25rem] p-6 shadow-2xl z-10 overflow-hidden ${isDark ? 'bg-slate-900/95 border-slate-800' : 'bg-white border-slate-200'}`}
            >
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-lg font-black uppercase tracking-wider flex items-center gap-2">
                  <Users className="w-5 h-5 text-indigo-500" />
                  Kelola Organisasi
                </h3>
                <button 
                  onClick={() => setIsOrgModalOpen(false)}
                  className={`p-1.5 rounded-lg transition-colors ${isDark ? 'hover:bg-slate-800 text-slate-400' : 'hover:bg-slate-100 text-slate-500'}`}
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className={`p-4 rounded-xl mb-4 border ${isDark ? 'bg-slate-800/50 border-slate-700/50' : 'bg-slate-50 border-slate-200'}`}>
                <label className={`block text-[10px] font-black uppercase tracking-widest mb-1 ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>ID Pengguna Anda</label>
                <div className="flex items-center gap-2">
                  <code className={`text-xs p-1.5 px-3 rounded flex-1 overflow-auto font-bold ${isDark ? 'bg-slate-900 text-slate-300' : 'bg-white border text-slate-800'}`}>{customId || user?.uid}</code>
                  <button
                    onClick={() => { navigator.clipboard.writeText(customId || user?.uid || ''); triggerToast('ID Disalin!', 'info'); }}
                    className="p-1.5 bg-indigo-600 text-white rounded cursor-pointer hover:bg-indigo-700 active:scale-95 transition"
                    title="Salin ID"
                  >
                    <Copy className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {organizations.length > 0 && activeOrgId && (
                <div className={`p-4 rounded-xl mb-4 border ${isDark ? 'bg-slate-800/50 border-slate-700/50' : 'bg-slate-50 border-slate-200'}`}>
                  <h4 className="text-xs font-black uppercase tracking-wider mb-2">Edit Nama Organisasi Aktif</h4>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={editingOrgName}
                      onChange={(e) => setEditingOrgName(e.target.value)}
                      placeholder="Nama Organisasi"
                      disabled={organizations.find(o => o.id === activeOrgId)?.ownerId !== user?.uid}
                      className={`flex-1 text-sm h-10 px-3 rounded border focus:outline-none focus:border-indigo-500 ${isDark ? 'bg-slate-900 border-slate-700 text-slate-200' : 'bg-white border-slate-300'}`}
                    />
                    {organizations.find(o => o.id === activeOrgId)?.ownerId === user?.uid && (
                      <button onClick={handleUpdateOrgName} disabled={!editingOrgName.trim()} className="h-10 px-4 bg-indigo-600 text-white text-xs font-bold uppercase rounded hover:bg-indigo-700 disabled:opacity-50 transition cursor-pointer">
                        Update
                      </button>
                    )}
                  </div>
                </div>
              )}

              <form onSubmit={handleCreateOrg} className={`p-4 rounded-xl mb-4 border ${isDark ? 'bg-slate-800/50 border-slate-700/50' : 'bg-slate-50 border-slate-200'}`}>
                <h4 className="text-xs font-black uppercase tracking-wider mb-2">Buat Organisasi Baru</h4>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={newOrgName}
                    onChange={(e) => setNewOrgName(e.target.value)}
                    placeholder="Nama Organisasi"
                    className={`flex-1 text-sm h-10 px-3 rounded border focus:outline-none focus:border-indigo-500 ${isDark ? 'bg-slate-900 border-slate-700 text-slate-200' : 'bg-white border-slate-300'}`}
                  />
                  <button type="submit" disabled={!newOrgName.trim()} className="h-10 px-4 bg-indigo-600 text-white text-xs font-bold uppercase rounded hover:bg-indigo-700 disabled:opacity-50 transition cursor-pointer">
                    Buat
                  </button>
                </div>
              </form>

              {organizations.length > 0 && organizations.find(o => o.id === activeOrgId)?.ownerId === user?.uid && (
                <div className="mb-4">
                  <form onSubmit={handleAddMember} className={`p-4 rounded-xl border ${isDark ? 'bg-slate-800/50 border-slate-700/50' : 'bg-slate-50 border-slate-200'}`}>
                    <h4 className="text-xs font-black uppercase tracking-wider mb-2">Daftar & Tambah Anggota</h4>
                    <p className={`text-[10px] mb-2 ${isDark ? 'text-slate-400' : 'text-slate-600'}`}>Minta pengguna lain menyalin Custom ID atau UID mereka untuk Anda tambahkan.</p>
                    <div className="flex gap-2">
                      <input
                        type="text"
                        value={newMemberUid}
                        onChange={(e) => setNewMemberUid(e.target.value)}
                        placeholder="Masukkan ID Pengguna"
                        className={`flex-1 text-sm h-10 px-3 rounded border focus:outline-none focus:border-indigo-500 ${isDark ? 'bg-slate-900 border-slate-700 text-slate-200' : 'bg-white border-slate-300'}`}
                      />
                      <button type="submit" disabled={!newMemberUid.trim()} className="h-10 px-4 bg-indigo-600 text-white text-xs font-bold uppercase rounded hover:bg-indigo-700 disabled:opacity-50 transition cursor-pointer">
                        Tambah
                      </button>
                    </div>
                  </form>
                  {orgMembers.length > 0 && (
                    <div className="mt-3 space-y-2">
                      {orgMembers.map(m => (
                        <div key={m.userId} className={`flex items-center justify-between p-3 rounded-lg border ${isDark ? 'bg-slate-800/30 border-slate-700/50' : 'bg-white border-slate-200'}`}>
                          <div className="flex items-center gap-2">
                            <span className={`text-[10px] px-2 py-0.5 rounded font-bold uppercase ${m.role === 'owner' ? 'bg-amber-500/20 text-amber-500' : 'bg-indigo-500/20 text-indigo-500'}`}>{m.role}</span>
                            <span className={`text-xs font-semibold ${isDark ? 'text-slate-300' : 'text-slate-700'}`}>{m.userId === user?.uid ? 'Anda (Saya)' : m.userId.substring(0, 8) + '...'}</span>
                          </div>
                          {m.userId !== user?.uid && (
                            <button onClick={() => handleRemoveMember(m.userId)} className="p-1.5 text-rose-500 hover:bg-rose-500/10 rounded transition cursor-pointer" title="Hapus Anggota">
                              <Trash2 className="w-4 h-4" />
                            </button>
                          )}
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}

            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
