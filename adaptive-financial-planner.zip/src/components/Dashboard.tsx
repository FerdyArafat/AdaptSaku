import { useState, useMemo } from 'react';
import { 
  ResponsiveContainer, 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  Tooltip, 
  Legend, 
  PieChart, 
  Pie, 
  Cell,
  AreaChart,
  Area,
  CartesianGrid
} from 'recharts';
import { 
  TrendingUp, 
  TrendingDown, 
  Wallet, 
  ShieldCheck, 
  AlertTriangle, 
  Activity,
  Award,
  Calendar,
  Download,
  FileSpreadsheet,
  FileText
} from 'lucide-react';
import { Income, Expense, Goal, AIAdvice } from '../types';
import { jsPDF } from 'jspdf';

interface DashboardProps {
  incomes: Income[];
  expenses: Expense[];
  goals: Goal[];
  aiAdvice: AIAdvice | null;
  allIncomes?: Income[];
  allExpenses?: Expense[];
  uniquePeriods?: string[];
  activePeriod?: string;
  isDark?: boolean;
}

const MONTH_NAMES_ID: { [key: string]: string } = {
  '01': 'Januari',
  '02': 'Februari',
  '03': 'Maret',
  '04': 'April',
  '05': 'Mei',
  '06': 'Juni',
  '07': 'Juli',
  '08': 'Agustus',
  '09': 'September',
  '10': 'Oktober',
  '11': 'November',
  '12': 'Desember'
};

const formatPeriodLabelID = (ym: string) => {
  if (!ym) return 'Semua Periode';
  if (ym === 'older_than_year') return 'Di Atas 1 Tahun Lalu';
  const parts = ym.split('-');
  if (parts.length < 2) return ym;
  const [year, month] = parts;
  const monthName = MONTH_NAMES_ID[month] || month;
  return `${monthName} ${year}`;
};

// Pure helper function to calculate Adaptability Score for a given subset of incomes and expenses
function calculateAdaptabilityScoreForPeriod(
  periodIncomes: Income[],
  periodExpenses: Expense[],
  goalsList: Goal[]
): number {
  const totalIncome = periodIncomes.reduce((sum, item) => sum + item.amount, 0);
  const totalExpense = periodExpenses.reduce((sum, item) => sum + item.amount, 0);
  const netSavings = totalIncome - totalExpense;

  if (totalIncome === 0) return 0;

  let kebutuhan = 0;
  periodExpenses.forEach((e) => {
    if (['kebutuhan', 'operasional_org', 'program_kerja', 'lain_lain'].includes(e.category)) kebutuhan += e.amount;
  });

  const actualSavingsPercent = (netSavings / totalIncome) * 105; // Normal buffer percent
  let savingsScore = 0;
  const actualSavingsRate = (netSavings / totalIncome) * 100;
  if (actualSavingsRate > 0) {
    savingsScore = Math.min(40, (actualSavingsRate / 20) * 40);
  } else {
    savingsScore = Math.max(-20, (actualSavingsRate / 20) * 40);
  }

  const freedomFactor = (totalIncome - kebutuhan) / totalIncome;
  const freedomScore = Math.min(30, Math.max(0, freedomFactor * 30));

  const goalScore = goalsList.length > 0 ? 30 : 15;

  let baseScore = Math.round(savingsScore + freedomScore + goalScore);

  const isCriticalBuffer = actualSavingsRate < 10 || netSavings < 150000;
  const isModerateBuffer = actualSavingsRate < 20 || netSavings < 300000;

  if (netSavings <= 0) {
    baseScore = Math.min(baseScore, 25);
  } else if (isCriticalBuffer) {
    baseScore = Math.min(baseScore, 45);
  } else if (isModerateBuffer) {
    baseScore = Math.min(baseScore, 65);
  }

  return Math.max(0, Math.min(100, baseScore));
}

const CustomTrendTooltip = ({ active, payload }: any) => {
  if (active && payload && payload.length) {
    const scoreValue = payload[0].value;
    const itemData = payload[0].payload;
    
    let statusLabel = 'Critical Warning';
    let statusClass = 'text-rose-400 bg-rose-500/10 border-rose-500/20';
    if (scoreValue >= 75) {
      statusLabel = 'Spent Calibrated';
      statusClass = 'text-emerald-400 bg-emerald-500/10 border-emerald-500/20';
    } else if (scoreValue >= 50) {
      statusLabel = 'Stable Calibrated';
      statusClass = 'text-indigo-400 bg-indigo-550/10 border-indigo-505/20';
    }

    return (
      <div className="p-4 bg-slate-900/95 border border-slate-700 rounded-2xl shadow-xl space-y-2 backdrop-blur-md custom-trend-tooltip-body">
        <p className="text-xs font-sans font-black text-white leading-none custom-trend-tooltip-label">
          {itemData.label}
        </p>
        <div className="flex items-center gap-2">
          <span className="text-xl font-mono font-black text-indigo-400 custom-trend-tooltip-score">
            {scoreValue}
          </span>
          <span className="text-[9px] text-slate-500 font-sans uppercase font-black tracking-wide">
            Adaptability Score
          </span>
        </div>
        <div className={`p-1 px-2.5 rounded-lg border text-center text-[9px] font-sans font-black uppercase tracking-wider ${statusClass}`}>
          {statusLabel}
        </div>
      </div>
    );
  }
  return null;
};

export function Dashboard({ 
  incomes, 
  expenses, 
  goals, 
  aiAdvice,
  allIncomes = [],
  allExpenses = [],
  uniquePeriods = [],
  activePeriod = '2026-05',
  isDark = true
}: DashboardProps) {
  const [exportScope, setExportScope] = useState<'selected' | 'all'>('selected');

  const handleExportCSV = () => {
    const onlySelectedMonth = exportScope === 'selected';
    const periodValue = activePeriod || 'all';
    
    const incomesToExport = onlySelectedMonth 
      ? incomes 
      : (allIncomes.length > 0 ? allIncomes : incomes);
    
    const expensesToExport = onlySelectedMonth 
      ? expenses 
      : (allExpenses.length > 0 ? allExpenses : expenses);

    const headers = [
      'Tipe Transaksi',
      'Tanggal',
      'Deskripsi / Sumber',
      'Kategori Utama',
      'Subkategori / Periode',
      'Jumlah Nominal (IDR)'
    ];

    const csvRows = [headers.join(',')];

    const escapeCSVValue = (val: string | number) => {
      const str = String(val);
      if (str.includes(',') || str.includes('"') || str.includes('\n')) {
        return `"${str.replace(/"/g, '""')}"`;
      }
      return str;
    };

    incomesToExport.forEach(item => {
      const row = [
        'Pemasukan',
        item.date || '',
        escapeCSVValue(item.source || ''),
        escapeCSVValue(item.category),
        escapeCSVValue(item.period === 'monthly' ? 'Bulanan' : 'Sekali-waktu'),
        item.amount
      ];
      csvRows.push(row.join(','));
    });

    expensesToExport.forEach(item => {
      const row = [
        'Pengeluaran',
        item.date || '',
        escapeCSVValue(item.title || ''),
        escapeCSVValue(item.category),
        escapeCSVValue(item.subcategory || ''),
        item.amount
      ];
      csvRows.push(row.join(','));
    });

    const csvString = csvRows.join('\r\n');
    const blob = new Blob([new Uint8Array([0xEF, 0xBB, 0xBF]), csvString], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    
    const prefix = onlySelectedMonth ? `Laporan_AdaptSaku_${periodValue}` : 'Laporan_AdaptSaku_Semua_Masa';
    link.setAttribute('download', `${prefix}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleExportPDF = () => {
    const onlySelectedMonth = exportScope === 'selected';
    const doc = new jsPDF({
      orientation: 'portrait',
      unit: 'mm',
      format: 'a4'
    });

    const periodValue = activePeriod || 'all';
    const selectedLabel = formatPeriodLabelID(periodValue);
    
    const incomesToExport = onlySelectedMonth 
      ? incomes 
      : (allIncomes.length > 0 ? allIncomes : incomes);
    
    const expensesToExport = onlySelectedMonth 
      ? expenses 
      : (allExpenses.length > 0 ? allExpenses : expenses);

    const reportTitle = onlySelectedMonth 
      ? `LAPORAN KONTROL FINANSIAL BULANAN` 
      : `LAPORAN SEJARAH KONTROL FINANSIAL`;
    
    const reportSub = onlySelectedMonth
      ? `Periode: ${selectedLabel.toUpperCase()}`
      : `Rekapitulasi Semua Masa Gabungan`;

    const pdfTotalIncome = incomesToExport.reduce((sum, item) => sum + item.amount, 0);
    const pdfTotalExpense = expensesToExport.reduce((sum, item) => sum + item.amount, 0);
    const pdfSaveBuffer = pdfTotalIncome - pdfTotalExpense;
    
    let pdfScore = adaptabilityScore;
    if (!onlySelectedMonth) {
      pdfScore = calculateAdaptabilityScoreForPeriod(incomesToExport, expensesToExport, goals);
    }
    
    let pdfRating = 'CRITICAL WARNING';
    let pdfRatingColor = [225, 29, 72];
    if (pdfScore >= 75) {
      pdfRating = 'SPENT CALIBRATED';
      pdfRatingColor = [16, 185, 129];
    } else if (pdfScore >= 50) {
      pdfRating = 'STABLE CALIBRATED';
      pdfRatingColor = [79, 70, 229];
    }

    let y = 15;

    const checkPageBreak = (neededHeight: number) => {
      if (y + neededHeight > 275) {
        doc.addPage();
        y = 15;
        drawFooter();
      }
    };

    const drawFooter = () => {
      const pageCount = (doc.internal as any).getNumberOfPages();
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(8);
      doc.setTextColor(148, 163, 184);
      doc.text(
        `Laporan Keuangan Adaptif AdaptSaku AI • Halaman ${pageCount}`,
        105,
        287,
        { align: 'center' }
      );
    };

    drawFooter();

    // Brand Badge decorative blue rect
    doc.setFillColor(79, 70, 229);
    doc.rect(15, y, 5, 12, 'F');

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(16);
    doc.setTextColor(15, 23, 42);
    doc.text('ADAPTSAKU', 23, y + 5);

    doc.setFont('helvetica', 'italic');
    doc.setFontSize(8);
    doc.setTextColor(100, 116, 139);
    doc.text('Asisten Perencana Keuangan Adaptif dengan Kecerdasan AI', 23, y + 10);

    const userEmail = "ferdyarafat@gmail.com";
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8);
    doc.setTextColor(100, 116, 139);
    const today = new Date().toLocaleString('id-ID', { dateStyle: 'long', timeStyle: 'short' });
    doc.text(`Dicetak: ${today} oleh ${userEmail}`, 195, y + 5, { align: 'right' });
    doc.text(`Platform: Google AI Studio Run Container`, 195, y + 10, { align: 'right' });

    y += 18;

    doc.setDrawColor(226, 232, 240);
    doc.setLineWidth(0.5);
    doc.line(15, y, 195, y);

    y += 8;

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(13);
    doc.setTextColor(30, 41, 59);
    doc.text(reportTitle, 15, y);

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(10);
    doc.setTextColor(16, 185, 129);
    doc.text(reportSub, 15, y + 5.5);

    y += 12;

    const boxW = 42;
    const boxH = 22;
    const padding = 4;

    doc.setFillColor(248, 250, 252);
    doc.setDrawColor(226, 232, 240);
    doc.rect(15, y, boxW, boxH, 'FD');
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(7.5);
    doc.setTextColor(100, 116, 139);
    doc.text('TOTAL PEMASUKAN', 15 + padding, y + padding + 2);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(10);
    doc.setTextColor(16, 185, 129);
    doc.text(formatRupiah(pdfTotalIncome), 15 + padding, y + boxH - 4);

    doc.setFillColor(248, 250, 252);
    doc.rect(15 + boxW + 2, y, boxW, boxH, 'FD');
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(7.5);
    doc.setTextColor(100, 116, 139);
    doc.text('TOTAL PENGELUARAN', 15 + boxW + 2 + padding, y + padding + 2);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(10);
    doc.setTextColor(225, 29, 72);
    doc.text(formatRupiah(pdfTotalExpense), 15 + boxW + 2 + padding, y + boxH - 4);

    doc.setFillColor(248, 250, 252);
    doc.rect(15 + (boxW * 2) + 4, y, boxW, boxH, 'FD');
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(7.5);
    doc.setTextColor(100, 116, 139);
    doc.text('SALDO BERSIH (BUFFER)', 15 + (boxW * 2) + 4 + padding, y + padding + 2);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(10);
    doc.setTextColor(pdfSaveBuffer >= 0 ? 79 : 225, pdfSaveBuffer >= 0 ? 70 : 29, pdfSaveBuffer >= 0 ? 229 : 72);
    doc.text(formatRupiah(pdfSaveBuffer), 15 + (boxW * 2) + 4 + padding, y + boxH - 4);

    doc.setFillColor(248, 250, 252);
    doc.rect(15 + (boxW * 3) + 6, y, boxW, boxH, 'FD');
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(7.5);
    doc.setTextColor(100, 116, 139);
    doc.text('ADAPTABILITY INDEX', 15 + (boxW * 3) + 6 + padding, y + padding + 2);
    
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(11);
    doc.setTextColor(pdfRatingColor[0], pdfRatingColor[1], pdfRatingColor[2]);
    doc.text(`${pdfScore} / 100`, 15 + (boxW * 3) + 6 + padding, y + boxH - 8);
    doc.setFontSize(6.5);
    doc.text(pdfRating, 15 + (boxW * 3) + 6 + padding, y + boxH - 4);

    y += boxH + 8;

    checkPageBreak(35);
    doc.setFillColor(248, 250, 252);
    doc.setDrawColor(226, 232, 240);
    doc.rect(15, y, 180, 26, 'FD');

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(9);
    doc.setTextColor(30, 41, 59);
    doc.text('REKOMENDASI PORSI BELANJA ADAPTIF VS REALISASI AKTUAL (3 PILAR)', 19, y + 4.5);

    let cellX = 19;
    const cellW = 55;

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(7.5);
    doc.setTextColor(100, 116, 139);
    doc.text('Pilar Kebutuhan (Needs)', cellX, y + 10.5);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(8);
    doc.setTextColor(245, 158, 11);
    doc.text(`Aktual: ${actualRatios.kebutuhan}% @ ${formatRupiah(expenseBreakdown.kebutuhan).replace('Rp', '')}`, cellX, y + 15.5);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(100, 116, 139);
    doc.text(`Target: ${targetRatio.kebutuhan}%`, cellX, y + 20.5);

    cellX += cellW;
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(7.5);
    doc.text('Pilar Keinginan (Wants)', cellX, y + 10.5);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(8);
    doc.setTextColor(236, 72, 153);
    doc.text(`Aktual: ${actualRatios.keinginan}% @ ${formatRupiah(expenseBreakdown.keinginan).replace('Rp', '')}`, cellX, y + 15.5);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(100, 116, 139);
    doc.text(`Target: ${targetRatio.keinginan}%`, cellX, y + 20.5);

    cellX += cellW;
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(7.5);
    doc.text('Pilar Tabungan (Savings)', cellX, y + 10.5);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(8);
    doc.setTextColor(16, 185, 129);
    doc.text(`Aktual: ${actualRatios.tabungan}% @ ${formatRupiah(expenseBreakdown.tabungan).replace('Rp', '')}`, cellX, y + 15.5);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(100, 116, 139);
    doc.text(`Target: ${targetRatio.tabungan}%`, cellX, y + 20.5);

    y += 33;

    checkPageBreak(30);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(10.5);
    doc.setTextColor(15, 23, 42);
    doc.text('1. DAFTAR PEMASUKAN', 15, y);
    
    y += 5;
    
    doc.setFillColor(79, 70, 229);
    doc.rect(15, y, 180, 7, 'F');
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(8);
    doc.setTextColor(255, 255, 255);
    doc.text('Tanggal', 18, y + 4.5);
    doc.text('Sumber / Keterangan', 48, y + 4.5);
    doc.text('Kategori', 108, y + 4.5);
    doc.text('Metode Periode', 142, y + 4.5);
    doc.text('Jumlah Nominal', 192, y + 4.5, { align: 'right' });
    
    y += 7;

    if (incomesToExport.length === 0) {
      doc.setDrawColor(226, 232, 240);
      doc.setLineWidth(0.2);
      doc.line(15, y, 195, y);
      doc.setFont('helvetica', 'italic');
      doc.setFontSize(8.5);
      doc.setTextColor(148, 163, 184);
      doc.text('Belum ada data pemasukan tercatat pada periode ini.', 18, y + 5.5);
      y += 10;
    } else {
      incomesToExport.forEach((item, index) => {
        checkPageBreak(8);
        if (index % 2 === 1) {
          doc.setFillColor(248, 250, 252);
          doc.rect(15, y, 180, 7, 'F');
        }
        doc.setDrawColor(241, 245, 249);
        doc.setLineWidth(0.25);
        doc.line(15, y + 7, 195, y + 7);

        doc.setFont('helvetica', 'normal');
        doc.setFontSize(8);
        doc.setTextColor(51, 65, 85);
        
        doc.text((item.date || '-').replace('T', ' '), 18, y + 5);
        
        let sSource = item.source || '';
        if (sSource.length > 32) sSource = sSource.substring(0, 30) + '..';
        doc.text(sSource, 48, y + 5);
        
        const catLabel = item.category.toUpperCase();
        doc.text(catLabel, 108, y + 5);
        doc.text(item.period === 'monthly' ? 'Bulanan Rutin' : 'Satu Kali', 142, y + 5);
        
        doc.setFont('helvetica', 'bold');
        doc.text(formatRupiah(item.amount), 192, y + 5, { align: 'right' });
        y += 7;
      });
      y += 4;
    }

    checkPageBreak(30);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(10.5);
    doc.setTextColor(15, 23, 42);
    doc.text('2. DAFTAR PENGELUARAN', 15, y);
    
    y += 5;
    
    doc.setFillColor(225, 29, 72);
    doc.rect(15, y, 180, 7, 'F');
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(8);
    doc.setTextColor(255, 255, 255);
    doc.text('Tanggal', 18, y + 4.5);
    doc.text('Judul Transaksi / Item', 48, y + 4.5);
    doc.text('Kategori Pilar', 108, y + 4.5);
    doc.text('Subkategori Detail', 142, y + 4.5);
    doc.text('Jumlah Nominal', 192, y + 4.5, { align: 'right' });
    
    y += 7;

    if (expensesToExport.length === 0) {
      doc.setDrawColor(226, 232, 240);
      doc.setLineWidth(0.2);
      doc.line(15, y, 195, y);
      doc.setFont('helvetica', 'italic');
      doc.setFontSize(8.5);
      doc.setTextColor(148, 163, 184);
      doc.text('Belum ada data pengeluaran tercatat pada periode ini.', 18, y + 5.5);
      y += 10;
    } else {
      expensesToExport.forEach((item, index) => {
        checkPageBreak(8);
        if (index % 2 === 1) {
          doc.setFillColor(248, 250, 252);
          doc.rect(15, y, 180, 7, 'F');
        }
        doc.setDrawColor(241, 245, 249);
        doc.setLineWidth(0.25);
        doc.line(15, y + 7, 195, y + 7);

        doc.setFont('helvetica', 'normal');
        doc.setFontSize(8);
        doc.setTextColor(51, 65, 85);
        
        doc.text((item.date || '-').replace('T', ' '), 18, y + 5);
        
        let sTitle = item.title || '';
        if (sTitle.length > 32) sTitle = sTitle.substring(0, 30) + '..';
        doc.text(sTitle, 48, y + 5);
        
        const catLabel = item.category.toUpperCase();
        doc.text(catLabel, 108, y + 5);
        doc.text(item.subcategory || '-', 142, y + 5);
        
        doc.setFont('helvetica', 'bold');
        doc.text(formatRupiah(item.amount), 192, y + 5, { align: 'right' });
        y += 7;
      });
      y += 4;
    }

    if (goals.length > 0) {
      checkPageBreak(30);
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(10.5);
      doc.setTextColor(15, 23, 42);
      doc.text('3. STATUS CAPAIAN TARGET IMPIAN', 15, y);
      
      y += 5;
      
      doc.setFillColor(16, 185, 129);
      doc.rect(15, y, 180, 7, 'F');
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(8);
      doc.setTextColor(255, 255, 255);
      doc.text('Nama Impian', 18, y + 4.5);
      doc.text('Target Tanggal', 68, y + 4.5);
      doc.text('Prioritas', 98, y + 4.5);
      doc.text('Terkumpul / Goal (IDR)', 128, y + 4.5);
      doc.text('Progress %', 192, y + 4.5, { align: 'right' });
      
      y += 7;

      goals.forEach((goal, index) => {
        checkPageBreak(8);
        if (index % 2 === 1) {
          doc.setFillColor(248, 250, 252);
          doc.rect(15, y, 180, 7, 'F');
        }
        doc.setDrawColor(241, 245, 249);
        doc.setLineWidth(0.25);
        doc.line(15, y + 7, 195, y + 7);

        doc.setFont('helvetica', 'normal');
        doc.setFontSize(8);
        doc.setTextColor(51, 65, 85);
        
        doc.text(goal.name || '-', 18, y + 5);
        doc.text(goal.targetDate || '-', 68, y + 5);
        
        const prioLabel = goal.priority === 'high' ? 'Tinggi' : goal.priority === 'medium' ? 'Sedang' : 'Rendah';
        doc.text(prioLabel, 98, y + 5);
        
        doc.text(`${formatRupiah(goal.currentAmount).replace('Rp', '')} / ${formatRupiah(goal.targetAmount).replace('Rp', '')}`, 128, y + 5);
        
        const pct = goal.targetAmount > 0 ? Math.round((goal.currentAmount / goal.targetAmount) * 100) : 0;
        doc.setFont('helvetica', 'bold');
        doc.text(`${pct}%`, 192, y + 5, { align: 'right' });
        y += 7;
      });
      y += 4;
    }

    if (aiAdvice) {
      checkPageBreak(35);
      doc.setFillColor(240, 253, 250);
      doc.setDrawColor(204, 251, 241);
      doc.rect(15, y, 180, 24, 'FD');

      doc.setFont('helvetica', 'bold');
      doc.setFontSize(9);
      doc.setTextColor(15, 118, 110);
      doc.text('REKOMENDASI STRATEGIS KECERDASAN AdaptSaku AI', 19, y + 5.5);

      doc.setFont('helvetica', 'normal');
      doc.setFontSize(7.5);
      doc.setTextColor(51, 65, 85);
      
      const adviceLine = aiAdvice.summary || 'Kondisi kas terpantau stabil. Pastikan alokasi sisa dana terus dioptimalkan secara teratur.';
      const wrappedText = doc.splitTextToSize(adviceLine, 172);
      doc.text(wrappedText, 19, y + 10.5);
    }

    const pdfName = onlySelectedMonth 
      ? `Laporan-Keuangan-AdaptSaku_${periodValue}.pdf` 
      : `Laporan-Keuangan-AdaptSaku_Semua_Masa.pdf`;

    doc.save(pdfName);
  };

  // 1. Calculations
  const totalIncome = useMemo(() => incomes.reduce((sum, item) => sum + item.amount, 0), [incomes]);
  const totalExpense = useMemo(() => expenses.reduce((sum, item) => sum + item.amount, 0), [expenses]);
  const netSavings = totalIncome - totalExpense;

  // Breakdown expenses
  const expenseBreakdown = useMemo(() => {
    let kebutuhan = 0;
    let keinginan = 0;
    let tabungan = 0;

    expenses.forEach((e) => {
      if (['kebutuhan', 'operasional_org', 'program_kerja', 'lain_lain'].includes(e.category)) kebutuhan += e.amount;
      else if (e.category === 'keinginan') keinginan += e.amount;
      else if (['tabungan', 'modal_usaha'].includes(e.category)) tabungan += e.amount;
    });

    return { kebutuhan, keinginan, tabungan };
  }, [expenses]);

  // Ratios
  const actualRatios = useMemo(() => {
    if (totalExpense === 0) return { kebutuhan: 0, keinginan: 0, tabungan: 0 };
    return {
      kebutuhan: Math.round((expenseBreakdown.kebutuhan / totalIncome) * 100),
      keinginan: Math.round((expenseBreakdown.keinginan / totalIncome) * 100),
      tabungan: Math.round((expenseBreakdown.tabungan / totalIncome) * 100),
    };
  }, [expenseBreakdown, totalIncome, totalExpense]);

  // Target ratios (Use AI advice if exists, otherwise default 50/30/20)
  const targetRatio = useMemo(() => {
    if (aiAdvice) return aiAdvice.recommendedRatio;
    return { kebutuhan: 50, keinginan: 30, tabungan: 20 };
  }, [aiAdvice]);

  // Score calculating "Indeks Adaptabilitas Finansial"
  // Score is calculated based on:
  // - Savings rate (up to 40 pts) -> target savings rate > 20%
  // - Freedom score (up to 30 pts) -> (Income - Kebutuhan) / Income
  // - Debt & Priority health (up to 30 pts) -> goals vs total budget
  const adaptabilityScore = useMemo(() => {
    if (totalIncome === 0) return 0;
    
    // Savings percentage score
    const actualSavingsPercent = (netSavings / totalIncome) * 100;
    let savingsScore = 0;
    if (actualSavingsPercent > 0) {
      savingsScore = Math.min(40, (actualSavingsPercent / 20) * 40);
    } else {
      // Overspent is heavily penalized
      savingsScore = Math.max(-20, (actualSavingsPercent / 20) * 40);
    }

    // Freedom factor score: how much room you have after essential expenses
    const freedomFactor = (totalIncome - expenseBreakdown.kebutuhan) / totalIncome;
    const freedomScore = Math.min(30, Math.max(0, freedomFactor * 30));

    // Goal buffer score
    const goalScore = goals.length > 0 ? 30 : 15; // default 15 if no goals registered yet

    let baseScore = Math.round(savingsScore + freedomScore + goalScore);

    // CRITICAL CORRECTION & SAFEGUARDS FOR EMERGENCY RESERVES (BIAYA DADAKAN)
    // If savings rate is tiny or net savings is absolutely small, they are extremely vulnerable.
    // - If saldo bersih (netSavings) is less than 10% of total income, or less than Rp 150.000 absolute,
    //   their budget is NOT safe from sudden costs. We cap the score to Critical Warning (< 50).
    // - If netSavings is between 10% and 20% of total income, or less than Rp 300.000 absolute,
    //   we cap the score to Stable Calibrated (< 70) so they can't get elite Spent Calibrated status with minimal buffer.
    const isCriticalBuffer = actualSavingsPercent < 10 || netSavings < 150000;
    const isModerateBuffer = actualSavingsPercent < 20 || netSavings < 300000;

    if (netSavings <= 0) {
      baseScore = Math.min(baseScore, 25);
    } else if (isCriticalBuffer) {
      baseScore = Math.min(baseScore, 45); // Strictly guarantees "Critical Warning" (< 50)
    } else if (isModerateBuffer) {
      baseScore = Math.min(baseScore, 65); // Caps at "Stable" (< 70)
    }

    return Math.max(0, Math.min(100, baseScore));
  }, [totalIncome, netSavings, expenseBreakdown.kebutuhan, goals]);

  // Status mapping
  const adaptabilityStatus = useMemo(() => {
    if (adaptabilityScore >= 75) return { label: 'SPENT CALIBRATED', color: 'text-emerald-400 bg-emerald-500/10 border-emerald-500/20', desc: 'Arus kas sangat fleksibel, optimal menghadapi fluktuasi finansial.' };
    if (adaptabilityScore >= 50) return { label: 'STABLE CALIBRATED', color: 'text-indigo-400 bg-indigo-505/10 border-indigo-500/20', desc: 'Anggaran aman, memiliki ruang mumpuni hadapi biaya dadakan.' };
    return { label: 'CRITICAL WARNING', color: 'text-rose-400 bg-rose-500/10 border-rose-500/20', desc: 'Kondisi sangat ketat. Sisa saldo bersih kurang aman untuk biaya dadakan, segera pangkas biaya keinginan Anda.' };
  }, [adaptabilityScore]);

  // Calculation of historical adaptability score trend across all tracked periods
  const trendData = useMemo(() => {
    const periods = uniquePeriods.length > 0 ? uniquePeriods : ['2026-04', '2026-05', '2026-06', '2026-07'];
    
    return periods.map((period) => {
      const periodIncomes = allIncomes.filter(i => i.date && i.date.startsWith(period));
      const periodExpenses = allExpenses.filter(e => e.date && e.date.startsWith(period));
      
      const score = calculateAdaptabilityScoreForPeriod(periodIncomes, periodExpenses, goals);
      
      const parts = period.split('-');
      let label = period;
      if (parts.length === 2) {
        const [year, month] = parts;
        const shortYear = year.substring(2);
        const monthNames: { [key: string]: string } = {
          '01': 'Jan', '02': 'Feb', '03': 'Mar', '04': 'Apr',
          '05': 'Mei', '06': 'Jun', '07': 'Jul', '08': 'Ags',
          '09': 'Sep', '10': 'Okt', '11': 'Nov', '12': 'Des'
        };
        label = `${monthNames[month] || month} '${shortYear}`;
      }
      
      return {
        period,
        label,
        'Adaptability Score': score
      };
    });
  }, [allIncomes, allExpenses, uniquePeriods, goals]);

  // Recharts Chart Formats
  const actualVsTargetData = [
    {
      name: 'Kebutuhan',
      Aktual: expenseBreakdown.kebutuhan,
      Target: (targetRatio.kebutuhan / 100) * totalIncome,
    },
    {
      name: 'Keinginan',
      Aktual: expenseBreakdown.keinginan,
      Target: (targetRatio.keinginan / 100) * totalIncome,
    },
    {
      name: 'Tabungan',
      Aktual: expenseBreakdown.tabungan + Math.max(0, netSavings), // consider surplus as savings buffer
      Target: (targetRatio.tabungan / 100) * totalIncome,
    },
  ];

  const pieData = [
    { name: 'Kebutuhan', value: expenseBreakdown.kebutuhan, color: '#f59e0b' },
    { name: 'Keinginan', value: expenseBreakdown.keinginan, color: '#ec4899' },
    { name: 'Sisa/Tabungan', value: expenseBreakdown.tabungan + Math.max(0, netSavings), color: '#10b981' },
  ].filter(item => item.value > 0);

  // Helper currency format
  const formatRupiah = (val: number) => {
    return new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
      minimumFractionDigits: 0,
    }).format(val);
  };

  // Theme Configuration for Recharts
  const axisColor = isDark ? '#94a3b8' : '#475569';
  const gridColor = isDark ? '#334155' : '#e2e8f0';
  const tooltipBg = isDark ? '#1e293b' : '#ffffff';
  const tooltipBorder = isDark ? '#475569' : '#cbd5e1';
  const tooltipText = isDark ? '#ffffff' : '#0f172a';

  // Budget limit warning (set predefined budget limit to total income or a custom fixed number)
  const predefinedBudgetLimit = totalIncome;
  const isOverBudget = totalExpense > predefinedBudgetLimit && totalExpense > 0;

  return (
    <div id="dashboard_summary_container" className="space-y-6">
      
      {/* 0. Budget Exceeded Warning Alert */}
      {isOverBudget && (
        <div className={`p-4 border rounded-2xl flex items-start gap-4 shadow-sm animate-pulse ${
          isDark ? 'bg-rose-500/10 border-rose-500/30 text-rose-300' : 'bg-rose-50 border-rose-200 text-rose-700'
        }`}>
          <div className={`p-2 rounded-xl shrink-0 ${isDark ? 'bg-rose-500/20 text-rose-400' : 'bg-rose-100 text-rose-600'}`}>
            <AlertTriangle className="w-5 h-5" />
          </div>
          <div className="space-y-1">
            <h4 className="font-bold text-sm">Peringatan: Limit Anggaran Terlampaui</h4>
            <p className="text-xs opacity-90 leading-relaxed font-medium">
              Total pengeluaran Anda ({formatRupiah(totalExpense)}) bulan ini telah melampaui limit anggaran periode pencatatan ({formatRupiah(predefinedBudgetLimit)}). Berhati-hatilah terhadap potensi defisit arus kas.
            </p>
          </div>
        </div>
      )}

      {/* 1. Value Summary Bento Row */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        
        {/* Card Pemasukan */}
        <div className="p-5 bg-slate-800/50 backdrop-blur-md border border-slate-705 rounded-[1.8rem] flex flex-col justify-between min-h-[115px] shadow-lg relative overflow-hidden group">
          <div className="absolute top-0 right-0 w-24 h-24 bg-emerald-500/5 rounded-full blur-2xl group-hover:scale-125 transition-transform duration-500"></div>
          <div className="flex justify-between items-start z-10 w-full">
            <span className="text-[10px] font-sans font-black text-slate-400 uppercase tracking-widest block pt-1">
              TOTAL INCOME
            </span>
            <div className="w-8 h-8 rounded-lg bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 flex items-center justify-center shrink-0 z-10">
              <TrendingUp className="w-4 h-4" />
            </div>
          </div>
          <div className="z-10 mt-3">
            <p className="text-xl font-mono font-black text-white tracking-tight break-all">
              {formatRupiah(totalIncome)}
            </p>
          </div>
        </div>

        {/* Card Pengeluaran */}
        <div className="p-5 bg-slate-800/50 backdrop-blur-md border border-slate-705 rounded-[1.8rem] flex flex-col justify-between min-h-[115px] shadow-lg relative overflow-hidden group">
          <div className="absolute top-0 right-0 w-24 h-24 bg-rose-500/5 rounded-full blur-2xl group-hover:scale-125 transition-transform duration-500"></div>
          <div className="flex justify-between items-start z-10 w-full">
            <span className="text-[10px] font-sans font-black text-slate-400 uppercase tracking-widest block pt-1">
              TOTAL EXPENSES
            </span>
            <div className="w-8 h-8 rounded-lg bg-rose-500/10 text-rose-400 border border-rose-500/20 flex items-center justify-center shrink-0 z-10">
              <TrendingDown className="w-4 h-4" />
            </div>
          </div>
          <div className="z-10 mt-3">
            <p className="text-xl font-mono font-black text-white tracking-tight break-all">
              {formatRupiah(totalExpense)}
            </p>
          </div>
        </div>

        {/* Card Saldo Bersih */}
        <div className="p-5 bg-slate-800/50 backdrop-blur-md border border-slate-705 rounded-[1.8rem] flex flex-col justify-between min-h-[115px] shadow-lg relative overflow-hidden group">
          <div className="absolute top-0 right-0 w-24 h-24 bg-indigo-500/5 rounded-full blur-2xl group-hover:scale-125 transition-transform duration-500"></div>
          <div className="flex justify-between items-start z-10 w-full">
            <span className="text-[10px] font-sans font-black text-slate-400 uppercase tracking-widest block pt-1">
              SAFETY BUFFER
            </span>
            <div className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 z-10 border ${
              netSavings >= 0 ? 'bg-indigo-500/10 text-indigo-400 border-indigo-500/20' : 'bg-rose-500/10 text-rose-400 border-rose-505/20'
            }`}>
              <Wallet className="w-4 h-4" />
            </div>
          </div>
          <div className="z-10 mt-3">
            <p className={`text-xl font-mono font-black tracking-tight break-all ${netSavings >= 0 ? 'text-indigo-400' : 'text-rose-400'}`}>
              {formatRupiah(netSavings)}
            </p>
          </div>
        </div>
      </div>

      {/* 2. Indeks Adaptabilitas Ringkas Bento Box */}
      <div className="p-6 bg-slate-800/50 backdrop-blur-md border border-slate-705 rounded-[2rem] shadow-xl space-y-6 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-500/5 rounded-full blur-3xl -mr-16 -mt-16 pointer-events-none"></div>
        
        {/* Row 1: Scoring Categories Explanation */}
        <div className="pb-5 border-b border-slate-800/50 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2 text-indigo-400">
              <Activity className="w-5 h-5 flex-shrink-0" />
              <h4 className="text-xs font-sans font-black text-white uppercase tracking-widest">
                ADAPTIVE METRICS
              </h4>
            </div>
            <p className="text-[10px] text-slate-400 leading-relaxed font-semibold">
              Metrik penilaian keuangan Anda.
            </p>
          </div>
          
          <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-3 px-4 flex flex-wrap gap-x-6 gap-y-2 items-center justify-start md:justify-end shrink-0">
            <span className="block text-[8px] font-sans font-black text-slate-500 uppercase tracking-widest w-full md:w-auto">
              Kategori Skor:
            </span>
            <p className="flex items-center gap-1.5 text-[10px] text-slate-350">
              <span className="w-1.5 h-1.5 bg-emerald-400 rounded-full shrink-0 animate-pulse"></span>
              <span><strong className="text-emerald-400 font-black">≥75</strong> Spent Calibrated</span>
            </p>
            <p className="flex items-center gap-1.5 text-[10px] text-slate-350">
              <span className="w-1.5 h-1.5 bg-indigo-400 rounded-full shrink-0"></span>
              <span><strong className="text-indigo-400 font-black">50-74</strong> Stable Calibrated</span>
            </p>
            <p className="flex items-center gap-1.5 text-[10px] text-slate-350">
              <span className="w-1.5 h-1.5 bg-rose-400 rounded-full shrink-0"></span>
              <span><strong className="text-rose-400 font-black">&lt;50</strong> Critical Warning</span>
            </p>
          </div>
        </div>

        {/* Row 2: Live Assessment Meter & Target Budget Breakdown */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-center">
          <div className="flex items-center gap-4">
            <div className="relative w-16 h-16 shrink-0 flex items-center justify-center rounded-full border-4 border-slate-700 bg-slate-900/60 shadow-inner">
              <span className="text-lg font-mono font-black text-white">{adaptabilityScore}</span>
              <div className={`absolute inset-0 rounded-full border-4 ${
                adaptabilityScore >= 75 ? 'border-emerald-500' : adaptabilityScore >= 50 ? 'border-indigo-500' : 'border-amber-500'
              } opacity-40 pointer-events-none`} />
            </div>
            <div>
              <span className={`inline-block text-[10px] font-sans font-black px-2.5 py-0.5 rounded-full border uppercase tracking-wider ${adaptabilityStatus.color}`}>
                {adaptabilityStatus.label}
              </span>
              <p className="text-[11px] font-sans text-slate-300 mt-1 lines-clamp-2 leading-relaxed">
                {adaptabilityStatus.desc}
              </p>
            </div>
          </div>

          <div className="p-3 bg-slate-900/40 border border-slate-705 rounded-xl space-y-1.5 flex flex-col justify-between">
            <div>
              <span className="text-[9px] font-sans font-black text-slate-400 uppercase tracking-widest flex items-center gap-1">
                <Award className="w-3.5 h-3.5 text-indigo-400" /> Target Budget ({aiAdvice ? 'Adaptif AI' : 'Default'})
              </span>
              <div className="grid grid-cols-3 gap-1.5 text-center font-mono text-[11px] font-bold text-slate-305 mt-1">
                <div className="p-1 px-2 bg-amber-500/10 border border-amber-500/20 rounded-lg text-amber-400">
                  <span className="block text-[7px] text-slate-500 font-sans font-black">NEEDS</span>
                  {targetRatio.kebutuhan}%
                </div>
                <div className="p-1 px-2 bg-pink-500/10 border border-pink-500/20 rounded-lg text-pink-400">
                  <span className="block text-[7px] text-slate-500 font-sans font-black">WANTS</span>
                  {targetRatio.keinginan}%
                </div>
                <div className="p-1 px-2 bg-emerald-500/10 border border-emerald-500/20 rounded-lg text-emerald-400">
                  <span className="block text-[7px] text-slate-500 font-sans font-black">SAVE</span>
                  {targetRatio.tabungan}%
                </div>
              </div>
            </div>

            {/* AI Calibration Helper Notice */}
            <div className="pt-2 border-t border-slate-700/30 text-[9.5px] leading-relaxed text-slate-400 dark:text-slate-300 flex items-start gap-1.5">
              <span className="text-[11px] mt-0.5 select-none text-indigo-400 shrink-0">🤖</span>
              <p>
                {!aiAdvice ? (
                  <span>
                    Rasio di atas menggunakan batasan standar. Gunakan tab <span className="font-bold text-indigo-400">Asisten AI & Simulasi</span> untuk menyusun rekomendasi alokasi yang disesuaikan otomatis dengan cashflow Anda!
                  </span>
                ) : (
                  <span>
                    Rasio saat ini berhasil terkalibrasi secara dinamis oleh asisten penganalisis Gemini AI sesuai kondisi sisa uang belanja Anda.
                  </span>
                )}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* 2.5 Tren Adaptability Score Historis (Bento Full-Width Card) */}
      <div id="adaptability_trend_chart_box" className="p-6 bg-slate-800/50 backdrop-blur-md border border-slate-705 rounded-[2rem] shadow-xl flex flex-col min-h-[300px] relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-500/5 rounded-full blur-3xl -mr-16 -mt-16 pointer-events-none"></div>
        
        <div className="mb-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <span className="px-3 py-1 bg-indigo-500/10 text-indigo-300 text-[9px] font-black uppercase rounded-full border border-indigo-550/20">
              Score Timeline
            </span>
            <h4 className="text-base font-sans font-black text-white mt-2 flex items-center gap-2">
              <Calendar className="w-4 h-4 text-indigo-400" /> Tren Adaptability Score Historis
            </h4>
            <p className="text-[11px] text-slate-400 mt-1 max-w-xl">
              Grafik perkembangan skor adaptabilitas keuangan Anda dari bulan ke bulan. Rentang nilai optimal adalah di atas 75 (Spent Calibrated).
            </p>
          </div>

          <div className="flex gap-2 shrink-0">
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900/40 border border-slate-800 text-[10px] text-slate-400">
              <span className="w-2 h-2 rounded-full bg-indigo-500"></span>
              Skor Anda
            </div>
          </div>
        </div>

        <div className="flex-1 min-h-[200px] w-full">
          {trendData.length === 0 ? (
            <div className="h-full flex items-center justify-center text-xs text-slate-500 p-8 text-center border border-dashed border-slate-700 rounded-2xl">
              Belum ada data periodik historis yang terekam.
            </div>
          ) : (
            <ResponsiveContainer width="100%" height={210}>
              <AreaChart data={trendData} margin={{ top: 10, right: 10, left: -25, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorScore" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#6366f1" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#6366f1" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke={gridColor} className="opacity-20 stroke-slate-750" />
                <XAxis 
                  dataKey="label" 
                  tick={{ fontSize: 10, fontFamily: 'sans-serif', fill: axisColor }} 
                  tickLine={false}
                  axisLine={false}
                  dy={10}
                />
                <YAxis 
                  domain={[0, 100]} 
                  tick={{ fontSize: 10, fontFamily: 'monospace', fill: axisColor }} 
                  tickLine={false}
                  axisLine={false}
                  dx={-5}
                />
                <Tooltip 
                  content={<CustomTrendTooltip />}
                  cursor={{ stroke: '#6366f1', strokeWidth: 1, strokeDasharray: '3 3' }}
                />
                <Area 
                  type="monotone" 
                  dataKey="Adaptability Score" 
                  stroke="#6366f1" 
                  strokeWidth={3} 
                  fillOpacity={1} 
                  fill="url(#colorScore)" 
                  activeDot={{ r: 6, strokeWidth: 1 }}
                />
              </AreaChart>
            </ResponsiveContainer>
          )}
        </div>
      </div>

      {/* 3. Recharts Graphics */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Actual VS Adaptive Target Budget */}
        <div id="actual_vs_target_chart_box" className={`p-5 backdrop-blur-md border rounded-[2rem] shadow-xl flex flex-col min-h-80 transition-colors ${
          isDark ? 'bg-slate-800/50 border-slate-705' : 'bg-white border-slate-200'
        }`}>
          <div className="mb-4">
            <span className={`px-3 py-1 text-[9px] font-black uppercase rounded-full border ${
              isDark ? 'bg-indigo-500/10 text-indigo-300 border-indigo-550/20' : 'bg-indigo-50 text-indigo-600 border-indigo-200'
            }`}>
              Projection Comparison
            </span>
            <h4 className={`text-sm font-sans font-black mt-2 leading-none ${isDark ? 'text-white' : 'text-slate-900'}`}>
              Alokasi Nominal: Aktual vs Target
            </h4>
            <p className={`text-[11px] mt-1 ${isDark ? 'text-slate-400' : 'text-slate-500 font-medium'}`}>
              Perbandingan sisa pagu nominal Anda dengan target alokasi adaptif bulanan.
            </p>
          </div>
          <div className="flex-1 min-h-[220px]">
            {totalIncome === 0 ? (
              <div className="h-full flex items-center justify-center text-xs text-slate-500 p-8 text-center border border-dashed border-slate-700 rounded-2xl">
                Silakan isi data pendapatan Anda terlebih dahulu untuk memproyeksikan pagu target.
              </div>
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={actualVsTargetData} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke={gridColor} vertical={false} />
                  <XAxis dataKey="name" tick={{ fontSize: 11, fontFamily: 'sans-serif', fill: axisColor }} axisLine={false} tickLine={false} />
                  <YAxis tickFormatter={(v) => `${(v / 1000).toLocaleString('id-ID')}K`} tick={{ fontSize: 10, fontFamily: 'monospace', fill: axisColor }} axisLine={false} tickLine={false} />
                  <Tooltip 
                    formatter={(value: any) => [formatRupiah(Number(value)), 'Jumlah']}
                    contentStyle={{ borderRadius: '16px', backgroundColor: tooltipBg, borderColor: tooltipBorder, fontSize: '11px', color: tooltipText }} 
                  />
                  <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '10px' }} />
                  <Bar dataKey="Aktual" fill="#6366f1" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="Target" fill="#10b981" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            )}
          </div>
        </div>

        {/* Current Expense Distribution Pie Chart */}
        <div id="expense_division_chart_box" className={`p-5 backdrop-blur-md border rounded-[2rem] shadow-xl flex flex-col min-h-80 transition-colors ${
          isDark ? 'bg-slate-800/50 border-slate-705' : 'bg-white border-slate-200'
        }`}>
          <div className="mb-4">
            <span className={`px-3 py-1 text-[9px] font-black uppercase rounded-full border ${
              isDark ? 'bg-emerald-500/10 text-emerald-400 border-emerald-555/20' : 'bg-emerald-50 text-emerald-600 border-emerald-200'
            }`}>
              Distribution Engine
            </span>
            <h4 className={`text-sm font-sans font-black mt-2 leading-none ${isDark ? 'text-white' : 'text-slate-900'}`}>
              Distribusi Pengeluaran Aktual
            </h4>
            <p className={`text-[11px] mt-1 ${isDark ? 'text-slate-400' : 'text-slate-500 font-medium'}`}>
              Klasifikasi pengeluaran nyata Anda saat ini berdasarkan kategori 3 PILAR finansial.
            </p>
          </div>
          <div className="flex-1 flex flex-col items-center gap-6 justify-center min-h-[220px]">
            {totalExpense === 0 && netSavings <= 0 ? (
              <div className="w-full h-full flex items-center justify-center text-xs text-slate-500 p-8 text-center border border-dashed border-slate-700 rounded-2xl">
                Belum ada pengeluaran terekam untuk menyusun grafik distribusi.
              </div>
            ) : (
              <>
                <div className="w-44 h-44 shrink-0 relative flex items-center justify-center">
                  {/* Central Text on Pie (Placed before for proper z-layer ordering + pointer-events-none) */}
                  <div className={`absolute text-center backdrop-blur-md p-1 rounded-full w-20 h-20 flex flex-col justify-center border z-0 pointer-events-none ${
                    isDark ? 'bg-slate-900/60 border-slate-800' : 'bg-white/90 border-slate-200 shadow-sm'
                  }`}>
                    <span className="text-[8px] font-sans font-black text-slate-400 uppercase tracking-widest block leading-none">
                      EFFICIENCY
                    </span>
                    <span className={`text-base font-mono font-black mt-0.5 ${isDark ? 'text-white' : 'text-slate-800'}`}>
                      {totalIncome > 0 ? Math.round(((totalIncome - expenseBreakdown.kebutuhan - expenseBreakdown.keinginan) / totalIncome) * 100) : 0}%
                    </span>
                  </div>

                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={pieData}
                        cx="50%"
                        cy="50%"
                        innerRadius={55}
                        outerRadius={75}
                        paddingAngle={3}
                        dataKey="value"
                      >
                        {pieData.map((entry, index) => (
                           <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip 
                        formatter={(value: any) => formatRupiah(Number(value))}
                        contentStyle={{ borderRadius: '16px', backgroundColor: tooltipBg, borderColor: tooltipBorder, fontSize: '11px', color: tooltipText }} 
                        wrapperStyle={{ zIndex: 100, pointerEvents: 'none' }}
                      />
                    </PieChart>
                  </ResponsiveContainer>
                </div>

                {/* Pie legend with amounts and percentages */}
                <div className="space-y-3 w-full max-w-sm">
                  {pieData.map((entry, idx) => {
                    const percentage = totalIncome > 0 ? Math.round((entry.value / totalIncome) * 100) : 0;
                    return (
                      <div key={idx} className={`flex justify-between items-center text-xs border-b pb-1.5 w-full ${isDark ? 'border-slate-800' : 'border-slate-200'}`}>
                        <div className="flex items-center gap-2">
                          <span className="w-2.5 h-2.5 rounded-full shrink-0" style={{ backgroundColor: entry.color }} />
                          <span className={`font-sans font-bold ${isDark ? 'text-slate-300' : 'text-slate-700'}`}>
                            {entry.name}
                          </span>
                        </div>
                        <div className="text-right">
                          <p className={`font-mono font-bold ${isDark ? 'text-white' : 'text-slate-900'}`}>
                            {formatRupiah(entry.value)}
                          </p>
                          <p className={`text-[9px] font-mono ${isDark ? 'text-slate-500' : 'text-slate-400'}`}>
                            {percentage}% of income
                          </p>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </>
            )}
          </div>
        </div>
      </div>

      {/* 4. Progress Pencapaian Target Keuangan */}
      {goals.length > 0 && (
        <div id="dashboard_goals_progress_box" className={`p-6 border rounded-[2rem] shadow-xl relative overflow-hidden transition-all duration-300 flex flex-col ${
          isDark 
            ? 'bg-slate-800/50 border-slate-705' 
            : 'bg-white border-slate-200'
        }`}>
          <div className="mb-6 flex flex-col sm:flex-row sm:justify-between sm:items-center gap-4">
            <div>
              <span className={`px-3 py-1 text-[9px] font-black uppercase rounded-full border inline-block mb-2 ${
                isDark ? 'bg-amber-500/10 text-amber-400 border-amber-500/20' : 'bg-amber-50 text-amber-600 border-amber-200'
              }`}>
                Milestone Tracker
              </span>
              <h4 className={`text-sm font-sans font-black leading-none ${isDark ? 'text-white' : 'text-slate-900'}`}>
                Perkembangan Target Finansial
              </h4>
              <p className={`text-[11px] mt-1.5 ${isDark ? 'text-slate-400' : 'text-slate-500 font-medium'}`}>
                Pantau seberapa dekat Anda mencapai impian dan tujuan finansial yang telah ditentukan.
              </p>
            </div>
            <div className={`text-[10px] font-mono px-3 py-1.5 rounded-xl border shrink-0 ${
               isDark ? 'bg-slate-900/40 text-slate-400 border-slate-800' : 'bg-slate-50 text-slate-500 border-slate-200'
            }`}>
               {goals.filter(g => g.currentAmount >= g.targetAmount).length} dari {goals.length} Tercapai
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {goals.map((goal) => {
              const percentage = Math.min(100, Math.max(0, Math.round((goal.currentAmount / goal.targetAmount) * 100)) || 0);
              const isCompleted = percentage >= 100;
              
              return (
                <div key={goal.id} className={`p-4 rounded-2xl border flex flex-col justify-between transition-all ${
                  isDark 
                    ? 'bg-slate-900/50 border-slate-800/80 hover:border-slate-700' 
                    : 'bg-slate-50 border-slate-200 hover:border-slate-300 hover:shadow-sm'
                }`}>
                  <div className="flex justify-between items-start gap-2 mb-3">
                    <div className="space-y-1">
                      <p className={`font-bold text-xs ${isDark ? 'text-white' : 'text-slate-800'}`}>{goal.name}</p>
                      <p className={`text-[9px] flex items-center gap-1 font-medium ${isDark ? 'text-slate-450' : 'text-slate-500'}`}>
                        <span>Target: {goal.targetDate}</span>
                      </p>
                    </div>
                    <span className={`px-2 py-0.5 text-[8px] font-black uppercase rounded border shrink-0 ${
                      isCompleted 
                        ? (isDark ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20' : 'bg-emerald-100 text-emerald-700 border-emerald-200')
                        : goal.priority === 'high' 
                          ? (isDark ? 'bg-rose-500/10 text-rose-450 border-rose-500/20' : 'bg-rose-50 text-rose-600 border-rose-200')
                          : goal.priority === 'medium'
                            ? (isDark ? 'bg-amber-500/10 text-amber-500 border-amber-500/20' : 'bg-amber-50 text-amber-600 border-amber-200')
                            : (isDark ? 'bg-slate-500/10 text-slate-400 border-slate-500/20' : 'bg-slate-100 text-slate-500 border-slate-300')
                    }`}>
                      {isCompleted ? 'Tercapai' : `Prio: ${goal.priority}`}
                    </span>
                  </div>
                  
                  <div className="space-y-1.5 mt-auto">
                    <div className="flex justify-between text-[10px] font-mono font-black">
                       <span className={isCompleted ? (isDark ? 'text-emerald-400' : 'text-emerald-600') : (isDark ? 'text-slate-300' : 'text-slate-700')}>
                         {formatRupiah(goal.currentAmount)}
                       </span>
                       <span className={isDark ? 'text-slate-500' : 'text-slate-400'}>
                         {formatRupiah(goal.targetAmount)}
                       </span>
                    </div>
                    
                    <div className={`w-full rounded-full h-2 overflow-hidden relative ${isDark ? 'bg-slate-800' : 'bg-slate-200'}`}>
                      <div
                        className={`h-full rounded-full transition-all duration-1000 ${
                          isCompleted 
                            ? 'bg-emerald-500' 
                            : 'bg-gradient-to-r from-indigo-500 to-indigo-400'
                        }`}
                        style={{ width: `${percentage}%` }}
                      />
                    </div>
                    <p className={`text-[9px] text-right font-black ${isCompleted ? (isDark ? 'text-emerald-500' : 'text-emerald-600') : (isDark ? 'text-indigo-400' : 'text-indigo-600')}`}>
                      {percentage}%
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* 5. Ekspor & Unduh Laporan Bento Card */}
      <div id="export_reports_panel_bento" className={`p-6 border rounded-[2rem] relative overflow-hidden transition-all duration-300 ${
          isDark 
            ? 'bg-slate-800/50 border-slate-700 shadow-xl' 
            : 'bg-white border-slate-200 shadow-lg text-slate-850'
        }`}>
        <div className="absolute top-0 right-0 w-64 h-64 bg-emerald-500/5 rounded-full blur-3xl -mr-16 -mt-16 pointer-events-none" />
        
        {/* Header Row */}
        <div className="pb-5 border-b border-slate-800/50 flex flex-col md:flex-row md:items-center justify-between gap-4 relative z-10">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <div className="p-2 bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 rounded-xl">
                <Download className="w-4 h-4" />
              </div>
              <h4 className={`text-xs font-sans font-black uppercase tracking-widest ${
                isDark ? 'text-white' : 'text-slate-900'
              }`}>
                Ekspor & Unduh Laporan Keuangan
              </h4>
            </div>
            <p className={`text-[11px] font-sans leading-relaxed ${
              isDark ? 'text-slate-400' : 'text-slate-600 font-semibold'
            }`}>
              Dapatkan berkas rekapitulasi data transaksi serta analisis alokasi finansial terkalibrasi Anda secara instan.
            </p>
          </div>
          
          <div className={`text-[10px] font-mono px-3 py-1.5 rounded-xl bg-slate-900/40 border text-slate-400 shrink-0 ${
            isDark ? 'border-slate-800' : 'border-slate-200'
          }`}>
            Format Dokumen: PDF (A4) / Tabular CSV
          </div>
        </div>

        {/* Content Row - Grid for pristine layout representation on wide screens */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-5 items-center relative z-10">
          {/* Left Column: Scope Description items */}
          <div className="space-y-3">
            <p className={`text-[11px] font-sans font-bold leading-relaxed ${isDark ? 'text-slate-300' : 'text-slate-700'}`}>
              Data yang dicakup secara otomatis dalam dokumen laporan Anda:
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[10.5px] font-sans">
              <div className={`p-2.5 rounded-xl border flex items-center gap-2 ${
                isDark ? 'bg-slate-905/45 border-slate-800/80 text-slate-300' : 'bg-slate-50 border-slate-200 text-slate-700 font-medium'
              }`}>
                <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 shrink-0"></div>
                <span>Pencatatan Kas Masuk & Keluar</span>
              </div>
              <div className={`p-2.5 rounded-xl border flex items-center gap-2 ${
                isDark ? 'bg-slate-905/45 border-slate-800/80 text-slate-300' : 'bg-slate-50 border-slate-200 text-slate-700 font-medium'
              }`}>
                <div className="w-1.5 h-1.5 rounded-full bg-indigo-500 shrink-0"></div>
                <span>Saran Alokasi 3 Pilar Finansial</span>
              </div>
              <div className={`p-2.5 rounded-xl border flex items-center gap-2 ${
                isDark ? 'bg-slate-905/45 border-slate-800/80 text-slate-300' : 'bg-slate-50 border-slate-200 text-slate-705 font-medium'
              }`}>
                <div className="w-1.5 h-1.5 rounded-full bg-amber-500 shrink-0"></div>
                <span>Perkembangan Skor Kesehatan AI</span>
              </div>
              <div className={`p-2.5 rounded-xl border flex items-center gap-2 ${
                isDark ? 'bg-slate-905/45 border-slate-800/80 text-slate-300' : 'bg-slate-50 border-slate-200 text-slate-705 font-medium'
              }`}>
                <div className="w-1.5 h-1.5 rounded-full bg-pink-500 shrink-0"></div>
                <span>Status Target Pencapaian Impian</span>
              </div>
            </div>
          </div>

          {/* Right Column: Interaction Controls */}
          <div className={`p-4.5 rounded-2xl border space-y-4 flex flex-col justify-between ${
            isDark ? 'bg-slate-900/40 border-slate-800' : 'bg-slate-50/50 border-slate-200 shadow-inner'
          }`}>
            <div className="space-y-2">
              <label className="block text-[8px] font-sans font-black text-slate-500 uppercase tracking-widest leading-none">
                Tentukan Rentang Waktu Laporan:
              </label>
              <div className={`p-1 rounded-xl flex border w-full ${
                isDark 
                  ? 'bg-slate-950 border-slate-800' 
                  : 'bg-white border-slate-250 shadow-sm'
              }`}>
                <button
                  type="button"
                  onClick={() => setExportScope('selected')}
                  className={`flex-1 py-2 px-3.5 rounded-lg text-[10px] font-sans font-black uppercase tracking-wider transition-all cursor-pointer text-center ${
                    exportScope === 'selected'
                      ? 'bg-emerald-600 text-white shadow shadow-emerald-950/20'
                      : isDark ? 'text-slate-400 hover:text-slate-200' : 'text-slate-600 hover:text-slate-850 hover:bg-slate-100'
                  }`}
                >
                  Bulan {formatPeriodLabelID(activePeriod)}
                </button>
                <button
                  type="button"
                  onClick={() => setExportScope('all')}
                  className={`flex-1 py-2 px-3.5 rounded-lg text-[10px] font-sans font-black uppercase tracking-wider transition-all cursor-pointer text-center ${
                    exportScope === 'all'
                      ? 'bg-emerald-600 text-white shadow shadow-emerald-950/20'
                      : isDark ? 'text-slate-400 hover:text-slate-200' : 'text-slate-600 hover:text-slate-850 hover:bg-slate-100'
                  }`}
                >
                  Semua Riwayat Kas
                </button>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3 pt-1">
              <button
                id="btn_export_pdf"
                onClick={handleExportPDF}
                className="inline-flex items-center justify-center gap-2 py-3 px-4 rounded-xl text-[10px] sm:text-xs font-sans font-black uppercase tracking-wider text-white bg-indigo-600 hover:bg-indigo-550 transition cursor-pointer active:scale-95 shadow-md shadow-indigo-900/15 whitespace-nowrap"
                title="Unduh laporan berformat PDF"
              >
                <FileText className="w-4 h-4" />
                <span>Unduh PDF</span>
              </button>
              <button
                id="btn_export_csv"
                onClick={handleExportCSV}
                className={`inline-flex items-center justify-center gap-2 py-3 px-4 rounded-xl text-[10px] sm:text-xs font-sans font-black uppercase tracking-wider transition cursor-pointer active:scale-95 border shadow-md whitespace-nowrap ${
                  isDark
                    ? 'bg-slate-900 hover:bg-slate-850 text-emerald-400 hover:text-emerald-300 border-slate-800 hover:border-slate-750'
                    : 'bg-white hover:bg-slate-50 text-emerald-600 hover:text-emerald-750 border-slate-200 hover:border-slate-300'
                }`}
                title="Unduh data berformat CSV spreadsheet"
              >
                <FileSpreadsheet className="w-4 h-4" />
                <span>Unduh CSV</span>
              </button>
            </div>
          </div>
        </div>
      </div>
      </div>
  );
}
