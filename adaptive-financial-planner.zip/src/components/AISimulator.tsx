import { useState, useMemo, useEffect, KeyboardEvent } from 'react';
import { 
  Sparkles, 
  Loader2, 
  HelpCircle, 
  AlertCircle, 
  CheckCircle, 
  ChevronRight, 
  Minus, 
  Plus, 
  Calendar,
  Zap,
  RotateCcw,
  Check,
  Sliders,
  Settings,
  Send,
  Trash2,
  Link2,
  User,
  Briefcase,
  Laptop,
  GraduationCap
} from 'lucide-react';
import { Income, Expense, Goal, AIAdvice, SimulatorState } from '../types';

interface AISimulatorProps {
  incomes: Income[];
  expenses: Expense[];
  allIncomes?: Income[];
  allExpenses?: Expense[];
  goals: Goal[];
  aiAdvice: AIAdvice | null;
  onSetAIAdvice: (advice: AIAdvice) => void;
  activePeriod?: string;
  isDark?: boolean;
}

export function AISimulator({ 
  incomes, 
  expenses, 
  allIncomes, 
  allExpenses, 
  goals, 
  aiAdvice, 
  onSetAIAdvice,
  activePeriod,
  isDark = true
}: AISimulatorProps) {
  const [loading, setLoading] = useState(false);
  const [errorStatus, setErrorStatus] = useState<string | null>(null);

  // Sub Tab for Gemini Advisor Report vs. Interactive Chat Panel
  const [aiSubTab, setAiSubTab] = useState<'advisor' | 'chat'>('advisor');

  // SakuAI Interactive Chat States
  const [chatInput, setChatInput] = useState('');
  const [chatMessages, setChatMessages] = useState<Array<{ role: 'user' | 'assistant'; text: string; timestamp: string }>>([
    {
      role: 'assistant',
      text: 'Halo! Saya adalah **AdaptSaku AI Assistant**, asisten finansial personal Anda. Saya sudah siap membaca ringkasan rencana transaksi Anda. Ada keputusan keuangan atau penghematan anggaran yang ingin didiskusikan hari ini?',
      timestamp: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })
    }
  ]);
  const [chatLoading, setChatLoading] = useState(false);
  const [userProfile, setUserProfile] = useState<'umum' | 'karyawan' | 'freelancer' | 'mahasiswa'>('umum');

  // States for custom multi-period configuration
  const [enableMultiPeriod, setEnableMultiPeriod] = useState(true);
  const [connectPastMonths, setConnectPastMonths] = useState(12);
  const [connectFutureMonths, setConnectFutureMonths] = useState(12);
  const [showConfig, setShowConfig] = useState(false);

  // Allow independent period selection inside the simulator for maximum personalization
  const [selectedPeriod, setSelectedPeriod] = useState(activePeriod || '2026-05');

  // Sync selectedPeriod with parent activePeriod to make switching dashboard elegant
  useEffect(() => {
    if (activePeriod) {
      setSelectedPeriod(activePeriod);
    }
  }, [activePeriod]);

  // Unique periods list calculated internally from all available data
  const uniquePeriodsInSimulator = useMemo(() => {
    const periods = new Set<string>();
    
    // Default system seed periods so there are options immediately
    periods.add('2026-02');
    periods.add('2026-03');
    periods.add('2026-04');
    periods.add('2026-05');
    periods.add('2026-06');
    periods.add('2026-07');

    const listInc = allIncomes || incomes;
    const listExp = allExpenses || expenses;

    listInc.forEach(i => {
      if (i.date && i.date.length >= 7) {
        const ym = i.date.substring(0, 7);
        if (/^\d{4}-\d{2}$/.test(ym)) {
          periods.add(ym);
        }
      }
    });

    listExp.forEach(e => {
      if (e.date && e.date.length >= 7) {
        const ym = e.date.substring(0, 7);
        if (/^\d{4}-\d{2}$/.test(ym)) {
          periods.add(ym);
        }
      }
    });

    return Array.from(periods).sort();
  }, [allIncomes, incomes, allExpenses, expenses]);

  // Format helper for dropdown label
  const formatPeriodLabel = (p: string) => {
    const MONTH_NAMES: { [key: string]: string } = {
      '01': 'Januari', '02': 'Februari', '03': 'Maret', '04': 'April',
      '05': 'Mei', '06': 'Juni', '07': 'Juli', '08': 'Agustus',
      '09': 'September', '10': 'Oktober', '11': 'November', '12': 'Desember'
    };
    const parts = p.split('-');
    if (parts.length !== 2) return p;
    const [year, month] = parts;
    const monthName = MONTH_NAMES[month] || month;
    return `${monthName} ${year}`;
  };

  // Dynamically filter incomes & expenses for the selected target period
  const currentIncomes = useMemo(() => {
    const list = allIncomes || incomes;
    return list.filter(i => i.date && i.date.startsWith(selectedPeriod));
  }, [allIncomes, incomes, selectedPeriod]);

  const currentExpenses = useMemo(() => {
    const list = allExpenses || expenses;
    return list.filter(e => e.date && e.date.startsWith(selectedPeriod));
  }, [allExpenses, expenses, selectedPeriod]);

  // Loading process descriptive state messages
  const [loadingStep, setLoadingStep] = useState('Menghubungkan ke Gemini AI...');

  // Simulator state variables
  const [incomeFactor, setIncomeFactor] = useState<number>(100); // percentage (50% to 150%)
  const [wantsCut, setWantsCut] = useState<number>(0); // percentage (0% to 100%)
  const [needsCut, setNeedsCut] = useState<number>(0); // percentage (0% to 50%)

  const totalIncomeOriginal = useMemo(() => currentIncomes.reduce((s, i) => s + i.amount, 0), [currentIncomes]);
  const totalExpenseOriginal = useMemo(() => currentExpenses.reduce((s, e) => s + e.amount, 0), [currentExpenses]);
  
  const expenseBreakdownOriginal = useMemo(() => {
    let kebutuhan = 0;
    let keinginan = 0;
    let tabungan = 0;
    currentExpenses.forEach(e => {
      if (e.category === 'kebutuhan') kebutuhan += e.amount;
      else if (e.category === 'keinginan') keinginan += e.amount;
      else if (e.category === 'tabungan') tabungan += e.amount;
    });
    return { kebutuhan, keinginan, tabungan };
  }, [currentExpenses]);

  // Handle triggering server-side Gemini analysis
  const handleAnalyzeFn = async () => {
    setLoading(true);
    setErrorStatus(null);
    setLoadingStep('Memformulasikan profil keuangan Anda...');
    
    // Simulate minor countdowns for premium loading feel
    setTimeout(() => {
      setLoadingStep('Menganalisis pengeluaran & prioritas tujuan...');
    }, 1000);

    setTimeout(() => {
      setLoadingStep('Merakit strategi alokasi adaptif personal...');
    }, 2200);

    try {
      const response = await fetch('/api/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          incomes: currentIncomes, 
          expenses: currentExpenses, 
          goals,
          allIncomes: allIncomes || incomes,
          allExpenses: allExpenses || expenses,
          activePeriod: selectedPeriod,
          enableMultiPeriod,
          connectPastMonths,
          connectFutureMonths
        }),
      });

      if (!response.ok) {
        throw new Error(`Gagal memuat rekomendasi AI. Status Server: ${response.status}`);
      }

      const recommendation = await response.json();
      onSetAIAdvice(recommendation);
    } catch (e: any) {
      console.error(e);
      setErrorStatus(e.message || 'Kesalahan jaringan saat menghubungi asisten AI.');
    } finally {
      setLoading(false);
    }
  };

  // Quick template insertion helper
  const handleTemplateClick = (text: string) => {
    setChatInput(text);
    setTimeout(() => {
      document.getElementById('sim-chat-input')?.focus();
    }, 50);
  };

  // 2. LIVE BUDGET SIMULATOR CALCULATIONS
  const simIncome = (totalIncomeOriginal * incomeFactor) / 100;
  const simKebutuhan = expenseBreakdownOriginal.kebutuhan * (1 - needsCut / 100);
  const simKeinginan = expenseBreakdownOriginal.keinginan * (1 - wantsCut / 100);
  const simTabunganDirect = expenseBreakdownOriginal.tabungan;
  const simTotalExpense = simKebutuhan + simKeinginan + simTabunganDirect;
  const simNetSavings = simIncome - simTotalExpense;

  // Simulator impacts on target goals
  const simulatedGoalsProjections = useMemo(() => {
    return goals.map(goal => {
      const neededAmount = goal.targetAmount - goal.currentAmount;
      if (neededAmount <= 0) {
        return {
          ...goal,
          monthsToAchieve: 0,
          status: 'Tercapai',
          note: 'Target tabungan ini sudah berhasil Anda selesaikan!'
        };
      }

      // Distribute net savings proportionally or based on priority
      // Let's assume high priority gets 50% of monthly net surplus, medium gets 30%, low gets 20%
      let priorityWeight = 0.2;
      if (goal.priority === 'high') priorityWeight = 0.5;
      else if (goal.priority === 'medium') priorityWeight = 0.3;

      const monthlyAllocation = Math.max(0, simNetSavings) * priorityWeight;

      if (monthlyAllocation <= 0) {
        return {
          ...goal,
          monthsToAchieve: Infinity,
          status: 'Terhambat',
          note: 'Tidak ada kapasitas surplus tabungan bulanan saat ini untuk mendanai rencana ini.'
        };
      }

      const months = Math.ceil(neededAmount / monthlyAllocation);
      
      // Calculate target date comparison
      const targetDateObj = new Date(goal.targetDate);
      const currentDateObj = new Date();
      const monthsAvailable = (targetDateObj.getFullYear() - currentDateObj.getFullYear()) * 12 + (targetDateObj.getMonth() - currentDateObj.getMonth());

      let status = 'Tepat Waktu';
      let note = `Diperkirakan selesai dalam ${months} bulan jika menyisihkan ${formatRupiah(monthlyAllocation)}/bulan.`;

      if (months > monthsAvailable) {
        status = 'Butuh Penyesuaian';
        note = `Target meleset ${months - monthsAvailable} bulan dari tenggat waktu Anda. Naikkan komitmen tabungan Anda.`;
      }

      return {
        ...goal,
        monthsToAchieve: months,
        status,
        note,
        monthlyAllocation
      };
    });
  }, [goals, simNetSavings]);

  // Interactive SakuAI Chat Handlers
  const handleKeyDown = (e: KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendChatMessage();
    }
  };

  const handleSendChatMessage = async (presetText?: string) => {
    const textToSend = presetText || chatInput;
    if (!textToSend.trim() || chatLoading) return;

    // Add user message to state
    const userMsg = {
      role: 'user' as const,
      text: textToSend,
      timestamp: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })
    };

    setChatMessages(prev => [...prev, userMsg]);
    if (!presetText) {
      setChatInput('');
    }
    setChatLoading(true);

    try {
      // Map existing messages to history format expected by the API
      const conversationalHistory = chatMessages.map(msg => ({
        role: msg.role === 'user' ? 'user' : 'model',
        text: msg.text
      }));

      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: textToSend,
          history: conversationalHistory,
          incomes: currentIncomes,
          expenses: currentExpenses,
          goals,
          activePeriod: selectedPeriod
        })
      });

      if (!response.ok) {
        throw new Error('Asisten AI gagal memahami obrolan.');
      }

      const data = await response.json();
      setChatMessages(prev => [...prev, {
        role: 'assistant' as const,
        text: data.text,
        timestamp: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })
      }]);
    } catch (e: any) {
      console.error(e);
      setChatMessages(prev => [...prev, {
        role: 'assistant' as const,
        text: '⚠️ **Maaf**: Hubungan komunikasi finansial terjeda atau server asisten sedang sibuk. Silakan kirim ulang pertanyaan Anda beberapa saat lagi.',
        timestamp: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })
      }]);
    } finally {
      setChatLoading(false);
    }
  };

  const handleClearChat = () => {
    setChatMessages([
      {
        role: 'assistant',
        text: 'Obrolan telah dibersihkan. AdaptSaku AI Assistant siap melayani Anda kembali! Silakan tanyakan apa saja tentang pencatatan keuangan atau tujuan impian tabungan Anda.',
        timestamp: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })
      }
    ]);
    setChatInput('');
  };

  // Natively rendering parsed basic Markdown for neat styling inside JSX chat bubbles
  function parseMarkdown(text: string) {
    if (!text) return null;
    return text.split('\n').map((line, lineIdx) => {
      let content = line.trim();
      
      // Headers
      if (content.startsWith('###')) {
        return (
          <h5 key={lineIdx} className={`text-xs font-black mt-2.5 mb-1.5 uppercase tracking-wide ${isDark ? 'text-emerald-400' : 'text-emerald-700 font-extrabold'}`}>
            {renderInlineMarkdown(content.replace(/^###\s*/, ''))}
          </h5>
        );
      }
      if (content.startsWith('##')) {
        return (
          <h4 key={lineIdx} className={`text-sm font-black mt-3.5 mb-2 uppercase tracking-wide border-b pb-0.5 ${isDark ? 'text-emerald-300 border-white/5' : 'text-emerald-600 border-slate-205 pb-1'}`}>
            {renderInlineMarkdown(content.replace(/^##\s*/, ''))}
          </h4>
        );
      }
      
      // Bullets
      if (content.startsWith('-') || content.startsWith('*') && !content.startsWith('***')) {
        return (
          <div key={lineIdx} className="flex items-start gap-2 ml-1 my-1">
            <span className="text-emerald-550 mt-1 shrink-0 font-extrabold">•</span>
            <p className={`text-xs leading-relaxed font-semibold ${isDark ? 'text-slate-300 font-medium' : 'text-slate-700'}`}>
              {renderInlineMarkdown(content.replace(/^[-*]\s*/, ''))}
            </p>
          </div>
        );
      }

      // Order bullets with numbers like "1."
      const numMatch = content.match(/^(\d+)\.\s(.*)/);
      if (numMatch) {
        return (
          <div key={lineIdx} className="flex items-start gap-2 ml-1 my-1">
            <span className={`font-mono text-[11px] mt-0.5 shrink-0 font-extrabold ${isDark ? 'text-emerald-400' : 'text-emerald-700'}`}>{numMatch[1]}.</span>
            <p className={`text-xs leading-relaxed font-semibold ${isDark ? 'text-slate-300' : 'text-slate-700'}`}>
              {renderInlineMarkdown(numMatch[2])}
            </p>
          </div>
        );
      }
      
      // Empty line
      if (content === '') {
        return <div key={lineIdx} className="h-2" />;
      }
      
      return (
        <p key={lineIdx} className={`text-xs leading-relaxed font-medium my-0.5 ${isDark ? 'text-slate-300' : 'text-slate-705'}`}>
          {renderInlineMarkdown(line)}
        </p>
      );
    });
  }

  function renderInlineMarkdown(text: string) {
    const parts = text.split(/\*\*([^*]+)\*\*/g);
    return parts.map((part, i) => {
      if (i % 2 === 1) {
        return <strong key={i} className={`font-black ${isDark ? 'text-white' : 'text-slate-900 border-b border-dashed border-slate-300/60 pb-0.5'}`}>{part}</strong>;
      }
      
      const italicParts = part.split(/\*([^*]+)\*/g);
      return italicParts.map((subPart, j) => {
        if (j % 2 === 1) {
          return <em key={j} className={`font-bold italic ${isDark ? 'text-amber-200' : 'text-indigo-600 bg-indigo-50/50 px-1 py-0.5 rounded'}`}>{subPart}</em>;
        }
        return subPart;
      });
    });
  }

  // Helper formats
  function formatRupiah(val: number) {
    if (val === Infinity) return 'Tak terbatas';
    return new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(val);
  }

  // Reset simulator values
  const handleResetSimulator = () => {
    setIncomeFactor(100);
    setWantsCut(0);
    setNeedsCut(0);
  };

  return (
    <div id="ai_simulator_tab_container" className="space-y-8 animate-fade-in">
       {/* SECTION 1: AI ADVICE WITH INTEGRATED CHAT AND ADVISOR REPORT */}
      <div className={`backdrop-blur-md border rounded-[2rem] p-6 md:p-8 space-y-6 transition-all duration-300 ${
        isDark 
          ? 'bg-slate-800/50 border-slate-700/80 shadow-xl' 
          : 'bg-white border-slate-200/80 shadow-lg text-slate-850'
      }`}>
        
        {/* SHARED HEADER WITH ADVANCED SUB-TABS SELECTOR */}
        <div className={`flex flex-col lg:flex-row lg:items-center justify-between gap-6 border-b pb-5 ${
          isDark ? 'border-slate-705' : 'border-slate-205/60'
        }`}>
          <div className="space-y-2 w-full">
            <div className="flex items-center gap-2.5">
              <span className="p-2 bg-gradient-to-r from-emerald-500/20 to-teal-500/20 border border-emerald-500/30 rounded-xl text-emerald-400">
                <Sparkles className="w-5 h-5 animate-pulse" />
              </span>
              <h3 className={`text-lg font-sans font-black leading-snug uppercase tracking-wider ${
                isDark ? 'text-white' : 'text-slate-900'
              }`}>
                Asisten Keuangan Adaptif AI
              </h3>
            </div>
            <p className={`text-xs max-w-xl ${
              isDark ? 'text-slate-400' : 'text-slate-600 font-medium'
            }`}>
              Audit cerdas keuangan bulanan atau mengobrol secara interaktif membahas keputusan finansial Anda secara langsung.
            </p>

            <div className="flex flex-wrap items-center gap-3 pt-2">
              {/* INTERACTIVE SUbtab Toggles */}
              <div className={`flex p-1 rounded-xl border ${
                isDark 
                  ? 'bg-slate-950 border-slate-800' 
                  : 'bg-slate-100 border-slate-200/85 shadow-sm'
              }`}>
                <button
                  type="button"
                  onClick={() => setAiSubTab('advisor')}
                  className={`py-1.5 px-4 rounded-lg text-[10px] font-sans font-black uppercase tracking-widest transition-all duration-200 cursor-pointer ${
                    aiSubTab === 'advisor'
                      ? 'bg-emerald-600 text-white shadow-md shadow-emerald-900/20 font-black'
                      : isDark
                        ? 'text-slate-400 hover:text-slate-100 hover:bg-slate-900/30'
                        : 'text-slate-600 hover:text-emerald-700 hover:bg-slate-200/50 font-extrabold'
                  }`}
                >
                  Analisis Alokasi
                </button>
                <button
                  type="button"
                  onClick={() => setAiSubTab('chat')}
                  className={`py-1.5 px-4 rounded-lg text-[10px] font-sans font-black uppercase tracking-widest transition-all duration-200 cursor-pointer flex items-center gap-1.5 ${
                    aiSubTab === 'chat'
                      ? 'bg-emerald-600 text-white shadow-md shadow-emerald-900/20 font-black'
                      : isDark
                        ? 'text-slate-400 hover:text-slate-100 hover:bg-slate-900/30'
                        : 'text-slate-600 hover:text-emerald-700 hover:bg-slate-200/50 font-extrabold'
                  }`}
                >
                  <span>AI Chat</span>
                  <span className="relative flex h-1.5 w-1.5 font-bold">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-teal-400 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-1.5 w-1.5 bg-teal-400"></span>
                  </span>
                </button>
              </div>

              {/* SHARED TRANSACTIONS PERIOD SELECTOR */}
              <div className={`flex items-center gap-2 rounded-xl px-3 py-1.5 border shadow-inner transition-colors duration-300 ${
                isDark 
                  ? 'bg-slate-900/60 border-slate-700/60' 
                  : 'bg-emerald-50/65 border-emerald-100/90 shadow-sm'
              }`}>
                <Calendar className={`w-4 h-4 shrink-0 ${isDark ? 'text-emerald-400' : 'text-emerald-600'}`} />
                <span className={`text-[11px] font-sans font-bold uppercase tracking-wider ${
                  isDark ? 'text-slate-300' : 'text-emerald-800'
                }`}>
                  Periode Anggaran:
                </span>
                <select
                  value={selectedPeriod}
                  onChange={(e) => setSelectedPeriod(e.target.value)}
                  className={`bg-transparent border-none font-mono font-bold text-xs cursor-pointer focus:outline-none focus:ring-0 pr-2 select-custom ${
                    isDark ? 'text-emerald-300' : 'text-emerald-600 font-extrabold'
                  }`}
                >
                  {uniquePeriodsInSimulator.map((p) => (
                    <option 
                      key={p} 
                      value={p} 
                      className={`font-mono font-bold ${
                        isDark ? 'bg-slate-950 text-emerald-300' : 'bg-white text-emerald-800'
                      }`}
                    >
                      {formatPeriodLabel(p).toUpperCase()}
                    </option>
                  ))}
                </select>
              </div>

              {/* MULTI PERIOD STATUS AND TOGGLE DISPLAY - Only active for Advisor reports */}
              {aiSubTab === 'advisor' && (
                <>
                  <span className={`inline-flex items-center gap-1.5 text-[10px] sm:text-[11px] font-mono font-bold py-1.5 px-3 border rounded-full transition-all duration-300 ${
                    enableMultiPeriod 
                      ? isDark 
                        ? 'bg-emerald-500/10 text-emerald-300 border-emerald-500/20' 
                        : 'bg-emerald-50 text-emerald-700 border-emerald-200 shadow-sm'
                      : isDark
                        ? 'bg-rose-500/10 text-rose-400 border-rose-500/20' 
                        : 'bg-rose-50 text-rose-700 border-rose-200 shadow-sm'
                  }`}>
                    <span className={`w-1.5 h-1.5 rounded-full ${enableMultiPeriod ? 'bg-emerald-500 animate-pulse' : 'bg-rose-500'}`} />
                    {enableMultiPeriod ? (
                      `Multi-Periode: ${connectPastMonths} Lalu ➔ ${connectFutureMonths} Rencana`
                    ) : (
                      'Multi-Periode: NONAKTIF'
                    )}
                  </span>

                  <button
                    type="button"
                    onClick={() => setShowConfig(!showConfig)}
                    className={`inline-flex items-center gap-1.5 text-[10px] sm:text-[11px] font-sans font-black uppercase tracking-wider py-1.5 px-3 rounded-full border transition-all duration-300 cursor-pointer ${
                      showConfig 
                        ? isDark
                          ? 'bg-amber-500/20 border-amber-500/40 text-amber-300 shadow-lg' 
                          : 'bg-amber-50 border-amber-200 text-amber-700 shadow-sm'
                        : isDark
                          ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-400 hover:text-white hover:bg-emerald-600'
                          : 'bg-emerald-50 border-emerald-200 text-emerald-600 hover:bg-emerald-100 shadow-sm'
                    }`}
                  >
                    <Link2 className="w-3.5 h-3.5" />
                    {showConfig ? 'Tutup Rantai' : 'Atur Rantai'}
                  </button>
                </>
              )}
            </div>
          </div>

          {/* TRIGGER ACTION BUTTON (FOR REPORT ANALYZER TAB ONLY) */}
          {aiSubTab === 'advisor' && (
            <button
              id="btn_trigger_ai"
              onClick={handleAnalyzeFn}
              disabled={loading || totalIncomeOriginal === 0}
              className={`cursor-pointer px-6 py-3.5 rounded-xl font-sans text-xs font-black uppercase tracking-widest shadow-lg flex items-center justify-center gap-2 transition-all duration-300 ${
                totalIncomeOriginal === 0
                  ? 'bg-slate-850 text-slate-500 border border-slate-800 cursor-not-allowed'
                  : 'bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white hover:scale-[1.02]'
              }`}
            >
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  MENGANALISIS...
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  Rekomendasi Alokasi AI
                </>
              )}
            </button>
          )}
        </div>

        {/* TAB 1 CONTENT: STANDARD REPORT ADVISOR */}
        {aiSubTab === 'advisor' ? (
          <div className="space-y-6">
            
            {/* IN-LINE PERIOD CONNECTIONS CONFIGURATION */}
            {showConfig && (
              <div id="ai_period_chain_settings" className={`p-5 border rounded-2xl space-y-4 animate-fade-in ${
                isDark 
                  ? 'bg-slate-950/70 border-slate-800 text-white' 
                  : 'bg-slate-50 border-slate-200 text-slate-900'
              }`}>
                <div className={`flex items-center justify-between border-b pb-3 ${
                  isDark ? 'border-slate-800/80' : 'border-slate-200'
                }`}>
                  <div className="flex items-center gap-2">
                    <Settings className={`w-4 h-4 ${isDark ? 'text-emerald-400' : 'text-emerald-600'}`} />
                    <span className={`text-xs font-sans font-black uppercase tracking-wider ${
                      isDark ? 'text-slate-200' : 'text-slate-800'
                    }`}>
                      Pengaturan Koneksi Multi-Periode AI
                    </span>
                  </div>
                  
                  {/* ON / OFF Switch */}
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input 
                      type="checkbox" 
                      className="sr-only peer" 
                      checked={enableMultiPeriod} 
                      onChange={() => setEnableMultiPeriod(!enableMultiPeriod)} 
                    />
                    <div className={`w-9 h-5 rounded-full transition-colors relative peer peer-checked:after:translate-x-full after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:rounded-full after:h-4 after:w-4 after:transition-all ${
                      isDark 
                        ? 'bg-slate-800 after:bg-slate-400 peer-checked:bg-emerald-500 peer-checked:after:bg-slate-950' 
                        : 'bg-slate-200 after:bg-white peer-checked:bg-emerald-500 peer-checked:after:bg-white shadow-inner'
                    }`}></div>
                    <span className={`ml-2.5 text-xs font-mono font-medium ${
                      isDark ? 'text-slate-400' : 'text-slate-600 font-bold'
                    }`}>
                      {enableMultiPeriod ? 'AKTIF' : 'NONAKTIF'}
                    </span>
                  </label>
                </div>

                {enableMultiPeriod ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {/* PAST MONTHS CONNECT */}
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className={`text-xs font-sans font-bold ${
                          isDark ? 'text-slate-300' : 'text-slate-705'
                        }`}>
                          Riwayat Masa Lalu
                        </span>
                        <span className={`text-xs font-mono font-bold py-0.5 px-2 rounded-md ${
                          isDark ? 'text-emerald-300 bg-emerald-500/10' : 'text-emerald-700 bg-emerald-100'
                        }`}>
                          {connectPastMonths} Bulan ke Belakang
                        </span>
                      </div>
                      <p className={`text-[10px] leading-normal ${
                        isDark ? 'text-slate-500' : 'text-slate-600'
                      }`}>
                        Menghubungkan data historis pengeluaran dan pemasukan riil periode sebelumnya agar AI mendeteksi perubahan kebiasaan.
                      </p>
                      <input 
                        type="range" 
                        min="0" 
                        max="24" 
                        step="1"
                        value={connectPastMonths}
                        onChange={(e) => setConnectPastMonths(Number(e.target.value))}
                        className={`w-full h-1 rounded-lg appearance-none cursor-pointer accent-emerald-500 ${
                          isDark ? 'bg-slate-800' : 'bg-slate-200'
                        }`}
                      />
                      <div className={`flex justify-between text-[10px] font-mono ${
                        isDark ? 'text-slate-600' : 'text-slate-500 font-medium'
                      }`}>
                        <span>0 (Hanya Berjalan)</span>
                        <span>Seluruh Histori (Max 24)</span>
                      </div>
                    </div>

                    {/* FUTURE MONTHS CONNECT */}
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className={`text-xs font-sans font-bold ${
                          isDark ? 'text-slate-300' : 'text-slate-705'
                        }`}>
                          Rencana Masa Depan
                        </span>
                        <span className={`text-xs font-mono font-bold py-0.5 px-2 rounded-md ${
                          isDark ? 'text-indigo-300 bg-indigo-500/10' : 'text-indigo-700 bg-indigo-100'
                        }`}>
                          {connectFutureMonths} Bulan Perencanaan
                        </span>
                      </div>
                      <p className={`text-[10px] leading-normal ${
                        isDark ? 'text-slate-500' : 'text-slate-600'
                      }`}>
                        Menganalisis anggaran masa depan untuk memastikan sisa tabungan dan perkiraan AdaptSaku Anda selaras demi kelayakan impian Anda.
                      </p>
                      <input 
                        type="range" 
                        min="0" 
                        max="24" 
                        step="1"
                        value={connectFutureMonths}
                        onChange={(e) => setConnectFutureMonths(Number(e.target.value))}
                        className={`w-full h-1 rounded-lg appearance-none cursor-pointer accent-indigo-500 ${
                          isDark ? 'bg-slate-800' : 'bg-slate-200'
                        }`}
                      />
                      <div className={`flex justify-between text-[10px] font-mono ${
                        isDark ? 'text-slate-600' : 'text-slate-500 font-medium'
                      }`}>
                        <span>0 (Hanya Berjalan)</span>
                        <span>Max 24 Bulan</span>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className={`p-4 rounded-xl border ${
                    isDark ? 'bg-rose-500/5 border-rose-500/10' : 'bg-rose-50 border-rose-200'
                  }`}>
                    <p className={`text-[11px] leading-normal ${
                      isDark ? 'text-rose-400' : 'text-rose-700 font-semibold'
                    }`}>
                      💡 <strong>Rantai Dimatikan:</strong> Rekomendasi AI hanya akan memproses aset AdaptSaku Anda khusus pada bulan berjalan tanpa melakukan tinjauan histori performa tabungan turun/naik.
                    </p>
                  </div>
                )}
              </div>
            )}

            {/* ERROR AND PROGRESS BOXES */}
            {loading && (
              <div id="ai_loading_spinner" className="p-10 bg-slate-900/60 rounded-2xl border border-dashed border-slate-700 flex flex-col items-center justify-center space-y-4">
                <Loader2 className="w-10 h-10 text-emerald-400 animate-spin" />
                <div className="text-center space-y-1">
                  <p className="text-xs font-black uppercase tracking-widest text-[#a855f7]">{loadingStep}</p>
                  <p className="text-[10px] text-slate-400">Sistem sedang merumuskan kecocokan pengeluaran menjadi mitigasi yang kokoh.</p>
                </div>
              </div>
            )}

            {errorStatus && (
              <div className="p-4 bg-rose-500/10 border border-rose-500/20 rounded-xl flex items-start gap-3 text-rose-300 text-xs">
                <AlertCircle className="w-4 h-4 mt-0.5 shrink-0" />
                <div>
                  <p className="font-bold uppercase tracking-wider">Gagal menghitung rekomendasi AI</p>
                  <p className="mt-1 font-mono text-[10px] text-rose-400/80">{errorStatus}</p>
                </div>
              </div>
            )}

            {/* EMPTY STATUS EXPLANATION */}
            {!aiAdvice && !loading && (
              <div className="p-10 border border-dashed border-slate-700 rounded-[2rem] text-center space-y-4 bg-slate-900/40">
                <div className="w-12 h-12 bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 flex items-center justify-center rounded-full mx-auto">
                  <HelpCircle className="w-6 h-6" />
                </div>
                <div className="max-w-md mx-auto space-y-2">
                  <p className="text-xs font-black uppercase tracking-wider text-slate-200">Mari dapatkan Analisis Adaptabilitas AI pertama Anda!</p>
                  <p className="text-[11px] text-slate-400 leading-relaxed">
                    Asisten AI akan mendeteksi kesehatan keuangan, menyusun formula 3 Pilar (Needs, Wants, Savings) adaptif sesuai sisa belanjaan, dan memandu alur pelunasan target.
                    {totalIncomeOriginal === 0 && (
                      <span className="block font-semibold text-rose-400 mt-2">
                        *Harap tambahkan minimal 1 entri pemasukan terlebih dahulu sebelum memicu penganalisis AI.
                      </span>
                    )}
                  </p>
                </div>
              </div>
            )}

            {/* RESULTS VIEW */}
            {aiAdvice && !loading && (
              <div id="ai_advice_results_panel" className="space-y-6">
                
                {/* STATUS BAR */}
                <div className={`p-4 rounded-2xl border flex gap-3 ${
                  aiAdvice.urgencyLevel === 'Aman' ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-300' :
                  aiAdvice.urgencyLevel === 'Waspada' ? 'bg-amber-500/10 border-amber-500/20 text-amber-300' :
                  'bg-rose-500/10 border-rose-500/20 text-rose-300'
                }`}>
                  <div className="shrink-0 mt-0.5">
                    {aiAdvice.urgencyLevel === 'Aman' ? <CheckCircle className="w-5 h-5 text-emerald-400" /> :
                     aiAdvice.urgencyLevel === 'Waspada' ? <AlertCircle className="w-5 h-5 text-amber-400" /> :
                     <AlertCircle className="w-5 h-5 text-rose-400" />}
                  </div>
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-black uppercase tracking-widest">
                        Status Tingkat Risiko: {aiAdvice.urgencyLevel}
                      </span>
                      {(aiAdvice as any).isDemo && (
                        <span className="text-[9px] bg-slate-800 px-1.5 py-0.5 rounded font-mono text-slate-400 border border-slate-700">
                          Simulasi
                        </span>
                      )}
                    </div>
                    <p className="text-xs leading-relaxed text-slate-300 text-left">
                      {aiAdvice.summary}
                    </p>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-white text-left">
                  {/* PILARS STATS */}
                  <div className="space-y-3">
                    <h4 className="text-xs font-black text-slate-400 uppercase tracking-widest flex items-center gap-1.5">
                      <Zap className="w-4 h-4 text-amber-400" /> Langkah Adaptif Terpilih
                    </h4>
                    <div className="space-y-2">
                      {aiAdvice.suggestions.map((suggestion, idx) => (
                        <div key={idx} className="p-3 bg-slate-900/40 rounded-xl border border-slate-800 flex items-start gap-2.5">
                          <ChevronRight className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                          <p className="text-xs text-slate-300 leading-relaxed font-medium">
                            {suggestion}
                          </p>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* GOALS EVALUATION */}
                  <div className="space-y-3">
                    <h4 className="text-xs font-black text-slate-400 uppercase tracking-widest">
                      Evaluasi Tujuan Finansial Anda
                    </h4>
                    <div className="space-y-2 max-h-72 overflow-y-auto pr-1">
                      {goals.length === 0 ? (
                        <div className="text-center py-6 text-xs text-slate-505 border border-dashed border-slate-800 rounded-xl">
                          Belum ada tujuan terdaftar untuk dianalisis oleh AI.
                        </div>
                      ) : (
                        aiAdvice.goalsAnalysis.map((gAnalysis) => {
                          const associatedGoal = goals.find(g => g.id === gAnalysis.goalId);
                          if (!associatedGoal) return null;

                          return (
                            <div key={gAnalysis.goalId} className="p-3.5 rounded-xl border border-slate-800/80 space-y-2 bg-slate-900/30">
                              <div className="flex justify-between items-center text-xs">
                                <span className="font-bold text-white">{associatedGoal.name}</span>
                                <span className={`text-[9px] font-black uppercase px-2 py-0.5 rounded-full border ${
                                  gAnalysis.feasibility === 'Mudah Tercapai' ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20' :
                                  gAnalysis.feasibility === 'Sangat Menantang' ? 'bg-rose-500/10 text-rose-400 border-rose-500/20' :
                                  'bg-amber-500/10 text-amber-400 border-amber-500/20'
                                }`}>
                                  {gAnalysis.feasibility}
                                </span>
                              </div>
                              <p className="text-[11px] text-slate-400 leading-relaxed font-medium">
                                {gAnalysis.advice}
                              </p>
                            </div>
                          );
                        })
                      )}
                    </div>
                  </div>
                </div>

              </div>
            )}
          </div>
        ) : (
          
          /* TAB 2 CONTENT: SAKUCHAT INTERACTIVE AI FINANCIAL DIALOGUE */
          <div id="shared_saku_chat_interface" className={`space-y-4 ${isDark ? 'text-white' : 'text-slate-800'}`}>
            <div className={`border rounded-3xl overflow-hidden flex flex-col h-[680px] sm:h-[720px] shadow-2xl relative ${
              isDark 
                ? 'border-slate-700/50 bg-slate-950/70' 
                : 'border-slate-200 bg-white'
            }`}>
              
              {/* CHAT PANE HEADER */}
              <div className={`px-4 py-3.5 border-b flex items-center justify-between ${
                isDark 
                  ? 'bg-slate-900/90 border-slate-800/80' 
                  : 'bg-slate-50 border-slate-200/60'
              }`}>
                <div className="flex items-center gap-2">
                  <span className="relative flex h-2.5 w-2.5">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500"></span>
                  </span>
                  <span className={`text-xs font-sans font-black uppercase tracking-wider ${
                    isDark ? 'text-slate-200' : 'text-slate-700'
                  }`}>
                    AdaptSaku Chat
                  </span>
                </div>
                
                <button
                  type="button"
                  onClick={handleClearChat}
                  className={`p-2 rounded-xl transition-all duration-300 ${
                    isDark 
                      ? 'bg-slate-950 hover:bg-slate-800 text-slate-400 hover:text-teal-400 border border-slate-800 hover:border-teal-500/30' 
                      : 'bg-white hover:bg-slate-100 text-slate-500 hover:text-indigo-650 border border-slate-200 hover:border-indigo-500/30'
                  }`}
                  title="Mulai ulang percakapan"
                  aria-label="Mulai ulang percakapan"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                </button>
              </div>

              {/* MESSAGES THREAD FEED */}
              <div className={`flex-1 overflow-y-auto p-5 space-y-4 scroll-smooth ${
                isDark ? 'bg-transparent' : 'bg-slate-50/40'
              }`}>
                {chatMessages.map((msg, index) => (
                  <div
                    key={index}
                    className={`flex flex-col max-w-[85%] text-left ${
                      msg.role === 'user' ? 'ml-auto items-end' : 'mr-auto items-start'
                    }`}
                  >
                    <div
                      className={`p-3.5 rounded-2xl text-xs leading-relaxed font-sans shadow-md ${
                        msg.role === 'user'
                          ? 'bg-gradient-to-br from-emerald-600 to-teal-700 text-white rounded-tr-none'
                          : isDark
                            ? 'bg-slate-900 border border-slate-800/80 text-slate-300 rounded-tl-none'
                            : 'bg-white border border-slate-200 text-slate-800 rounded-tl-none'
                      }`}
                    >
                      {msg.role === 'user' ? (
                        <p className="font-medium whitespace-pre-wrap break-words">{msg.text}</p>
                      ) : (
                        <div className="space-y-1">
                          {parseMarkdown(msg.text)}
                        </div>
                      )}
                    </div>
                    <span className="text-[9px] text-slate-500 font-mono mt-1 px-1">
                      {msg.timestamp}
                    </span>
                  </div>
                ))}

                {/* TYPING LOADER */}
                {chatLoading && (
                  <div className="flex flex-col items-start max-w-[85%] mr-auto text-left">
                    <div className={`p-3.5 rounded-2xl rounded-tl-none flex items-center gap-2 border ${
                      isDark 
                        ? 'bg-slate-900 border-slate-800/80 text-slate-400' 
                        : 'bg-white border-slate-200 text-slate-500'
                    }`}>
                      <Loader2 className="w-4 h-4 text-emerald-400 animate-spin" />
                      <span className="text-xs font-medium">AdaptSaku AI sedang meninjau data Anda...</span>
                    </div>
                  </div>
                )}
                         {/* PROFILE FILTER SECTION */}
              <div className={`px-5 py-2.5 border-t text-left ${
                isDark 
                  ? 'border-slate-800/80 bg-slate-950/95' 
                  : 'border-slate-200 bg-slate-50'
              }`}>
                <p className="text-[9px] font-sans font-black text-slate-500 uppercase tracking-widest mb-2">
                  👤 Pilih Profil Keuangan Anda (Tips Spesifik):
                </p>
                <div className="flex flex-wrap gap-1.5">
                  <button
                    type="button"
                    onClick={() => setUserProfile('umum')}
                    className={`inline-flex items-center gap-1.5 text-[9px] font-sans font-black uppercase tracking-wider py-1.5 px-2.5 rounded-lg border transition duration-300 cursor-pointer ${
                      userProfile === 'umum'
                        ? (isDark ? 'bg-indigo-500/10 text-indigo-400 border-indigo-500/35' : 'bg-indigo-50 text-indigo-700 border-indigo-200')
                        : (isDark ? 'bg-slate-900 hover:bg-slate-850 text-slate-400 border-slate-800' : 'bg-white hover:bg-slate-100 text-slate-500 border-slate-200')
                    }`}
                  >
                    <User className="w-3 h-3 shrink-0" />
                    <span>Umum</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setUserProfile('karyawan')}
                    className={`inline-flex items-center gap-1.5 text-[9px] font-sans font-black uppercase tracking-wider py-1.5 px-2.5 rounded-lg border transition duration-300 cursor-pointer ${
                      userProfile === 'karyawan'
                        ? (isDark ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/35' : 'bg-emerald-50 text-emerald-700 border-emerald-200')
                        : (isDark ? 'bg-slate-900 hover:bg-slate-850 text-slate-400 border-slate-800' : 'bg-white hover:bg-slate-100 text-slate-500 border-slate-200')
                    }`}
                  >
                    <Briefcase className="w-3 h-3 shrink-0" />
                    <span>Karyawan</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setUserProfile('freelancer')}
                    className={`inline-flex items-center gap-1.5 text-[9px] font-sans font-black uppercase tracking-wider py-1.5 px-2.5 rounded-lg border transition duration-300 cursor-pointer ${
                      userProfile === 'freelancer'
                        ? (isDark ? 'bg-amber-500/10 text-amber-400 border-amber-500/35' : 'bg-amber-50 text-amber-700 border-amber-200')
                        : (isDark ? 'bg-slate-900 hover:bg-slate-850 text-slate-400 border-slate-800' : 'bg-white hover:bg-slate-100 text-slate-500 border-slate-200')
                    }`}
                  >
                    <Laptop className="w-3 h-3 shrink-0" />
                    <span>Freelancer</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setUserProfile('mahasiswa')}
                    className={`inline-flex items-center gap-1.5 text-[9px] font-sans font-black uppercase tracking-wider py-1.5 px-2.5 rounded-lg border transition duration-300 cursor-pointer ${
                      userProfile === 'mahasiswa'
                        ? (isDark ? 'bg-pink-500/10 text-pink-400 border-pink-500/35' : 'bg-pink-50 text-pink-700 border-pink-200')
                        : (isDark ? 'bg-slate-900 hover:bg-slate-850 text-slate-400 border-slate-800' : 'bg-white hover:bg-slate-100 text-slate-500 border-slate-200')
                    }`}
                  >
                    <GraduationCap className="w-3 h-3 shrink-0" />
                    <span>Mahasiswa</span>
                  </button>
                </div>
              </div>

              {/* PRESETS BUTTON HELPER PANEL */}
              <div className={`px-5 py-2.5 border-t text-left ${
                isDark 
                  ? 'border-slate-900/60 bg-slate-950/90' 
                  : 'border-slate-200/50 bg-slate-50'
              }`}>
                <p className="text-[9px] font-sans font-black text-slate-500 uppercase tracking-widest mb-2">⚡ Klik Template Pertanyaan Cepat:</p>
                <div className="flex flex-wrap gap-2">
                  {userProfile === 'umum' && (
                    <>
                      <button
                        type="button"
                        onClick={() => handleTemplateClick("Beri saya saran alokasi yang realistis didasari data masukan dan tujuan finansial saya.")}
                        className={`text-[10px] font-sans font-black py-1.5 px-3 rounded-xl transition duration-300 cursor-pointer text-left ${
                          isDark
                            ? 'bg-slate-900 hover:bg-slate-850 text-slate-300 hover:text-white border border-slate-800 hover:border-slate-700'
                            : 'bg-white hover:bg-slate-100 text-slate-600 hover:text-slate-800 border border-slate-250 hover:border-slate-350'
                        }`}
                        disabled={chatLoading}
                      >
                        Beri Saran Alokasi Terbaik
                      </button>
                      <button
                        type="button"
                        onClick={() => handleTemplateClick("Tolong sesuaikan pengeluaran saya menggunakan aturan budgeting 50/30/20.")}
                        className={`text-[10px] font-sans font-black py-1.5 px-3 rounded-xl transition duration-300 cursor-pointer text-left ${
                          isDark
                            ? 'bg-slate-900 hover:bg-slate-850 text-slate-300 hover:text-white border border-slate-800 hover:border-slate-700'
                            : 'bg-white hover:bg-slate-100 text-slate-600 hover:text-slate-800 border border-slate-250 hover:border-slate-350'
                        }`}
                        disabled={chatLoading}
                      >
                        Terapkan 50/30/20
                      </button>
                      <button
                        type="button"
                        onClick={() => handleTemplateClick("Bagaimana strategi terbaik untuk melunasi cicilan/utang saya lebih cepat?")}
                        className={`text-[10px] font-sans font-black py-1.5 px-3 rounded-xl transition duration-300 cursor-pointer text-left ${
                          isDark
                            ? 'bg-slate-900 hover:bg-slate-850 text-slate-300 hover:text-white border border-slate-800 hover:border-slate-700'
                            : 'bg-white hover:bg-slate-100 text-slate-600 hover:text-slate-800 border border-slate-250 hover:border-slate-350'
                        }`}
                        disabled={chatLoading}
                      >
                        Strategi Bebas Utang
                      </button>
                    </>
                  )}

                  {userProfile === 'karyawan' && (
                    <>
                      <button
                        type="button"
                        onClick={() => handleTemplateClick("Saya bekerja tetap dengan penghasilan bulanan stabil. Bagaimana tips mengelola pengeluaran bulanan agar tidak bocor alus?")}
                        className={`text-[10px] font-sans font-black py-1.5 px-3 rounded-xl transition duration-300 cursor-pointer text-left ${
                          isDark
                            ? 'bg-slate-900 hover:bg-slate-850 text-slate-300 hover:text-white border border-slate-800 hover:border-slate-700'
                            : 'bg-white hover:bg-slate-100 text-slate-600 hover:text-slate-800 border border-slate-250 hover:border-slate-350'
                        }`}
                        disabled={chatLoading}
                      >
                        Kelola Gaji Bulanan
                      </button>
                      <button
                        type="button"
                        onClick={() => handleTemplateClick("Bagaimana tips bagi karyawan untuk menyisihkan dana tabungan/investasi pasif secara berkala setiap kali gajian?")}
                        className={`text-[10px] font-sans font-black py-1.5 px-3 rounded-xl transition duration-300 cursor-pointer text-left ${
                          isDark
                            ? 'bg-slate-900 hover:bg-slate-850 text-slate-300 hover:text-white border border-slate-800 hover:border-slate-700'
                            : 'bg-white hover:bg-slate-100 text-slate-600 hover:text-slate-800 border border-slate-250 hover:border-slate-350'
                        }`}
                        disabled={chatLoading}
                      >
                        Investasi Setelah Gajian
                      </button>
                      <button
                        type="button"
                        onClick={() => handleTemplateClick("Saya seorang fresh graduate / pekerja baru di kantor. Berikan saran porsi budget yang pas untuk dana darurat pertama saya.")}
                        className={`text-[10px] font-sans font-black py-1.5 px-3 rounded-xl transition duration-300 cursor-pointer text-left ${
                          isDark
                            ? 'bg-slate-900 hover:bg-slate-850 text-slate-300 hover:text-white border border-slate-800 hover:border-slate-700'
                            : 'bg-white hover:bg-slate-100 text-slate-600 hover:text-slate-800 border border-slate-250 hover:border-slate-350'
                        }`}
                        disabled={chatLoading}
                      >
                        Saran Dana Darurat Pertama
                      </button>
                    </>
                  )}

                  {userProfile === 'freelancer' && (
                    <>
                      <button
                        type="button"
                        onClick={() => handleTemplateClick("Sebagai pekerja lepas dengan pendapatan fluktuatif/tidak menentu, bagaimana trik budgeting yang aman agar tetap stabil?")}
                        className={`text-[10px] font-sans font-black py-1.5 px-3 rounded-xl transition duration-300 cursor-pointer text-left ${
                          isDark
                            ? 'bg-slate-900 hover:bg-slate-850 text-slate-300 hover:text-white border border-slate-800 hover:border-slate-700'
                            : 'bg-white hover:bg-slate-100 text-slate-600 hover:text-slate-805 border border-slate-250 hover:border-slate-350'
                        }`}
                        disabled={chatLoading}
                      >
                        Budgeting Penghasilan Fluktuatif
                      </button>
                      <button
                        type="button"
                        onClick={() => handleTemplateClick("Bagaimana tips disiplin memisahkan antara rekening kas proyek kerjaan dengan uang pribadi agar kas operasional terjaga?")}
                        className={`text-[10px] font-sans font-black py-1.5 px-3 rounded-xl transition duration-300 cursor-pointer text-left ${
                          isDark
                            ? 'bg-slate-900 hover:bg-slate-850 text-slate-300 hover:text-white border border-slate-800 hover:border-slate-705'
                            : 'bg-white hover:bg-slate-100 text-slate-600 hover:text-slate-800 border border-slate-250 hover:border-slate-355'
                        }`}
                        disabled={chatLoading}
                      >
                        Pisahkan Kas Bisnis vs Pribadi
                      </button>
                      <button
                        type="button"
                        onClick={() => handleTemplateClick("Berapa porsi tabungan aman untuk dana darurat pekerja freelance saat bulan sepi proyek?")}
                        className={`text-[10px] font-sans font-black py-1.5 px-3 rounded-xl transition duration-300 cursor-pointer text-left ${
                          isDark
                            ? 'bg-slate-900 hover:bg-slate-850 text-slate-300 hover:text-white border border-slate-800 hover:border-slate-705'
                            : 'bg-white hover:bg-slate-100 text-slate-600 hover:text-slate-800 border border-slate-250 hover:border-slate-355'
                        }`}
                        disabled={chatLoading}
                      >
                        Dana Cadangan Freelancer
                      </button>
                    </>
                  )}

                  {userProfile === 'mahasiswa' && (
                    <>
                      <button
                        type="button"
                        onClick={() => handleTemplateClick("Uang saku bulanan dari orang tua/beasiswa terbatas. Berikan tips jitu membuat skala prioritas antara buku kuliah vs nongkrong sosial.")}
                        className={`text-[10px] font-sans font-black py-1.5 px-3 rounded-xl transition duration-300 cursor-pointer text-left ${
                          isDark
                            ? 'bg-slate-900 hover:bg-slate-850 text-slate-300 hover:text-white border border-slate-800 hover:border-slate-705'
                            : 'bg-white hover:bg-slate-100 text-slate-600 hover:text-slate-800 border border-slate-250 hover:border-slate-355'
                        }`}
                        disabled={chatLoading}
                      >
                        Membagi Kiriman Bulanan
                      </button>
                      <button
                        type="button"
                        onClick={() => handleTemplateClick("Bagaimana rumus berhemat harian yang efektif untuk biaya makan murah sehat, kos-kosan, dan fotokopi tugas kuliah?")}
                        className={`text-[10px] font-sans font-black py-1.5 px-3 rounded-xl transition duration-300 cursor-pointer text-left ${
                          isDark
                            ? 'bg-slate-900 hover:bg-slate-850 text-slate-300 hover:text-white border border-slate-800 hover:border-slate-705'
                            : 'bg-white hover:bg-slate-100 text-slate-600 hover:text-slate-800 border border-slate-250 hover:border-slate-355'
                        }`}
                        disabled={chatLoading}
                      >
                        Model Budget Anak Kos
                      </button>
                      <button
                        type="button"
                        onClick={() => handleTemplateClick("Sebagai pelajar dengan keterbatasan kas bulanan, bagaimana strategi realistis untuk mulai menabung sekecil apapun?")}
                        className={`text-[10px] font-sans font-black py-1.5 px-3 rounded-xl transition duration-300 cursor-pointer text-left ${
                          isDark
                            ? 'bg-slate-900 hover:bg-slate-850 text-slate-300 hover:text-white border border-slate-800 hover:border-slate-705'
                            : 'bg-white hover:bg-slate-100 text-slate-600 hover:text-slate-805 border border-slate-250 hover:border-slate-355'
                        }`}
                        disabled={chatLoading}
                      >
                        Trik Menabung Nominal Kecil
                      </button>
                    </>
                  )}

                  {/* Shared global templates to ensure seamless navigation */}
                  <button
                    type="button"
                    onClick={() => handleTemplateClick("Bulan ini berapa total pengeluaran keinginan saya dan bagaimana alternatif menyiasatinya agar tetap terkontrol?")}
                    className={`text-[10px] font-sans font-black py-1.5 px-3 rounded-xl transition duration-300 cursor-pointer text-left ${
                      isDark
                        ? 'bg-slate-900 hover:bg-slate-850 text-slate-300 hover:text-white border border-slate-800 hover:border-slate-705'
                        : 'bg-white hover:bg-slate-100 text-slate-600 hover:text-slate-800 border border-slate-250 hover:border-slate-355'
                    }`}
                    disabled={chatLoading}
                  >
                    Tips Hemat Belanja Keinginan
                  </button>
                  <button
                    type="button"
                    onClick={() => handleTemplateClick("Bagaimana strategi mengamankan target dana darurat atau impian finansial terbesar saya saat simulasi diaktifkan?")}
                    className={`text-[10px] font-sans font-black py-1.5 px-3 rounded-xl transition duration-300 cursor-pointer text-left ${
                      isDark
                        ? 'bg-slate-900 hover:bg-slate-850 text-slate-300 hover:text-white border border-slate-800 hover:border-slate-705'
                        : 'bg-white hover:bg-slate-100 text-slate-600 hover:text-slate-800 border border-slate-250 hover:border-slate-355'
                    }`}
                    disabled={chatLoading}
                  >
                    Atur Strategi Target Jangka Panjang
                  </button>
                </div>
              </div>        </div>

              {/* STICKY CHAT INPUT PANEL */}
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  handleSendChatMessage();
                }}
                className={`p-3 border-t flex gap-2 items-end ${
                  isDark 
                    ? 'bg-slate-900 border-slate-800/80' 
                    : 'bg-slate-50 border-slate-200/60'
                }`}
              >
                <textarea
                  id="sim-chat-input"
                  value={chatInput}
                  onChange={(e) => setChatInput(e.target.value)}
                  onKeyDown={handleKeyDown}
                  rows={2}
                  placeholder={`Tanyakan AdaptSaku ${formatPeriodLabel(selectedPeriod)} Anda di sini... (Shift + Enter untuk baris baru, Enter untuk kirim)`}
                  className={`flex-1 rounded-xl px-4 py-2.5 text-xs focus:outline-none focus:border-emerald-555 transition resize-none ${
                    isDark 
                      ? 'bg-slate-950 border border-slate-800 text-white placeholder-slate-500' 
                      : 'bg-white border border-slate-250 text-slate-800 placeholder-slate-400 shadow-inner'
                  }`}
                  disabled={chatLoading}
                />
                
                <button
                  type="submit"
                  disabled={chatLoading || !chatInput.trim()}
                  className={`px-5 py-3 h-[42px] rounded-xl text-xs font-black uppercase tracking-wider flex items-center justify-center gap-1.5 transition ${
                    chatLoading || !chatInput.trim()
                      ? isDark 
                        ? 'bg-slate-850 text-slate-500 border border-slate-800/80 cursor-not-allowed'
                        : 'bg-slate-200 text-slate-400 border border-slate-300/60 cursor-not-allowed'
                      : 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-md shadow-emerald-900/15 cursor-pointer hover:scale-[1.02]'
                  }`}
                >
                  <Send className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">Kirim</span>
                </button>
              </form>

            </div>
          </div>
        )}
      </div>

      {/* SECTION 2: WHAT-IF ADAPTABILITY LIVE SIMULATOR */}
      <div className="bg-slate-800/50 backdrop-blur-md border border-slate-705 rounded-[2rem] shadow-xl p-6 md:p-8 space-y-6">
        <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center gap-4 pb-3 border-b border-slate-700/60">
          <div className="space-y-1 flex-1">
            <h3 className="text-base font-sans font-black text-white uppercase tracking-wider">
              Simulator Adaptasi Skenario AdaptSaku
            </h3>
            <p className="text-xs text-slate-400">
              Gerakkan parameter di bawah untuk memprediksi ketahanan AdaptSaku Anda jika pemasukan naik-turun atau biaya dihemat.
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={() => {
                setIncomeFactor(0);
                setWantsCut(100);
                setNeedsCut(30);
              }}
              className={`text-[10px] font-sans font-black py-2 px-3 rounded-xl transition duration-300 cursor-pointer flex items-center gap-1.5 border ${
                isDark ? 'bg-rose-500/10 text-rose-400 hover:bg-rose-500/20 border-rose-500/30' : 'bg-rose-50 text-rose-600 hover:bg-rose-100 border-rose-200 shadow-sm hover:border-rose-300'
              }`}
              title="Cek ketahanan dana darurat Anda saat tak ada pemasukan sama sekali"
            >
              <AlertCircle className="w-3.5 h-3.5" />
              Skenario Krisis
            </button>
            <button
              onClick={handleResetSimulator}
              className="p-2 text-slate-400 hover:text-white bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-xl transition-colors cursor-pointer"
              title="Saturasikan Setelan Awal"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
          </div>
        </div>

        {incomeFactor === 0 && (
          <div className={`p-3 border rounded-xl text-[10px] leading-relaxed font-medium ${
            isDark ? 'bg-rose-500/10 border-rose-500/20 text-rose-300' : 'bg-rose-50 border-rose-200 text-rose-700'
          }`}>
            <strong>⚠️ Info Skenario Krisis:</strong> Skenario ini mensimulasikan hidup selama sebulan (atau periode tertentu) murni tanpa penghasilan sama sekali, menghapus seluruh pengeluaran keinginan, dan menekan biaya kebutuhan. Gunakan mode ini untuk memahami ketahanan kas cadangan dan mengukur seberapa pentingnya mendanai milestone Dana Darurat Anda.
          </div>
        )}

        {totalIncomeOriginal === 0 ? (
          <div className="text-center py-8 text-xs text-slate-500 border border-dashed border-slate-800 rounded-2xl">
            Harap isi pendapatan di tab Pendapatan guna memicu visualisasi simulasi "What-If" di sini.
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Sliders panel */}
            <div className="lg:col-span-12 xl:col-span-5 space-y-6">
              {/* Income factor slider */}
              <div className={`p-4 rounded-2xl border space-y-3 hover:border-teal-500/35 transition-all duration-300 ${
                isDark ? 'bg-slate-900/40 border-slate-800 text-white' : 'bg-white border-slate-200 text-slate-800 shadow-sm'
              }`}>
                <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center gap-1.5 text-xs">
                  <span className={`text-[10px] font-sans font-black uppercase tracking-wider ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>Fluktuasi Pendapatan ({incomeFactor}%)</span>
                  <span className={`font-mono font-black text-sm leading-none shrink-0 ${incomeFactor < 100 ? 'text-rose-455' : incomeFactor > 100 ? 'text-emerald-500' : 'text-slate-400'}`}>
                    {formatRupiah(simIncome)}
                  </span>
                </div>
                <input
                  type="range"
                  min="50"
                  max="150"
                  step="5"
                  value={incomeFactor}
                  onChange={(e) => setIncomeFactor(Number(e.target.value))}
                  className={`w-full h-1.5 rounded-lg appearance-none cursor-pointer accent-teal-500 focus:outline-none ${
                    isDark ? 'bg-slate-700' : 'bg-slate-200'
                  }`}
                />
                <div className={`flex justify-between text-[8px] sm:text-[9px] font-mono font-bold leading-normal ${isDark ? 'text-slate-500' : 'text-slate-400'}`}>
                  <span>-50% (Skenario Terburuk)</span>
                  <span>Normal</span>
                  <span>+50% (Kenaikan)</span>
                </div>
              </div>

              {/* Wants deduction slider */}
              <div className={`p-4 rounded-2xl border space-y-3 hover:border-pink-500/35 transition-all duration-300 ${
                isDark ? 'bg-slate-900/40 border-slate-800 text-white' : 'bg-white border-slate-200 text-slate-800 shadow-sm'
              }`}>
                <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center gap-1.5 text-xs">
                  <span className={`text-[10px] font-sans font-black uppercase tracking-wider ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>Penghematan Keinginan ({wantsCut}%)</span>
                  <span className="text-pink-500 font-mono font-black text-sm leading-none shrink-0">
                    Sisa: {formatRupiah(simKeinginan)}
                  </span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="100"
                  step="5"
                  value={wantsCut}
                  onChange={(e) => setWantsCut(Number(e.target.value))}
                  className={`w-full h-1.5 rounded-lg appearance-none cursor-pointer accent-pink-500 focus:outline-none ${
                    isDark ? 'bg-slate-700' : 'bg-slate-200'
                  }`}
                />
                <div className={`flex justify-between text-[8px] sm:text-[9px] font-mono font-bold leading-normal ${isDark ? 'text-slate-500' : 'text-slate-400'}`}>
                  <span>Konsumsi Penuh</span>
                  <span>Setengah Hemat</span>
                  <span>Frugal total (100%)</span>
                </div>
              </div>

              {/* Needs deduction slider */}
              <div className={`p-4 rounded-2xl border space-y-3 hover:border-amber-500/35 transition-all duration-300 ${
                isDark ? 'bg-slate-900/40 border-slate-800 text-white' : 'bg-white border-slate-200 text-slate-800 shadow-sm'
              }`}>
                <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center gap-1.5 text-xs">
                  <span className={`text-[10px] font-sans font-black uppercase tracking-wider ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>Penghematan Kebutuhan ({needsCut}%)</span>
                  <span className="text-amber-500 font-mono font-black text-sm leading-none shrink-0">
                    Sisa: {formatRupiah(simKebutuhan)}
                  </span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="50"
                  step="5"
                  value={needsCut}
                  onChange={(e) => setNeedsCut(Number(e.target.value))}
                  className={`w-full h-1.5 rounded-lg appearance-none cursor-pointer accent-amber-500 focus:outline-none ${
                    isDark ? 'bg-slate-700' : 'bg-slate-200'
                  }`}
                />
                <div className={`flex justify-between text-[8px] sm:text-[9px] font-mono font-bold leading-normal ${isDark ? 'text-slate-500' : 'text-slate-400'}`}>
                  <span>Standard</span>
                  <span>Penghematan Ketat (Max 50%)</span>
                </div>
              </div>
            </div>

            {/* Simulated report panel */}
            <div id="simulated_report_card" className={`lg:col-span-12 xl:col-span-7 p-6 rounded-[2rem] border space-y-6 ${
              isDark ? 'bg-slate-950 border-slate-800 text-white' : 'bg-slate-50 border-slate-200 text-slate-800 shadow-sm'
            }`}>
              <h4 className={`text-xs font-black uppercase tracking-widest flex flex-wrap items-center justify-between gap-2 ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>
                <span>Dampak Arus Kas (Before vs After)</span>
                {(incomeFactor !== 100 || wantsCut !== 0 || needsCut !== 0) && (
                  <span className={`text-[9px] px-2.5 py-1 rounded-full border ${
                    isDark ? 'bg-indigo-500/20 text-indigo-300 border-indigo-500/30' : 'bg-indigo-100 text-indigo-700 border-indigo-200'
                  }`}>
                    Mode Simulasi Aktif
                  </span>
                )}
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className={`p-4 border rounded-2xl space-y-2 relative overflow-hidden group ${
                  isDark ? 'bg-slate-900/60 border-slate-800/80' : 'bg-white border-slate-200 shadow-sm'
                }`}>
                  <div className="absolute right-0 top-0 bottom-0 w-1 bg-emerald-500/30"></div>
                  <span className={`text-[10px] uppercase tracking-wider font-extrabold block ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>Pemasukan</span>
                  <div className="flex flex-col gap-1">
                    <p className={`text-base sm:text-lg font-mono font-black leading-none ${isDark ? 'text-white' : 'text-slate-850'}`}>{formatRupiah(simIncome)}</p>
                    {simIncome !== totalIncomeOriginal && (
                      <p className={`text-[10px] font-mono line-through leading-none mt-1 ${isDark ? 'text-slate-500' : 'text-slate-400'}`}>Asli: {formatRupiah(totalIncomeOriginal)}</p>
                    )}
                  </div>
                </div>
                <div className={`p-4 border rounded-2xl space-y-2 relative overflow-hidden ${
                  isDark ? 'bg-slate-900/60 border-slate-800/80' : 'bg-white border-slate-200 shadow-sm'
                }`}>
                  <div className="absolute right-0 top-0 bottom-0 w-1 bg-amber-500/30"></div>
                  <span className={`text-[10px] uppercase tracking-wider font-extrabold block ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>Gabungan Belanja</span>
                  <div className="flex flex-col gap-1">
                    <p className={`text-base sm:text-lg font-mono font-black leading-none ${isDark ? 'text-white' : 'text-slate-850'}`}>{formatRupiah(simTotalExpense)}</p>
                    {simTotalExpense !== totalExpenseOriginal && (
                      <p className={`text-[10px] font-mono line-through leading-none mt-1 ${isDark ? 'text-slate-500' : 'text-slate-400'}`}>Asli: {formatRupiah(totalExpenseOriginal)}</p>
                    )}
                  </div>
                </div>
                <div className={`p-4 border rounded-2xl sm:col-span-2 space-y-2 relative overflow-hidden ${
                  isDark ? 'bg-slate-900/60 border-slate-800/80' : 'bg-white border-slate-200 shadow-sm'
                }`}>
                  <div className={`absolute right-0 top-0 bottom-0 w-1 ${simNetSavings >= 0 ? 'bg-teal-500/40' : 'bg-rose-500/40'}`}></div>
                  <span className={`text-[10px] uppercase tracking-wider font-extrabold block ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>Sisa Kapasitas Menabung (Surplus/Defisit)</span>
                  <div className="flex flex-col md:flex-row md:items-end justify-between gap-3">
                    <p className={`text-xl sm:text-2xl font-mono font-black ${simNetSavings >= 0 ? (isDark ? 'text-emerald-400 drop-shadow-[0_0_12px_rgba(52,211,153,0.15)]' : 'text-emerald-600') : (isDark ? 'text-rose-455 drop-shadow-[0_0_12px_rgba(244,63,94,0.15)]' : 'text-rose-600')}`}>
                      {formatRupiah(simNetSavings)}
                    </p>
                    {(simIncome !== totalIncomeOriginal || simTotalExpense !== totalExpenseOriginal) && (
                      <div className={`flex items-center gap-2 px-2.5 py-1.5 rounded-lg border shrink-0 ${
                        isDark ? 'bg-slate-950 border-slate-800' : 'bg-slate-100 border-slate-200/80'
                      }`}>
                        <span className={`text-[9px] uppercase font-bold tracking-widest ${isDark ? 'text-slate-500' : 'text-slate-500'}`}>Asli:</span>
                        <span className={`text-[11px] font-mono font-black line-through ${isDark ? 'text-slate-400' : 'text-slate-650'}`}>
                          {formatRupiah(totalIncomeOriginal - totalExpenseOriginal)}
                        </span>
                      </div>
                    )}
                  </div>
                </div>
              </div>

              {/* Simulated goal projections list */}
              <div className={`space-y-3 pt-4 border-t ${isDark ? 'border-slate-800' : 'border-slate-200'}`}>
                <h5 className={`text-[10px] font-sans font-black uppercase tracking-wider ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>
                  Estimasi Penyelesaian Target Finansial (Real-Time Projections)
                </h5>
                <div className="space-y-2 max-h-[440px] overflow-y-auto pr-1">
                  {goals.length === 0 ? (
                    <div className={`text-center py-6 text-xs border border-dashed rounded-xl ${
                      isDark ? 'text-slate-500 border-slate-800' : 'text-slate-500 border-slate-300'
                    }`}>
                      Tidak ada target tujuan terdaftar untuk kalkulasi estimasi AdaptSaku.
                    </div>
                  ) : (
                    simulatedGoalsProjections.map(gProj => (
                      <div
                        key={gProj.id}
                        className={`p-3.5 border rounded-xl flex flex-col gap-2.5 transition-all duration-300 ${
                          isDark
                            ? 'bg-slate-900/40 hover:bg-slate-800/40 border-slate-800/80 hover:border-slate-700'
                            : 'bg-white hover:bg-slate-50 border-slate-200 hover:border-slate-300 shadow-sm'
                        }`}
                      >
                        {/* Baris 1: Prioritas & Status Proyeksi */}
                        <div className="flex justify-between items-center">
                          <div className={`px-2 py-0.5 rounded-lg flex items-center gap-1.5 border leading-none font-sans text-[9px] font-black uppercase tracking-wider ${
                            gProj.priority === 'high'
                              ? (isDark ? 'bg-rose-500/10 text-rose-450 border-rose-500/20' : 'bg-rose-50 text-rose-700 border-rose-200')
                              : gProj.priority === 'medium'
                              ? (isDark ? 'bg-amber-500/10 text-amber-450 border-amber-500/20' : 'bg-amber-50 text-amber-700 border-amber-200')
                              : (isDark ? 'bg-blue-500/10 text-blue-450 border-blue-500/20' : 'bg-blue-50 text-blue-700 border-blue-200')
                          }`}>
                            <span className="w-1 h-1 rounded-full bg-current"></span>
                            <span>{gProj.priority === 'high' ? 'Urgens' : gProj.priority === 'medium' ? 'Penting' : 'Minor'}</span>
                          </div>

                          <span className={`shrink-0 text-[10px] px-2.5 py-1 rounded font-black uppercase border ${
                            gProj.status === 'Tercapai'
                              ? (isDark ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20' : 'bg-emerald-50 text-emerald-700 border-emerald-200')
                              : gProj.status === 'Tepat Waktu'
                              ? (isDark ? 'bg-teal-500/10 text-teal-400 border-teal-500/20' : 'bg-teal-50 text-teal-700 border-teal-200')
                              : gProj.status === 'Terhambat'
                              ? (isDark ? 'bg-rose-500/10 text-rose-400 border-rose-500/20' : 'bg-rose-50 text-rose-700 border-rose-200')
                              : (isDark ? 'bg-amber-500/10 text-amber-400 border-amber-500/20' : 'bg-amber-50 text-amber-700 border-amber-200')
                          }`}>
                            {gProj.status}
                          </span>
                        </div>

                        {/* Baris 2: Nama Rencana, Progres Numerik & Narasi Solusi */}
                        <div className="space-y-1.5">
                          <p className={`text-sm font-extrabold leading-snug billing-title ${isDark ? 'text-white' : 'text-slate-900'}`}>
                            {gProj.name}
                          </p>

                          {/* Detail Progres Ringkas */}
                          <div className="flex flex-wrap items-center gap-1.5 text-[9px] font-mono leading-none">
                            <span className={`px-1.5 py-0.5 rounded flex items-center gap-1 ${
                              isDark ? 'bg-slate-800 text-slate-300' : 'bg-slate-100 text-slate-650 border border-slate-205'
                            }`}>
                              Progres: {formatRupiah(gProj.currentAmount)} / {formatRupiah(gProj.targetAmount)}
                            </span>
                            <span className={`px-1.5 py-0.5 rounded font-black ${
                              isDark ? 'bg-emerald-950/40 text-emerald-400' : 'bg-emerald-55 text-emerald-700 border border-emerald-200'
                            }`}>
                              {Math.min(100, Math.round((gProj.currentAmount / gProj.targetAmount) * 100))}%
                            </span>
                          </div>

                          {/* Narasi Catatan dari Mesin Adaptasi */}
                          <p className={`text-[10px] leading-relaxed p-2 rounded-lg border font-medium ${
                            isDark
                              ? 'bg-slate-900/60 border-slate-800/60 text-slate-300'
                              : 'bg-slate-50 border-slate-200/80 text-slate-600'
                          }`}>
                            {gProj.note}
                          </p>
                        </div>

                        {/* Baris 3: Tenggat Waktu & Alokasi Per Bulan */}
                        <div className={`flex justify-between items-center pt-2.5 border-t ${
                          isDark ? 'border-slate-800/60' : 'border-slate-200'
                        }`}>
                          <div className="flex items-center gap-1">
                            <Calendar className={`w-3.5 h-3.5 ${isDark ? 'text-indigo-400' : 'text-indigo-600'}`} />
                            <span className={`text-[9px] font-mono font-bold leading-none ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>
                              Tenggat: {gProj.targetDate}
                            </span>
                          </div>

                          <div className="text-right">
                            <span className="text-[8px] uppercase font-bold tracking-widest text-slate-500 font-sans block leading-none mb-0.5">
                              Alokasi Simulasi
                            </span>
                            <span className={`text-xs font-mono font-black ${
                              gProj.monthlyAllocation && gProj.monthlyAllocation > 0
                                ? (isDark ? 'text-teal-400' : 'text-emerald-600')
                                : (isDark ? 'text-slate-500' : 'text-slate-400')
                            }`}>
                              {gProj.monthlyAllocation && gProj.monthlyAllocation > 0 ? `+ ${formatRupiah(gProj.monthlyAllocation)}/bln` : 'Rp 0'}
                            </span>
                          </div>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
