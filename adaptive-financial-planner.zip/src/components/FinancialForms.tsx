import React, { useState, useEffect } from 'react';
import { jsPDF } from 'jspdf';
import { 
  Plus, 
  Trash2, 
  Briefcase, 
  TrendingUp, 
  Coins, 
  Calendar, 
  DollarSign,
  AlertCircle,
  HelpCircle,
  PiggyBank,
  Check,
  Pencil,
  Repeat,
  X,
  Printer,
  Search,
  Filter
} from 'lucide-react';
import { Income, Expense, Goal } from '../types';

const autocompleteRules = [
  // Kebutuhan - Transportasi / Bensin
  { keywords: ['gojek', 'grab', 'maxim', 'bensin', 'pertamax', 'pertalite', 'shell', 'krl', 'mrt', 'lrt', 'taksi', 'taxi', 'tol', 'parkir', 'ojek'], category: 'kebutuhan', subcategory: 'Transportasi / Bensin' },
  // Keinginan - Streaming & Hiburan (Film, Games)
  { keywords: ['spotify', 'netflix', 'youtube premium', 'youtube tv', 'disney', 'hbo', 'steam', 'playstation', 'nintendo', 'mlbb', 'diamond', 'crunchyroll', 'game', 'gaming'], category: 'keinginan', subcategory: 'Streaming & Hiburan (Film, Games)' },
  // Kebutuhan - Listrik, Gas & Air
  { keywords: ['listrik', 'pln', 'token', 'pdam', 'gas', 'lpg', 'air pdam'], category: 'kebutuhan', subcategory: 'Listrik, Gas & Air' },
  // Kebutuhan - Pulsa & Internet
  { keywords: ['pulsa', 'kuota', 'telkomsel', 'indosat', 'xl', 'biznet', 'indihome', 'myrepublic', 'smartfren', 'wifi', 'internet'], category: 'kebutuhan', subcategory: 'Pulsa & Internet' },
  // Keinginan - Makan Mewah/Kafe (Nongkrong)
  { keywords: ['starbucks', 'kafe', 'cafe', 'nongkrong', 'kopisop', 'boba', 'kopi', 'restoran', 'mewah'], category: 'keinginan', subcategory: 'Makan Mewah/Kafe (Nongkrong)' },
  // Kebutuhan - Makanan & Minuman
  { keywords: ['gofood', 'grabfood', 'shopeefood', 'makan', 'warteg', 'sembako', 'belanja bulanan', 'pasar', 'sayur', 'beras', 'bakso', 'mie ayam', 'indomaret', 'alfamart'], category: 'kebutuhan', subcategory: 'Makanan & Minuman' },
  // Kebutuhan - Sewa Tempat Tinggal / Kos
  { keywords: ['kos', 'kost', 'kontrakan', 'sewa kamar', 'apartemen', 'kpr'], category: 'kebutuhan', subcategory: 'Sewa Tempat Tinggal / Kos' },
  // Kebutuhan - Kesehatan / Obat
  { keywords: ['dokter', 'obat', 'rs', 'rumah sakit', 'klinik', 'bpjs', 'vitamin', 'asuransi'], category: 'kebutuhan', subcategory: 'Kesehatan / Obat' },
  // Kebutuhan - Cicilan Wajib/Hutang
  { keywords: ['cicilan', 'hutang', 'utang', 'pinjol', 'paylater', 'kartu kredit'], category: 'kebutuhan', subcategory: 'Cicilan Wajib/Hutang' },
  // Kebutuhan - Pendidikan
  { keywords: ['spp', 'sekolah', 'kuliah', 'bimbel', 'les', 'buku', 'kursus', 'fotokopi'], category: 'kebutuhan', subcategory: 'Pendidikan' },
  // Keinginan - Belanja Mode / Skincare
  { keywords: ['baju', 'celana', 'sepatu', 'skincare', 'makeup', 'fashion', 'zara', 'h&m', 'tokopedia', 'shopee', 'pakaian', 'tas'], category: 'keinginan', subcategory: 'Belanja Mode / Skincare' },
  // Keinginan - Liburan / Traveling
  { keywords: ['liburan', 'travel', 'traveling', 'hotel', 'tiket pesawat', 'pantai', 'gili'], category: 'keinginan', subcategory: 'Liburan / Traveling' },
  // Keinginan - Hobi & Koleksi
  { keywords: ['hobi', 'koleksi', 'lego', 'gundam', 'kamera', 'sepeda'], category: 'keinginan', subcategory: 'Hobi & Koleksi' },
  // Keinginan - Keanggotaan Gimnasium
  { keywords: ['gym', 'fitness', 'gimnasium'], category: 'keinginan', subcategory: 'Keanggotaan Gimnasium' },
  // Tabungan - Dana Darurat
  { keywords: ['darurat', 'dana darurat', 'emergency'], category: 'tabungan', subcategory: 'Dana Darurat' },
  // Tabungan - Investasi Saham / Reksadana
  { keywords: ['saham', 'reksadana', 'bibit', 'ajaib', 'bareksa'], category: 'tabungan', subcategory: 'Investasi Saham / Reksadana' },
  // Tabungan - Tabungan Emas / SBN
  { keywords: ['emas', 'sbn', 'ori', 'tabungan emas'], category: 'tabungan', subcategory: 'Tabungan Emas / SBN' },
  // Tabungan - Investasi Crypto
  { keywords: ['crypto', 'kripto', 'bitcoin', 'btc', 'eth', 'binance', 'indodax', 'pintu'], category: 'tabungan', subcategory: 'Investasi Crypto' },
  // Tabungan - Kas Berjangka / Deposito
  { keywords: ['deposito', 'kas berjangka'], category: 'tabungan', subcategory: 'Kas Berjangka / Deposito' },
  // Tabungan - Persiapan Menikah / Rumah
  { keywords: ['nikah', 'rumah', 'kawin', 'dp rumah'], category: 'tabungan', subcategory: 'Persiapan Menikah / Rumah' },
];

interface FinancialFormsProps {
  incomes: Income[];
  expenses: Expense[];
  goals: Goal[];
  onAddIncome: (income: Omit<Income, 'id'>) => void;
  onDeleteIncome: (id: string) => void;
  onUpdateIncome?: (income: Income) => void;
  onAddExpense: (expense: Omit<Expense, 'id'>) => void;
  onDeleteExpense: (id: string) => void;
  onUpdateExpense?: (expense: Expense) => void;
  onAddGoal: (goal: Omit<Goal, 'id'>) => void;
  onDeleteGoal: (id: string) => void;
  onUpdateGoal?: (goal: Goal) => void;
  activePeriod: string;
  isDark?: boolean;
}

export function FinancialForms({
  incomes,
  expenses,
  goals,
  onAddIncome,
  onDeleteIncome,
  onUpdateIncome,
  onAddExpense,
  onDeleteExpense,
  onUpdateExpense,
  onAddGoal,
  onDeleteGoal,
  onUpdateGoal,
  activePeriod,
  isDark = true
}: FinancialFormsProps) {
  // Tabs for input sections
  const [activeTab, setActiveTab] = useState<'income' | 'expense' | 'goal'>('expense');

  const getDefaultDateForPeriod = (period: string) => {
    const todayStr = new Date().toISOString().split('T')[0];
    if (todayStr.startsWith(period)) {
      return todayStr;
    }
    return `${period}-01`;
  };

  const getDefaultDateTimeForPeriod = (period: string) => {
    const now = new Date();
    const tzOffset = now.getTimezoneOffset() * 60000;
    const localNow = new Date(now.getTime() - tzOffset);
    const localDateTimeStr = localNow.toISOString().slice(0, 16);

    if (localDateTimeStr.startsWith(period)) {
      return localDateTimeStr;
    }
    return `${period}-01T12:00`;
  };

  // Editing state IDs
  const [editingExpenseId, setEditingExpenseId] = useState<string | null>(null);
  const [editingIncomeId, setEditingIncomeId] = useState<string | null>(null);
  const [editingGoalId, setEditingGoalId] = useState<string | null>(null);

  // Expense Form State
  const [expTitle, setExpTitle] = useState('');
  const [expAmount, setExpAmount] = useState('');
  const [expCategory, setExpCategory] = useState<'kebutuhan' | 'keinginan' | 'tabungan'>('kebutuhan');
  const [expSubcategory, setExpSubcategory] = useState('Makanan & Minuman');
  const [expDate, setExpDate] = useState(() => getDefaultDateTimeForPeriod(activePeriod));
  const [expRecurring, setExpRecurring] = useState(false);
  const [isAutoDetected, setIsAutoDetected] = useState(false);

  const handleTitleChange = (val: string) => {
    setExpTitle(val);
    
    if (!val.trim()) {
      setIsAutoDetected(false);
      return;
    }

    const lowerVal = val.toLowerCase();
    let found = false;
    
    for (const rule of autocompleteRules) {
      const matched = rule.keywords.some(kw => lowerVal.includes(kw));
      
      if (matched) {
        setExpCategory(rule.category as any);
        setExpSubcategory(rule.subcategory);
        setIsAutoDetected(true);
        found = true;
        break;
      }
    }
    
    if (!found) {
      setIsAutoDetected(false);
    }
  };

  // Income Form State
  const [incSource, setIncSource] = useState('');
  const [incAmount, setIncAmount] = useState('');
  const [incCategory, setIncCategory] = useState<'primary' | 'side-hustle' | 'investment' | 'other'>('primary');
  const [incPeriod, setIncPeriod] = useState<'monthly' | 'one-time'>('monthly');
  const [incDate, setIncDate] = useState(() => getDefaultDateTimeForPeriod(activePeriod));
  const [incRecurring, setIncRecurring] = useState(false);

  // Receipt Scanner State
  const [isScanning, setIsScanning] = useState(false);
  const [scanNotes, setScanNotes] = useState('');
  const [isAIScannerVisible, setIsAIScannerVisible] = useState(false);
  const receiptInputRef = React.useRef<HTMLInputElement>(null);

  // Sync date fields with period selection changes
  useEffect(() => {
    setExpDate(getDefaultDateTimeForPeriod(activePeriod));
    setIncDate(getDefaultDateTimeForPeriod(activePeriod));
  }, [activePeriod]);

  // Goal Form State
  const [goalName, setGoalName] = useState('');
  const [goalTarget, setGoalTarget] = useState('');
  const [goalCurrent, setGoalCurrent] = useState('0');
  const [goalDate, setGoalDate] = useState('');
  const [goalPriority, setGoalPriority] = useState<'high' | 'medium' | 'low'>('medium');
  const [goalCategory, setGoalCategory] = useState<'general' | 'emergency_fund'>('general');

  // Subcategory presets for targeted goals
  const handleApplyEmergencyPreset = () => {
    setGoalName('Dana Darurat (Ideal: 3-6x Pengeluaran Bulanan)');
    setGoalCategory('emergency_fund');
    setGoalPriority('high');
    triggerGoalAmountFocus();
  };

  const triggerGoalAmountFocus = () => {
    const el = document.getElementById('goalTargetInput');
    if (el) el.focus();
  };

  // Subcategory suggestions based on main category
  const subcategoryPresets: Record<string, string[]> = {
    kebutuhan: ['Makanan & Minuman', 'Sewa Tempat Tinggal / Kos', 'Listrik, Gas & Air', 'Transportasi / Bensin', 'Kesehatan / Obat', 'Cicilan Wajib/Hutang', 'Pendidikan', 'Pulsa & Internet'],
    keinginan: ['Belanja Mode / Skincare', 'Makan Mewah/Kafe (Nongkrong)', 'Streaming & Hiburan (Film, Games)', 'Liburan / Traveling', 'Hobi & Koleksi', 'Keanggotaan Gimnasium'],
    tabungan: ['Dana Darurat', 'Investasi Saham / Reksadana', 'Tabungan Emas / SBN', 'Investasi Crypto', 'Kas Berjangka / Deposito', 'Persiapan Menikah / Rumah'],
    program_kerja: ['Proker A', 'Proker B', 'Event', 'Seminar', 'Lomba', 'Lainnya'],
    modal_usaha: ['Bahan Baku', 'Alat', 'Promosi / Ads', 'Sewa', 'Lainnya'],
    operasional_org: ['Rapat', 'Kesekretariatan', 'Inventaris', 'Transportasi', 'Konsumsi', 'Lainnya'],
    lain_lain: ['Biaya Tak Terduga', 'Donasi', 'Lainnya']
  };

  const ensureDateTimeLocalString = (dateStr: string) => {
    if (!dateStr) return '';
    if (dateStr.includes('T')) return dateStr.slice(0, 16);
    return `${dateStr}T12:00`;
  };

  const handleStartEditExpense = (exp: Expense) => {
    setEditingExpenseId(exp.id);
    setExpTitle(exp.title);
    setExpAmount(exp.amount.toString());
    setExpCategory(exp.category);
    setExpSubcategory(exp.subcategory);
    setExpDate(ensureDateTimeLocalString(exp.date));
    setExpRecurring(exp.isRecurring || false);
    // Smooth scroll to container or form top
    const elem = document.getElementById('expense_panel');
    if (elem) elem.scrollIntoView({ behavior: 'smooth', block: 'start' });
  };

  const handleStartEditIncome = (inc: Income) => {
    setEditingIncomeId(inc.id);
    setIncSource(inc.source);
    setIncAmount(inc.amount.toString());
    setIncCategory(inc.category);
    setIncPeriod(inc.period);
    setIncDate(ensureDateTimeLocalString(inc.date));
    setIncRecurring(inc.isRecurring || false);
    const elem = document.getElementById('income_panel');
    if (elem) elem.scrollIntoView({ behavior: 'smooth', block: 'start' });
  };

  const handleStartEditGoal = (goal: Goal) => {
    setEditingGoalId(goal.id);
    setGoalName(goal.name);
    setGoalTarget(goal.targetAmount.toString());
    setGoalCurrent(goal.currentAmount.toString());
    setGoalDate(goal.targetDate);
    setGoalPriority(goal.priority);
    setGoalCategory(goal.category || 'general');
    const elem = document.getElementById('goal_panel');
    if (elem) elem.scrollIntoView({ behavior: 'smooth', block: 'start' });
  };

  const handleIncomeSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!incSource || !incAmount || Number(incAmount) <= 0) return;
    
    if (editingIncomeId && onUpdateIncome) {
      onUpdateIncome({
        id: editingIncomeId,
        source: incSource,
        amount: Math.round(Number(incAmount)),
        category: incCategory,
        period: incPeriod,
        date: incDate,
        isRecurring: incRecurring
      });
      setEditingIncomeId(null);
    } else {
      onAddIncome({
        source: incSource,
        amount: Math.round(Number(incAmount)),
        category: incCategory,
        period: incPeriod,
        date: incDate,
        isRecurring: incRecurring
      });
    }
    setIncSource('');
    setIncAmount('');
    setIncRecurring(false);
  };

  const handleReceiptUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      alert("Harap unggah file gambar yang valid.");
      return;
    }

    setIsScanning(true);

    try {
      const reader = new FileReader();
      reader.onloadend = async () => {
        const base64String = (reader.result as string).split(',')[1];
        
        try {
          const res = await fetch('/api/analyze-receipt', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              imageBase64: base64String,
              mimeType: file.type,
              notes: scanNotes
            })
          });

          if (!res.ok) {
            const data = await res.json();
            throw new Error(data.error || 'Server error');
          }

          const parsedData = await res.json();
          
          if (parsedData.expectedType === 'income') {
            setActiveTab('income');
            setIncSource(parsedData.title || "");
            setIncAmount(parsedData.amount ? String(parsedData.amount) : "");
            setIncCategory(parsedData.category || "primary");
            if (parsedData.date) {
              setIncDate(ensureDateTimeLocalString(parsedData.date));
            }
          } else {
            setActiveTab('expense');
            setExpTitle(parsedData.title || "");
            setExpAmount(parsedData.amount ? String(parsedData.amount) : "");
            setExpCategory(parsedData.category || "kebutuhan");
            setExpSubcategory(parsedData.subcategory && parsedData.subcategory !== 'Lainnya' ? parsedData.subcategory : (subcategoryPresets[parsedData.category as any]?.[0] || 'Lainnya'));
            if (parsedData.date) {
              setExpDate(ensureDateTimeLocalString(parsedData.date));
            }
            setIsAutoDetected(true);
          }

          setScanNotes('');
        } catch (err: any) {
          alert('Gagal memindai bukti transaksi: ' + err.message);
        } finally {
          setIsScanning(false);
          if (receiptInputRef.current) receiptInputRef.current.value = '';
        }
      };
      
      reader.onerror = () => {
        setIsScanning(false);
        alert("Gagal membaca file gambar.");
      };

      reader.readAsDataURL(file);
    } catch {
      setIsScanning(false);
    }
  };

  const handleExpenseSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!expTitle || !expAmount || Number(expAmount) <= 0) return;
    
    if (editingExpenseId && onUpdateExpense) {
      onUpdateExpense({
        id: editingExpenseId,
        title: expTitle,
        amount: Math.round(Number(expAmount)),
        category: expCategory,
        subcategory: expSubcategory,
        date: expDate,
        isRecurring: expRecurring
      });
      setEditingExpenseId(null);
    } else {
      onAddExpense({
        title: expTitle,
        amount: Math.round(Number(expAmount)),
        category: expCategory,
        subcategory: expSubcategory,
        date: expDate,
        isRecurring: expRecurring
      });
    }
    setExpTitle('');
    setExpAmount('');
    setExpRecurring(false);
    setIsAutoDetected(false);
  };

  const handleGoalSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!goalName || !goalTarget || Number(goalTarget) <= 0) return;
    
    if (editingGoalId && onUpdateGoal) {
      onUpdateGoal({
        id: editingGoalId,
        name: goalName,
        targetAmount: Math.round(Number(goalTarget)),
        currentAmount: Math.round(Number(goalCurrent || '0')),
        targetDate: goalDate || new Date(Date.now() + 365 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
        priority: goalPriority,
        category: goalCategory
      });
      setEditingGoalId(null);
    } else {
      onAddGoal({
        name: goalName,
        targetAmount: Math.round(Number(goalTarget)),
        currentAmount: Math.round(Number(goalCurrent || '0')),
        targetDate: goalDate || new Date(Date.now() + 365 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
        priority: goalPriority,
        category: goalCategory
      });
    }
    setGoalName('');
    setGoalTarget('');
    setGoalCurrent('0');
    setGoalDate('');
    setGoalCategory('general');
  };

  // Helper formatting rupiah
  const formatRupiah = (val: number) => {
    return new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(val);
  };

  // Local states for filtering Daftar Transaksi Aktif
  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<'semua' | 'kebutuhan' | 'keinginan' | 'tabungan'>('semua');

  // Filtered displayed expenses calculation
  const displayedExpenses = expenses.filter((exp) => {
    const matchesSearch = 
      (exp.title || '').toLowerCase().includes(searchTerm.toLowerCase()) || 
      (exp.subcategory || '').toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesCategory = categoryFilter === 'semua' || exp.category === categoryFilter;

    return matchesSearch && matchesCategory;
  });

  // Export filtered list to PDF (using jsPDF)
  const handleExportListPDF = () => {
    const doc = new jsPDF({
      orientation: 'portrait',
      unit: 'mm',
      format: 'a4'
    });

    const primaryColor = [15, 23, 42]; // slate-900 / dark graphite
    const accentColor = [219, 39, 119]; // pink-600

    let y = 15;

    // Title Block
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(16);
    doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
    doc.text('DAFTAR TRANSAKSI AKTIF (AdaptSaku)', 15, y);
    y += 7;

    // Subtitle / Period
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(10);
    doc.setTextColor(100, 116, 139); // slate-500
    
    const formattedPeriod = activePeriod ? activePeriod.toUpperCase() : 'SEMUA PERIODE';
    doc.text(`Periode Aktif: ${formattedPeriod}`, 15, y);
    
    // Date of export
    const today = new Date().toLocaleDateString('id-ID', {
      day: 'numeric',
      month: 'long',
      year: 'numeric'
    });
    doc.text(`Dicetak Pada: ${today}`, 195, y, { align: 'right' });
    y += 10;

    // Filters used info box
    doc.setFillColor(248, 250, 252); // slate-50 background
    doc.setDrawColor(226, 232, 240); // slate-200 border
    doc.roundedRect(15, y, 180, 14, 2, 2, 'FD');
    
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(9);
    doc.setTextColor(71, 85, 105); // slate-600
    doc.text('Filter Pencarian Aktif:', 19, y + 5.5);
    
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(14, 165, 233); // sky-500 or indigo
    const filterInfoText = `Kata Kunci: "${searchTerm || '-'}"   |   Kategori: ${categoryFilter.toUpperCase()}`;
    doc.text(filterInfoText, 19, y + 10);
    
    // Right side stats inside the info box
    const totalFilteredAmount = displayedExpenses.reduce((sum, item) => sum + item.amount, 0);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(primaryColor[0], primaryColor[1], primaryColor[2]);
    doc.text('Total Nominal:', 135, y + 5.5);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(accentColor[0], accentColor[1], accentColor[2]);
    doc.text(formatRupiah(totalFilteredAmount), 135, y + 10);
    
    y += 22;

    // Transactions Table header
    doc.setFillColor(15, 23, 42); // slate-900 background
    doc.rect(15, y, 180, 8, 'F');
    
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(9);
    doc.setTextColor(255, 255, 255);
    
    doc.text('Waktu Transaksi', 18, y + 5.5);
    doc.text('Detail & Kategori', 60, y + 5.5);
    doc.text('Nominal', 190, y + 5.5, { align: 'right' });
    
    y += 8;

    // Table rows
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8);
    
    if (displayedExpenses.length === 0) {
      doc.setTextColor(100, 116, 139);
      doc.text('Tidak ada transaksi yang sesuai dengan filter pencarian.', 105, y + 8, { align: 'center' });
    } else {
      displayedExpenses.forEach((exp, idx) => {
        // Alternating row background
        if (idx % 2 === 1) {
          doc.setFillColor(248, 250, 252);
          doc.rect(15, y, 180, 14, 'F');
        }
        
        // Date formatting or date display
        const dateStr = exp.date ? exp.date.replace('T', ' ') : '-';
        doc.setTextColor(100, 116, 139); // slate-500
        doc.setFont('helvetica', 'normal');
        doc.text(dateStr, 18, y + 5.5);
        
        // Truncate title if too long
        let titleToShow = exp.title || '';
        if (titleToShow.length > 55) {
          titleToShow = titleToShow.substring(0, 52) + '...';
        }
        doc.setTextColor(30, 41, 59); // slate-800
        doc.setFont('helvetica', 'bold');
        doc.text(titleToShow, 60, y + 5.5);
        
        // Category representation (highlight category text)
        const catLabel = exp.category ? exp.category.toUpperCase() : '-';
        const subcatLabel = exp.subcategory || '-';
        doc.setTextColor(100, 116, 139); // slate-500
        doc.setFont('helvetica', 'normal');
        doc.text(`[${catLabel}] ${subcatLabel}`, 60, y + 10.5);
        
        doc.setTextColor(30, 41, 59);
        doc.setFont('helvetica', 'bold');
        doc.text(formatRupiah(exp.amount), 190, y + 8, { align: 'right' });
        doc.setFont('helvetica', 'normal');
        
        y += 14;

        // Check page break
        if (y > 270) {
          doc.addPage();
          y = 15;
          // Redraw table header on new page
          doc.setFillColor(15, 23, 42);
          doc.rect(15, y, 180, 8, 'F');
          doc.setFont('helvetica', 'bold');
          doc.setTextColor(255, 255, 255);
          doc.text('Waktu Transaksi', 18, y + 5.5);
          doc.text('Detail & Kategori', 60, y + 5.5);
          doc.text('Nominal', 190, y + 5.5, { align: 'right' });
          y += 8;
          doc.setFont('helvetica', 'normal');
        }
      });
    }

    // Add footer to each page
    const totalPages = (doc.internal as any).getNumberOfPages();
    for (let i = 1; i <= totalPages; i++) {
      doc.setPage(i);
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(8);
      doc.setTextColor(148, 163, 184); // slate-400
      
      // Footer text line
      doc.text(
        `Laporan Daftar Transaksi Aktif AdaptSaku • Halaman ${i} dari ${totalPages}`,
        105,
        287,
        { align: 'center' }
      );
    }

    // Download PDF filename
    const filename = `AdaptSaku_Daftar_Transaksi_${formattedPeriod}_${new Date().toISOString().substring(0, 10)}.pdf`;
    doc.save(filename);
  };

  return (
    <div id="financial_forms_container" className="bg-slate-800/50 backdrop-blur-md border border-slate-705 rounded-[2rem] shadow-xl overflow-hidden flex flex-col h-full text-slate-100">
      {/* Tab Navigation header */}
      <div className="flex bg-slate-900/60 border-b border-slate-800 p-1.5">
        <button
          id="tab_expense"
          onClick={() => setActiveTab('expense')}
          className={`flex-1 py-3 text-center rounded-xl font-sans text-xs font-black uppercase tracking-wider transition-all cursor-pointer ${
            activeTab === 'expense'
              ? 'bg-slate-700 text-white shadow-md border border-slate-600'
              : 'text-slate-400 hover:text-white hover:bg-slate-800/40'
          }`}
        >
          <span className="flex items-center justify-center gap-2">
            <Coins className="w-4 h-4 text-pink-400" />
            EXPENSES
          </span>
        </button>
        <button
          id="tab_income"
          onClick={() => setActiveTab('income')}
          className={`flex-1 py-3 text-center rounded-xl font-sans text-xs font-black uppercase tracking-wider transition-all cursor-pointer ${
            activeTab === 'income'
              ? 'bg-slate-700 text-white shadow-md border border-slate-600'
              : 'text-slate-400 hover:text-white hover:bg-slate-800/40'
          }`}
        >
          <span className="flex items-center justify-center gap-2">
            <Briefcase className="w-4 h-4 text-emerald-400" />
            INCOME
          </span>
        </button>
        <button
          id="tab_goal"
          onClick={() => setActiveTab('goal')}
          className={`flex-1 py-3 text-center rounded-xl font-sans text-xs font-black uppercase tracking-wider transition-all cursor-pointer ${
            activeTab === 'goal'
              ? 'bg-slate-700 text-white shadow-md border border-slate-600'
              : 'text-slate-400 hover:text-white hover:bg-slate-800/40'
          }`}
        >
          <span className="flex items-center justify-center gap-2">
            <PiggyBank className="w-4 h-4 text-indigo-400" />
            GOALS
          </span>
        </button>
      </div>

      <div className="p-6 flex-1 overflow-y-auto">
        {/* ==================== AI RECEIPT SCANNER ==================== */}
        {(activeTab === 'expense' || activeTab === 'income') && (
          <div className="mb-6 mb-8 flex flex-col items-center">
            {isAIScannerVisible ? (
              <div className={`w-full p-4 sm:p-5 rounded-2xl border flex flex-col gap-4 ${isDark ? 'bg-indigo-900/20 border-indigo-500/30' : 'bg-indigo-50 border-indigo-200 shadow-sm'}`}>
                <div className="flex items-start sm:items-center justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${isDark ? 'bg-indigo-600/30 text-indigo-400' : 'bg-indigo-600 text-white shadow-sm'}`}>
                      <span className="font-black text-xs">AI</span>
                    </div>
                    <div>
                      <h4 className={`text-xs font-black uppercase tracking-wider ${isDark ? 'text-indigo-300' : 'text-indigo-800'}`}>Scan Bukti Transaksi</h4>
                      <p className={`text-[10px] sm:text-xs mt-0.5 ${isDark ? 'text-indigo-400/80' : 'text-indigo-700/80'}`}>Auto-fill form ini dari struk atau screenshot transfer</p>
                    </div>
                  </div>
                  <button 
                    onClick={() => setIsAIScannerVisible(false)}
                    className={`p-2 rounded-lg shrink-0 transition-colors ${isDark ? 'hover:bg-slate-800 text-slate-400' : 'hover:bg-indigo-100 text-indigo-400 hover:text-indigo-600'}`}
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
                <div className="flex flex-col sm:flex-row gap-3 items-stretch">
                  <input
                    type="text"
                    placeholder="Tambah catatan spesifik (opsional)..."
                    value={scanNotes}
                    onChange={(e) => setScanNotes(e.target.value)}
                    className={`flex-1 h-10 px-3.5 rounded-xl border text-xs focus:outline-none transition-all ${isDark ? 'bg-slate-900/60 border-slate-700 text-slate-200 focus:border-indigo-500 placeholder-slate-500' : 'bg-white border-slate-300 text-slate-800 focus:border-indigo-500 placeholder-slate-400 shadow-sm'}`}
                  />
                  <button
                    type="button"
                    onClick={() => receiptInputRef.current?.click()}
                    disabled={isScanning}
                    className="shrink-0 w-full sm:w-auto px-5 h-10 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed text-white text-xs font-black uppercase tracking-wider rounded-xl flex items-center justify-center transition-colors shadow-md shadow-indigo-600/30"
                  >
                    {isScanning ? 'Membaca Gambar...' : 'Unggah & Scan'}
                  </button>
                </div>
                <input 
                  type="file" 
                  ref={receiptInputRef} 
                  className="hidden" 
                  accept="image/*" 
                  onChange={handleReceiptUpload} 
                />
              </div>
            ) : (
              <button 
                onClick={() => setIsAIScannerVisible(true)}
                className={`flex items-center gap-2 py-2 px-4 rounded-xl font-sans text-xs font-black uppercase tracking-wider transition-all border shadow-sm ${isDark ? 'bg-indigo-900/30 text-indigo-400 border-indigo-500/30 hover:bg-indigo-800/40' : 'bg-indigo-50 text-indigo-700 border-indigo-200 hover:bg-indigo-100 hover:border-indigo-300'}`}
              >
                <div className={`w-5 h-5 rounded-md flex items-center justify-center ${isDark ? 'bg-indigo-800 text-indigo-300' : 'bg-indigo-200 text-indigo-800'}`}>
                  <span className="text-[9px]">AI</span>
                </div>
                Gunakan AI Scanner
              </button>
            )}
          </div>
        )}

        {/* ==================== EXPENSE TAB ==================== */}
        {activeTab === 'expense' && (
          <div id="expense_panel" className="space-y-6">
            <h3 className="text-base font-sans font-black text-white leading-snug uppercase tracking-wider flex items-center justify-between">
              {editingExpenseId ? 'Ubah Pengeluaran' : 'Catat Pengeluaran Baru'}
              <span className="p-1 px-2.5 bg-pink-500/10 text-pink-400 border border-pink-500/20 text-[10px] rounded-full uppercase font-black">
                {editingExpenseId ? 'Edit Mode' : 'Spends'}
              </span>
            </h3>
            <form onSubmit={handleExpenseSubmit} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <div className="flex justify-between items-center mb-2">
                    <label className="block text-[10px] font-sans font-black text-slate-400 uppercase tracking-widest">
                      Nama Pengeluaran
                    </label>
                    {isAutoDetected && (
                      <span className="text-[9px] font-sans font-semibold text-emerald-400 uppercase tracking-wider animate-pulse flex items-center gap-1 bg-emerald-500/10 border border-emerald-500/20 px-1.5 py-0.5 rounded-md">
                        ✨ Terpilih Otomatis
                      </span>
                    )}
                  </div>
                  <input
                    type="text"
                    required
                    value={expTitle}
                    onChange={(e) => handleTitleChange(e.target.value)}
                    placeholder="Sewa kos, Kopi, Gadget, dll."
                    className="w-full h-11 px-4 py-2 bg-slate-900/60 rounded-xl border border-slate-700 text-slate-100 text-sm focus:outline-none focus:border-indigo-500 placeholder-slate-500 transition"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-sans font-black text-slate-400 uppercase tracking-widest mb-2">
                    Jumlah (Rupiah)
                  </label>
                  <div className="relative">
                    <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-xs font-bold text-slate-500 font-mono z-10 pointer-events-none financial-rp-prefix">Rp</span>
                    <input
                      type="number"
                      required
                      min="1"
                      value={expAmount}
                      onChange={(e) => setExpAmount(e.target.value)}
                      placeholder="150000"
                      className="w-full h-11 pl-11 pr-4 py-2 bg-slate-900/60 rounded-xl border border-slate-700 text-slate-100 text-sm focus:outline-none focus:border-indigo-500 placeholder-slate-500 transition"
                    />
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-[10px] font-sans font-black text-slate-400 uppercase tracking-widest mb-2">
                    Kategori Alokasi
                  </label>
                  <select
                    value={expCategory}
                    onChange={(e) => {
                      const cat = e.target.value as any;
                      setExpCategory(cat);
                      setExpSubcategory(subcategoryPresets[cat][0]);
                      setIsAutoDetected(false);
                    }}
                    className="w-full h-11 px-4 py-2 bg-slate-900/60 rounded-xl border border-slate-700 text-slate-100 text-sm focus:outline-none focus:border-indigo-500 transition"
                  >
                    <option value="kebutuhan" className="bg-slate-900">Kebutuhan (Needs) - Wajib</option>
                    <option value="keinginan" className="bg-slate-900">Keinginan (Wants) - Gaya Hidup</option>
                    <option value="tabungan" className="bg-slate-900">Tabungan (Savings) - Berskala</option>
                    <option value="program_kerja" className="bg-slate-900">Program Kerja (Organisasi)</option>
                    <option value="modal_usaha" className="bg-slate-900">Modal Danus (Organisasi)</option>
                    <option value="operasional_org" className="bg-slate-900">Operasional (Organisasi)</option>
                    <option value="lain_lain" className="bg-slate-900">Lain-lain</option>
                  </select>
                </div>
                <div>
                  <label className="block text-[10px] font-sans font-black text-slate-400 uppercase tracking-widest mb-2">
                    Subkategori
                  </label>
                  <select
                    value={expSubcategory}
                    onChange={(e) => {
                      setExpSubcategory(e.target.value);
                      setIsAutoDetected(false);
                    }}
                    className="w-full h-11 px-4 py-2 bg-slate-900/60 rounded-xl border border-slate-700 text-slate-105 text-sm focus:outline-none focus:border-indigo-500 transition"
                  >
                    {subcategoryPresets[expCategory].map((sub) => (
                      <option key={sub} value={sub} className="bg-slate-900">{sub}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-[10px] font-sans font-black text-slate-400 uppercase tracking-widest mb-2">
                    Waktu Transaksi
                  </label>
                  <input
                    type="datetime-local"
                    required
                    value={expDate}
                    onChange={(e) => setExpDate(e.target.value)}
                    className="w-full h-11 px-4 py-2 bg-slate-900/60 rounded-xl border border-slate-700 text-slate-100 text-sm focus:outline-none focus:border-indigo-500 transition"
                  />
                </div>
              </div>

              <div className="flex items-center mt-2 mb-4">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input 
                    type="checkbox" 
                    checked={expRecurring}
                    onChange={(e) => setExpRecurring(e.target.checked)}
                    className="w-4 h-4 rounded text-pink-500 focus:ring-pink-500 bg-slate-900 border-slate-700" 
                  />
                  <span className="text-xs font-semibold text-slate-300">Tandai sebagai pengeluaran rutin tiap bulan</span>
                </label>
              </div>

              <div className="flex gap-2">
                <button
                  type="submit"
                  className="flex-1 h-11 bg-pink-600 hover:bg-pink-700 text-white font-sans text-xs font-black uppercase tracking-wider rounded-xl flex items-center justify-center gap-2 shadow-lg hover:shadow-pink-900/30 transition-all duration-300 cursor-pointer"
                >
                  {editingExpenseId ? <Check className="w-4 h-4" /> : <Plus className="w-4 h-4" />}
                  {editingExpenseId ? 'Simpan Perubahan' : 'Tambahkan Pengeluaran'}
                </button>
                {editingExpenseId && (
                  <button
                    type="button"
                    onClick={() => {
                      setEditingExpenseId(null);
                      setExpTitle('');
                      setExpAmount('');
                      setIsAutoDetected(false);
                    }}
                    className="w-24 h-11 bg-slate-700 hover:bg-slate-600 border border-slate-600 text-slate-100 font-sans text-xs font-black uppercase tracking-wider rounded-xl transition cursor-pointer"
                  >
                    Batal
                  </button>
                )}
              </div>
            </form>

            {/* List of current expenses */}
            <div className="pt-5 border-t border-slate-805">
              <div className="flex flex-col sm:flex-row justify-between gap-3 mb-4">
                <div className="flex flex-col gap-1">
                  <h4 className="text-[10px] font-sans font-black text-slate-400 uppercase tracking-widest">
                    DAFTAR TRANSAKSI AKTIF
                  </h4>
                  <div className="flex items-center gap-2">
                    <span className="px-2 py-0.5 rounded-full bg-slate-900 text-slate-350 border border-slate-800 font-mono text-[9px] font-black">
                      Menampilkan {displayedExpenses.length} dari {expenses.length} transaksi
                    </span>
                    {(searchTerm || categoryFilter !== 'semua') && (
                      <span className="text-[9px] font-sans font-black uppercase text-pink-400 tracking-wider">
                        * Filter Aktif
                      </span>
                    )}
                  </div>
                </div>
                
                <div className="flex items-center justify-between sm:justify-end gap-2 flex-wrap">
                  <span className="text-[11px] font-mono font-black text-pink-400 bg-pink-500/10 border border-pink-500/20 px-2.5 py-1.5 rounded-full whitespace-nowrap">
                    Total: {formatRupiah(displayedExpenses.reduce((s, e) => s + e.amount, 0))}
                  </span>
                  
                  {displayedExpenses.length > 0 && (
                    <button
                      type="button"
                      onClick={handleExportListPDF}
                      className="inline-flex items-center gap-1.5 text-[10px] items-center justify-center font-sans font-black uppercase tracking-wider py-1.5 px-3 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white border border-indigo-500 transition duration-300 cursor-pointer shadow-md shadow-indigo-950/20 whitespace-nowrap"
                      title="Cetak PDF daftar yang terfilter saat ini"
                    >
                      <Printer className="w-3.5 h-3.5" />
                      <span>Cetak PDF</span>
                    </button>
                  )}
                </div>
              </div>

              {/* Filtering Controls (Search and Category filter) */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 mb-4">
                <div className="relative">
                  <span className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-500">
                    <Search className="w-3.5 h-3.5" />
                  </span>
                  <input
                    type="text"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    placeholder="Cari transaksi / subkategori..."
                    className="w-full h-9 pl-9 pr-8 py-1 bg-slate-900/60 rounded-lg border border-slate-700/80 text-slate-100 text-xs focus:outline-none focus:border-indigo-500 placeholder-slate-500/80 transition"
                  />
                  {searchTerm && (
                    <button
                      type="button"
                      onClick={() => setSearchTerm('')}
                      className="absolute inset-y-0 right-0 pr-2.5 flex items-center text-slate-500 hover:text-slate-300"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
                <div className="relative">
                  <span className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-500">
                    <Filter className="w-3.5 h-3.5" />
                  </span>
                  <select
                    value={categoryFilter}
                    onChange={(e) => setCategoryFilter(e.target.value as any)}
                    className="w-full h-9 pl-9 pr-8 bg-slate-900/60 rounded-lg border border-slate-700/80 text-slate-100 text-xs focus:outline-none focus:border-indigo-500 transition appearance-none cursor-pointer"
                  >
                    <option value="semua" className="bg-slate-900">Semua Kategori</option>
                    <option value="kebutuhan" className="bg-slate-900">Kebutuhan (Needs)</option>
                    <option value="keinginan" className="bg-slate-900">Keinginan (Wants)</option>
                    <option value="tabungan" className="bg-slate-900">Tabungan (Savings)</option>
                    <option value="program_kerja" className="bg-slate-900">Program Kerja</option>
                    <option value="modal_usaha" className="bg-slate-900">Modal Danus</option>
                    <option value="operasional_org" className="bg-slate-900">Operasional Org</option>
                    <option value="lain_lain" className="bg-slate-900">Lain-lain</option>
                  </select>
                  <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-slate-500">
                    <svg className="fill-current h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20">
                      <path d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z"/>
                    </svg>
                  </div>
                </div>
              </div>

              {expenses.length === 0 ? (
                <div className="text-center py-10 text-slate-500 text-xs border border-dashed border-slate-700/60 rounded-2xl text-slate-400">
                  Belum ada transaksi terekam. Masukkan pengeluaran pertama Anda.
                </div>
              ) : displayedExpenses.length === 0 ? (
                <div className="text-center py-10 text-slate-400 text-xs border border-dashed border-slate-700/60 rounded-2xl">
                  Tidak ada transaksi yang cocok dengan filter pencarian Anda. Bersihkan filter untuk melihat semua.
                </div>
              ) : (
                <div className="max-h-[520px] overflow-y-auto space-y-2 pr-1">
                  {displayedExpenses.map((exp) => {
                    const formatDateLabel = (dateStr: string) => {
                      if (!dateStr) return '';
                      const dateOnly = dateStr.includes('T') ? dateStr.split('T')[0] : dateStr;
                      const timeOnly = dateStr.includes('T') ? dateStr.split('T')[1].slice(0, 5) : '';
                      const parts = dateOnly.split('-');
                      if (parts.length < 3) return dateStr;
                      const [_, mm, dd] = parts;
                      const months = ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Agt', 'Sep', 'Okt', 'Nov', 'Des'];
                      const monthIdx = parseInt(mm, 10) - 1;
                      const formatted = `${dd} ${months[monthIdx] || mm}`;
                      return timeOnly ? `${formatted} ${timeOnly}` : formatted;
                    };
                    return (
                      <div
                        key={exp.id}
                        className="p-3.5 rounded-xl bg-slate-900/40 hover:bg-slate-800/40 border border-slate-800/80 hover:border-slate-700 transition flex flex-col gap-2.5"
                      >
                        {/* Baris 1: Simbol Kategori & Aksi Edit/Hapus */}
                        <div className="flex justify-between items-center">
                          <div className={`px-2.5 py-1 rounded-lg flex items-center gap-1.5 border leading-none font-sans text-[10px] font-black uppercase tracking-wider ${
                            exp.category === 'kebutuhan' ? 'bg-amber-500/10 text-amber-500 border-amber-500/20' :
                            exp.category === 'keinginan' ? 'bg-pink-500/10 text-pink-500 border-pink-500/20' : 'bg-emerald-500/10 text-emerald-500 border-emerald-500/20'
                          }`}>
                            <span className="w-1.5 h-1.5 rounded-full bg-current"></span>
                            <span>{exp.category}</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <button
                              onClick={() => handleStartEditExpense(exp)}
                              className="text-slate-400 hover:text-indigo-400 p-1.5 rounded-lg hover:bg-slate-800/80 transition-all cursor-pointer"
                              title="Edit Transaksi"
                            >
                              <Pencil className="w-3.5 h-3.5" />
                            </button>
                            <button
                              onClick={() => {
                                if (editingExpenseId === exp.id) {
                                  setEditingExpenseId(null);
                                  setExpTitle('');
                                  setExpAmount('');
                                }
                                onDeleteExpense(exp.id);
                              }}
                              className="text-slate-400 hover:text-rose-450 p-1.5 rounded-lg hover:bg-slate-800/80 transition-all cursor-pointer"
                              title="Hapus Transaksi"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>

                        {/* Baris 2: Nama Transaksi & Keterangan detail */}
                        <div className="space-y-1.5">
                          <p className="text-sm font-extrabold text-white leading-snug flex items-center gap-2 flex-wrap billing-title">
                            <span>{exp.title}</span>
                            {exp.isRecurring && (
                              <span className="inline-flex items-center gap-1 text-[9px] px-1.5 py-0.5 rounded bg-pink-500/10 text-pink-500 border border-pink-500/20 font-sans font-black uppercase tracking-wider">
                                <Repeat className="w-2.5 h-2.5" /> Rutin
                              </span>
                            )}
                          </p>
                          <div className="text-[10px] text-slate-400 flex items-center gap-2 flex-wrap font-medium">
                            <span className="px-1.5 py-0.5 rounded font-mono text-[9px] flex items-center gap-1 shrink-0 financial-badge-date-exp">
                              <Calendar className="w-2.5 h-2.5" />
                              {formatDateLabel(exp.date)}
                            </span>
                            <span className="text-slate-600">•</span>
                            <span className="px-1.5 py-0.5 rounded text-[9px] font-sans font-black tracking-normal uppercase financial-badge-info">
                              {exp.subcategory}
                            </span>
                          </div>
                        </div>

                        {/* Baris 3: Nominal */}
                        <div className="flex justify-between items-center pt-2.5 border-t border-slate-800/40">
                          <span className="text-[10px] uppercase font-black tracking-wider text-slate-500 font-sans">Nominal</span>
                          <span className="text-sm font-mono font-black text-rose-455 expense-card-amount">
                            - {formatRupiah(exp.amount)}
                          </span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
        )}

        {/* ==================== INCOME TAB ==================== */}
        {activeTab === 'income' && (
          <div id="income_panel" className="space-y-6">
            <h3 className="text-base font-sans font-black text-white leading-snug uppercase tracking-wider flex items-center justify-between">
              {editingIncomeId ? 'Ubah Pendapatan' : 'Catat Pendapatan Baru'}
              <span className="p-1 px-2.5 bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 text-[10px] rounded-full uppercase font-black">
                {editingIncomeId ? 'Edit Mode' : 'Incomes'}
              </span>
            </h3>
            <form onSubmit={handleIncomeSubmit} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] font-sans font-black text-slate-400 uppercase tracking-widest mb-2">
                    Sumber Pendapatan
                  </label>
                  <input
                    type="text"
                    required
                    value={incSource}
                    onChange={(e) => setIncSource(e.target.value)}
                    placeholder="Gaji Utama, Kerja Sampingan, dll."
                    className="w-full h-11 px-4 py-2 bg-slate-900/60 rounded-xl border border-slate-700 text-slate-100 text-sm focus:outline-none focus:border-indigo-500 placeholder-slate-500 transition"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-sans font-black text-slate-400 uppercase tracking-widest mb-2">
                    Jumlah (Rupiah)
                  </label>
                  <div className="relative">
                    <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-xs font-bold text-slate-500 font-mono z-10 pointer-events-none financial-rp-prefix">Rp</span>
                    <input
                      type="number"
                      required
                      min="1"
                      value={incAmount}
                      onChange={(e) => setIncAmount(e.target.value)}
                      placeholder="5000000"
                      className="w-full h-11 pl-11 pr-4 py-2 bg-slate-900/60 rounded-xl border border-slate-700 text-slate-100 text-sm focus:outline-none focus:border-indigo-500 placeholder-slate-500 transition"
                    />
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-[10px] font-sans font-black text-slate-400 uppercase tracking-widest mb-2">
                    Jenis/Kategori
                  </label>
                  <select
                    value={incCategory}
                    onChange={(e) => setIncCategory(e.target.value as any)}
                    className="w-full h-11 px-4 py-2 bg-slate-900/60 rounded-xl border border-slate-700 text-slate-100 text-sm focus:outline-none focus:border-indigo-500 transition"
                  >
                    <option value="primary" className="bg-slate-900">Gaji Pokok / Pekerjaan Utama</option>
                    <option value="side-hustle" className="bg-slate-900">Freelance / Proyek Sampingan</option>
                    <option value="investment" className="bg-slate-900">Investasi / Dividen / Bunga</option>
                    <option value="other" className="bg-slate-900">Jenis Pendapatan Lainnya</option>
                    <option value="universitas" className="bg-slate-900">Universitas / Beasiswa</option>
                    <option value="iuran_kas" className="bg-slate-900">Iuran Kas Anggota</option>
                    <option value="dana_usaha" className="bg-slate-900">Dana Usaha (Danus)</option>
                    <option value="sponsor" className="bg-slate-900">Sponsorship / Kemitraan</option>
                    <option value="organisasi_lain" className="bg-slate-900">Dana Organisasi</option>
                  </select>
                </div>
                <div>
                  <label className="block text-[10px] font-sans font-black text-slate-400 uppercase tracking-widest mb-2">
                    Sifat Pendapatan
                  </label>
                  <select
                    value={incPeriod}
                    onChange={(e) => setIncPeriod(e.target.value as any)}
                    className="w-full h-11 px-4 py-2 bg-slate-900/60 rounded-xl border border-slate-700 text-slate-105 text-sm focus:outline-none focus:border-indigo-500 transition"
                  >
                    <option value="monthly" className="bg-slate-900">Bulanan (Rutin)</option>
                    <option value="one-time" className="bg-slate-900">Sekali Waktu (Bonus/Hadiah)</option>
                  </select>
                </div>
                <div>
                  <label className="block text-[10px] font-sans font-black text-slate-400 uppercase tracking-widest mb-2">
                    Waktu Pendapatan
                  </label>
                  <input
                    type="datetime-local"
                    required
                    value={incDate}
                    onChange={(e) => setIncDate(e.target.value)}
                    className="w-full h-11 px-4 py-2 bg-slate-900/60 rounded-xl border border-slate-700 text-slate-100 text-sm focus:outline-none focus:border-indigo-500 transition"
                  />
                </div>
              </div>

              <div className="flex items-center mt-2 mb-4">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input 
                    type="checkbox" 
                    checked={incRecurring}
                    onChange={(e) => setIncRecurring(e.target.checked)}
                    className="w-4 h-4 rounded text-emerald-500 focus:ring-emerald-500 bg-slate-900 border-slate-700" 
                  />
                  <span className="text-xs font-semibold text-slate-300">Tandai sebagai pemasukan rutin tiap bulan</span>
                </label>
              </div>

              <div className="flex gap-2">
                <button
                  type="submit"
                  className="flex-1 h-11 bg-emerald-600 hover:bg-emerald-700 text-white font-sans text-xs font-black uppercase tracking-wider rounded-xl flex items-center justify-center gap-2 shadow-lg hover:shadow-emerald-900/30 transition-all duration-300 cursor-pointer"
                >
                  {editingIncomeId ? <Check className="w-4 h-4" /> : <Plus className="w-4 h-4" />}
                  {editingIncomeId ? 'Simpan Perubahan' : 'Tambahkan Pendapatan'}
                </button>
                {editingIncomeId && (
                  <button
                    type="button"
                    onClick={() => {
                      setEditingIncomeId(null);
                      setIncSource('');
                      setIncAmount('');
                    }}
                    className="w-24 h-11 bg-slate-700 hover:bg-slate-600 border border-slate-600 text-slate-100 font-sans text-xs font-black uppercase tracking-wider rounded-xl transition cursor-pointer"
                  >
                    Batal
                  </button>
                )}
              </div>
            </form>

            {/* List of current incomes */}
            <div className="pt-5 border-t border-slate-805">
              <div className="flex flex-col sm:flex-row justify-between gap-3 mb-4">
                <div className="flex flex-col gap-1">
                  <h4 className="text-[10px] font-sans font-black text-slate-400 uppercase tracking-widest">
                    DAFTAR PEMASUKAN AKTIF
                  </h4>
                  <div className="flex items-center gap-2">
                    <span className="px-2 py-0.5 rounded-full bg-slate-900 text-slate-350 border border-slate-800 font-mono text-[9px] font-black">
                      Menampilkan {incomes.length} transaksi
                    </span>
                  </div>
                </div>
                <div className="flex items-center justify-between sm:justify-end gap-2 flex-wrap">
                  <span className="text-[11px] font-mono font-black text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 px-2.5 py-1.5 rounded-full whitespace-nowrap">
                    Total: {formatRupiah(incomes.reduce((s, i) => s + i.amount, 0))}
                  </span>
                </div>
              </div>
              {incomes.length === 0 ? (
                <div className="text-center py-10 text-slate-500 text-xs border border-dashed border-slate-700/60 rounded-2xl">
                  Kosong. Masukkan pendapatan bersih rutin atau omzet freelance Anda di atas.
                </div>
              ) : (
                <div className="max-h-[520px] overflow-y-auto space-y-2 pr-1">
                  {incomes.map((inc) => {
                    const formatDateLabel = (dateStr: string) => {
                      if (!dateStr) return '';
                      const dateOnly = dateStr.includes('T') ? dateStr.split('T')[0] : dateStr;
                      const timeOnly = dateStr.includes('T') ? dateStr.split('T')[1].slice(0, 5) : '';
                      const parts = dateOnly.split('-');
                      if (parts.length < 3) return dateStr;
                      const [_, mm, dd] = parts;
                      const months = ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Agt', 'Sep', 'Okt', 'Nov', 'Des'];
                      const monthIdx = parseInt(mm, 10) - 1;
                      const formatted = `${dd} ${months[monthIdx] || mm}`;
                      return timeOnly ? `${formatted} ${timeOnly}` : formatted;
                    };
                    return (
                      <div
                        key={inc.id}
                        className="p-3.5 rounded-xl bg-slate-900/40 hover:bg-slate-800/40 border border-slate-800/80 hover:border-slate-700 transition flex flex-col gap-2.5"
                      >
                        {/* Baris 1: Simbol Kategori & Aksi Edit/Hapus */}
                        <div className="flex justify-between items-center">
                          <div className="px-2.5 py-1 rounded-lg flex items-center gap-1.5 border leading-none font-sans text-[10px] font-black uppercase tracking-wider bg-emerald-500/10 text-emerald-400 border-emerald-500/20">
                            {inc.category === 'primary' ? <Briefcase className="w-3.5 h-3.5" /> : <Coins className="w-3.5 h-3.5" />}
                            <span>{inc.category === 'primary' ? 'Utama' : inc.category === 'side-hustle' ? 'Sampingan' : 'Pasif/Lain'}</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <button
                              onClick={() => handleStartEditIncome(inc)}
                              className="text-slate-400 hover:text-emerald-400 p-1.5 rounded-lg hover:bg-slate-800/80 transition-all cursor-pointer"
                              title="Edit Pendapatan"
                            >
                              <Pencil className="w-3.5 h-3.5" />
                            </button>
                            <button
                              onClick={() => {
                                if (editingIncomeId === inc.id) {
                                  setEditingIncomeId(null);
                                  setIncSource('');
                                  setIncAmount('');
                                }
                                onDeleteIncome(inc.id);
                              }}
                              className="text-slate-400 hover:text-rose-450 p-1.5 rounded-lg hover:bg-slate-800/80 transition-all cursor-pointer"
                              title="Hapus Pendapatan"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>

                        {/* Baris 2: Nama Pendapatan & Keterangan detail */}
                        <div className="space-y-1.5">
                          <p className="text-sm font-extrabold text-white leading-snug flex items-center gap-2 flex-wrap billing-title">
                            <span>{inc.source}</span>
                            {inc.isRecurring && (
                              <span className="inline-flex items-center gap-1 text-[9px] px-1.5 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 font-sans font-black uppercase tracking-wider">
                                <Repeat className="w-2.5 h-2.5" /> Rutin
                              </span>
                            )}
                          </p>
                          <div className="text-[10px] text-slate-400 flex items-center gap-2 flex-wrap font-medium">
                            <span className="px-1.5 py-0.5 rounded font-mono text-[9px] flex items-center gap-1 shrink-0 financial-badge-date-inc">
                              <Calendar className="w-2.5 h-2.5" />
                              {formatDateLabel(inc.date)}
                            </span>
                            <span className="text-slate-600">•</span>
                            <span className="px-1.5 py-0.5 rounded text-[9px] font-sans font-black tracking-normal uppercase financial-badge-info">
                              {inc.period === 'monthly' ? 'Bulanan' : 'Satu kali'}
                            </span>
                          </div>
                        </div>

                        {/* Baris 3: Nominal */}
                        <div className="flex justify-between items-center pt-2.5 border-t border-slate-800/40">
                          <span className="text-[10px] uppercase font-black tracking-wider text-slate-500 font-sans">Nominal</span>
                          <span className="text-sm font-mono font-black text-emerald-400 income-card-amount">
                            + {formatRupiah(inc.amount)}
                          </span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
        )}

        {/* ==================== GOAL TAB ==================== */}
        {activeTab === 'goal' && (
          <div id="goal_panel" className="space-y-6">
            <h3 className="text-base font-sans font-black text-white leading-snug uppercase tracking-wider flex items-center justify-between">
              {editingGoalId ? 'Ubah Rencana Keuangan' : 'Catat Tujuan Finansial (Goals) Baru'}
              <span className="p-1 px-2.5 bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 text-[10px] rounded-full uppercase font-black">
                {editingGoalId ? 'Edit Mode' : 'Goals'}
              </span>
            </h3>
            <form onSubmit={handleGoalSubmit} className="space-y-4">
              <div className="flex items-center justify-between pb-2">
                <p className="text-[10px] text-slate-450 font-medium">Bisa membuat milestone pribadi atau gunakan rekomendasi standar:</p>
                {!editingGoalId && (
                  <button type="button" onClick={handleApplyEmergencyPreset} className="text-[10px] font-sans font-black uppercase tracking-wide bg-indigo-500/20 text-indigo-400 hover:text-indigo-300 hover:bg-indigo-500/30 px-3 py-1.5 rounded-lg transition">
                    + Preset Dana Darurat
                  </button>
                )}
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] font-sans font-black text-slate-400 uppercase tracking-widest mb-2">
                    Nama Rencana Keuangan
                  </label>
                  <input
                    type="text"
                    required
                    value={goalName}
                    onChange={(e) => setGoalName(e.target.value)}
                    placeholder="Dana Darurat, Rumah Impian, dll."
                    className="w-full h-11 px-4 py-2 bg-slate-900/60 rounded-xl border border-slate-700 text-slate-100 text-sm focus:outline-none focus:border-indigo-500 placeholder-slate-500 transition"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-sans font-black text-slate-400 uppercase tracking-widest mb-2">
                    Target Akumulasi (Rp)
                  </label>
                  <div className="relative">
                    <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-xs font-bold text-slate-500 font-mono z-10 pointer-events-none financial-rp-prefix">Rp</span>
                    <input
                      id="goalTargetInput"
                      type="number"
                      required
                      min="1"
                      value={goalTarget}
                      onChange={(e) => setGoalTarget(e.target.value)}
                      placeholder="15000000"
                      className="w-full h-11 pl-11 pr-4 py-2 bg-slate-900/60 rounded-xl border border-slate-700 text-slate-100 text-sm focus:outline-none focus:border-indigo-500 placeholder-slate-500 transition"
                    />
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-[10px] font-sans font-black text-slate-400 uppercase tracking-widest mb-2">
                    Saldo Saat Ini (Rp)
                  </label>
                  <div className="relative">
                    <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-xs font-bold text-slate-500 font-mono z-10 pointer-events-none financial-rp-prefix">Rp</span>
                    <input
                      type="number"
                      min="0"
                      value={goalCurrent}
                      onChange={(e) => setGoalCurrent(e.target.value)}
                      placeholder="0"
                      className="w-full h-11 pl-11 pr-4 py-2 bg-slate-900/60 rounded-xl border border-slate-700 text-slate-100 text-sm focus:outline-none focus:border-indigo-500 placeholder-slate-500 transition"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-[10px] font-sans font-black text-slate-400 uppercase tracking-widest mb-2">
                    Target Tanggal
                  </label>
                  <input
                    type="date"
                    required
                    value={goalDate}
                    onChange={(e) => setGoalDate(e.target.value)}
                    className="w-full h-11 px-4 py-2 bg-slate-900/60 rounded-xl border border-slate-700 text-slate-105 text-sm focus:outline-none focus:border-indigo-500 transition"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-sans font-black text-slate-400 uppercase tracking-widest mb-2">
                    Prioritas Urgensi
                  </label>
                  <select
                    value={goalPriority}
                    onChange={(e) => setGoalPriority(e.target.value as any)}
                    className="w-full h-11 px-4 py-2 bg-slate-900/60 rounded-xl border border-slate-700 text-slate-100 text-sm focus:outline-none focus:border-indigo-500 transition"
                  >
                    <option value="high" className="bg-slate-900">Tinggi (Mendesak)</option>
                    <option value="medium" className="bg-slate-900">Sedang (Penting)</option>
                    <option value="low" className="bg-slate-900">Rendah (Opsional)</option>
                  </select>
                </div>
              </div>

              <div className="flex gap-2">
                <button
                  type="submit"
                  className="flex-1 h-11 bg-indigo-600 hover:bg-indigo-700 text-white font-sans text-xs font-black uppercase tracking-wider rounded-xl flex items-center justify-center gap-2 shadow-lg hover:shadow-indigo-900/30 transition-all duration-300 cursor-pointer"
                >
                  {editingGoalId ? <Check className="w-4 h-4" /> : <Plus className="w-4 h-4" />}
                  {editingGoalId ? 'Simpan Perubahan' : 'Daftarkan Target Tujuan'}
                </button>
                {editingGoalId && (
                  <button
                    type="button"
                    onClick={() => {
                      setEditingGoalId(null);
                      setGoalName('');
                      setGoalTarget('');
                      setGoalCurrent('0');
                      setGoalDate('');
                    }}
                    className="w-24 h-11 bg-slate-700 hover:bg-slate-600 border border-slate-600 text-slate-100 font-sans text-xs font-black uppercase tracking-wider rounded-xl transition cursor-pointer"
                  >
                    Batal
                  </button>
                )}
              </div>
            </form>

            {/* List of goals */}
            <div className="pt-5 border-t border-slate-805">
              <div className="flex flex-col gap-1 mb-4">
                <h4 className="text-[10px] font-sans font-black text-slate-400 uppercase tracking-widest">
                  DAFTAR TUJUAN FINANSIAL
                </h4>
                <div className="flex items-center gap-2">
                  <span className="px-2 py-0.5 rounded-full bg-slate-900 text-slate-350 border border-slate-800 font-mono text-[9px] font-black">
                    Menampilkan {goals.length} tujuan
                  </span>
                </div>
              </div>
              {goals.length === 0 ? (
                <div className="text-center py-10 text-slate-500 text-xs border border-dashed border-slate-700/60 rounded-2xl">
                  Belum ada rencana keuangan. Buat tujuan Anda (misalnya Dana Darurat) untuk mulai merakit perisai finansial yang adaptif.
                </div>
              ) : (
                <div className="max-h-[520px] overflow-y-auto space-y-3 pr-1">
                  {goals.map((goal) => {
                    const percentage = Math.min(100, Math.round((goal.currentAmount / goal.targetAmount) * 100));
                    return (
                      <div
                        key={goal.id}
                        className="p-4 rounded-xl border border-slate-800 bg-slate-900/40 hover:bg-slate-800/40 hover:border-slate-700 transition space-y-3"
                      >
                        <div className="flex justify-between items-start">
                          <div>
                            <div className="flex items-center gap-2">
                              <span className="text-sm font-bold text-white">
                                {goal.name}
                              </span>
                              <span className={`text-[8px] font-sans font-black uppercase px-2 py-0.5 rounded-full border ${
                                goal.priority === 'high' ? 'bg-rose-500/10 text-rose-455 border-rose-500/20' :
                                goal.priority === 'medium' ? 'bg-amber-500/10 text-amber-450 border-amber-500/20' : 'bg-blue-500/10 text-blue-450 border-blue-500/20'
                              }`}>
                                {goal.priority === 'high' ? 'Urgens' : goal.priority === 'medium' ? 'Penting' : 'Minor'}
                              </span>
                            </div>
                            <p className="text-[10px] text-slate-450 font-sans flex items-center gap-1 mt-1.5 font-medium">
                              <Calendar className="w-3.5 h-3.5 text-indigo-400" /> Target: {goal.targetDate}
                            </p>
                          </div>
                          <div className="flex items-center gap-2">
                            <span className="text-xs font-mono font-black text-indigo-400 mr-1.5">
                              {percentage}%
                            </span>
                            <button
                              onClick={() => handleStartEditGoal(goal)}
                              className="text-slate-400 hover:text-indigo-400 p-1.5 rounded-lg hover:bg-slate-800/80 transition-all cursor-pointer"
                              title="Edit Target"
                            >
                              <Pencil className="w-3.5 h-3.5" />
                            </button>
                            <button
                              onClick={() => {
                                if (editingGoalId === goal.id) {
                                  setEditingGoalId(null);
                                  setGoalName('');
                                  setGoalTarget('');
                                  setGoalCurrent('0');
                                  setGoalDate('');
                                }
                                onDeleteGoal(goal.id);
                              }}
                              className="text-slate-400 hover:text-rose-455 p-1.5 rounded-lg hover:bg-slate-800/80 transition-all cursor-pointer"
                              title="Hapus Target"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>

                        {/* Progress Bar */}
                        <div className="space-y-1.5">
                          <div className="w-full bg-slate-800 h-2.5 rounded-full overflow-hidden border border-slate-750">
                            <div
                              className="bg-indigo-500 h-full rounded-full transition-all duration-500"
                              style={{ width: `${percentage}%` }}
                            />
                          </div>
                          <div className="flex justify-between text-[10px] font-mono font-black text-slate-400 mt-1">
                            <span>{formatRupiah(goal.currentAmount)}</span>
                            <span>Target: {formatRupiah(goal.targetAmount)}</span>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
